param(
    [Parameter(Mandatory = $true)]
    [string]$ResourceGroupName,

    [Parameter(Mandatory = $true)]
    [string]$Location,

    [Parameter(Mandatory = $true)]
    [string]$PythonSessionPoolName,

    [string]$AcrNamePrefix = "acrdynsessions",
    [string]$CustomEnvironmentName = "acae-custom-sessions",
    [string]$CustomSessionPoolName = "csharp-custom-pool",
    [string]$ImageName = "csharp-code-interpreter",
    [string]$ImageTag = "v1",
    [switch]$SkipProviderRegistration,
    [switch]$ForceRecreateCustomPool
)

$ErrorActionPreference = "Stop"

function Confirm-RequiredCommand {
    param([string]$Name)

    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        throw "Required command '$Name' is not available on PATH."
    }
}

function Write-Step {
    param([string]$Message)
    Write-Host "`n=== $Message ===" -ForegroundColor Cyan
}

function Invoke-TimedStep {
    param(
        [string]$Label,
        [scriptblock]$Script
    )

    Write-Host ("Starting: {0}" -f $Label) -ForegroundColor DarkCyan
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    & $Script
    $sw.Stop()
    Write-Host ("Completed: {0} ({1}s)" -f $Label, [math]::Round($sw.Elapsed.TotalSeconds, 1)) -ForegroundColor DarkCyan
}

function ConvertTo-SessionPoolSafeName {
    param([string]$Value)

    $candidate = ($Value.ToLowerInvariant() -replace "[^a-z0-9]", "")
    if ([string]::IsNullOrWhiteSpace($candidate)) {
        $candidate = "pydynamicsessions"
    }
    if ($candidate[0] -notmatch "[a-z]") {
        $candidate = "p$candidate"
    }

    return $candidate
}

Confirm-RequiredCommand -Name "az"
Confirm-RequiredCommand -Name "terraform"

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoRoot = Split-Path -Parent $scriptDir
$terraformDir = Join-Path $repoRoot "terraform"
$csharpDir = Join-Path $repoRoot "dotnet/CsharpCodeInterpreter"

if (-not (Test-Path $terraformDir)) {
    throw "Terraform directory not found at: $terraformDir"
}

if (-not (Test-Path $csharpDir)) {
    throw "CsharpCodeInterpreter directory not found at: $csharpDir"
}

$effectivePythonSessionPoolName = ConvertTo-SessionPoolSafeName -Value $PythonSessionPoolName
if ($effectivePythonSessionPoolName -ne $PythonSessionPoolName) {
    Write-Host ("Adjusted Python session pool name from '{0}' to '{1}' to satisfy provider naming rules." -f $PythonSessionPoolName, $effectivePythonSessionPoolName) -ForegroundColor Yellow
}

Write-Step "Azure login and subscription"
az login | Out-Null
$subscriptionId = az account show --query id -o tsv
if ([string]::IsNullOrWhiteSpace($subscriptionId)) {
    throw "Unable to resolve Azure subscription ID."
}
Write-Host "Using subscription: $subscriptionId"

if (-not $SkipProviderRegistration) {
    Write-Step "Registering Microsoft.App provider and containerapp extension"
    az provider register --namespace Microsoft.App | Out-Null
    az extension add --name containerapp --allow-preview true --upgrade | Out-Null
}

Write-Step "Preparing terraform.tfvars"
$tfVarsPath = Join-Path $terraformDir "terraform.tfvars"
$tfVarsContent = @"
resource_group_name      = "$ResourceGroupName"
location                 = "$Location"
session_pool_name        = "$effectivePythonSessionPoolName"
acr_name_prefix          = "$AcrNamePrefix"
max_concurrent_sessions  = 5
cooldown_period_seconds  = 300
session_egress_status    = "EgressEnabled"
"@
Set-Content -Path $tfVarsPath -Value $tfVarsContent -Encoding utf8

Write-Step "Terraform init/apply"
Push-Location $terraformDir
try {
    Invoke-TimedStep -Label "terraform init" -Script {
        terraform init
        if ($LASTEXITCODE -ne 0) {
            throw "terraform init failed with exit code $LASTEXITCODE"
        }
    }

    Write-Host "Terraform init finished; starting terraform apply..." -ForegroundColor Yellow
    Invoke-TimedStep -Label "terraform apply" -Script {
        terraform apply -auto-approve -input=false
        if ($LASTEXITCODE -ne 0) {
            throw "terraform apply failed with exit code $LASTEXITCODE"
        }
    }
    Write-Host "Terraform apply finished." -ForegroundColor Yellow

    $rg = terraform output -raw resource_group_name
    $acrName = terraform output -raw acr_name
    $acrServer = terraform output -raw acr_login_server
    $pythonPool = terraform output -raw session_pool_name
    $mcpEndpoint = terraform output -raw mcp_server_endpoint
}
finally {
    Pop-Location
}

Write-Step "Building and pushing image to ACR"
Write-Host ("Building image {0}:{1} in ACR {2}" -f $ImageName, $ImageTag, $acrName)
Invoke-TimedStep -Label "az acr build" -Script {
    az acr build --registry $acrName --image "$ImageName`:$ImageTag" $csharpDir | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "az acr build failed with exit code $LASTEXITCODE"
    }
}

Write-Step "Ensuring Container Apps environment exists"
$envExists = az containerapp env show --name $CustomEnvironmentName --resource-group $rg --query name -o tsv 2>$null
if ([string]::IsNullOrWhiteSpace($envExists)) {
    Invoke-TimedStep -Label "az containerapp env create" -Script {
        az containerapp env create --name $CustomEnvironmentName --resource-group $rg --location $Location | Out-Null
        if ($LASTEXITCODE -ne 0) {
            throw "az containerapp env create failed with exit code $LASTEXITCODE"
        }
    }
    Write-Host "Created environment: $CustomEnvironmentName"
}
else {
    Write-Host "Environment already exists: $CustomEnvironmentName"
}

Write-Step "Creating or reusing custom container session pool"
$poolExists = az containerapp sessionpool show --name $CustomSessionPoolName --resource-group $rg --query name -o tsv 2>$null
if (-not [string]::IsNullOrWhiteSpace($poolExists) -and $ForceRecreateCustomPool) {
    az containerapp sessionpool delete --name $CustomSessionPoolName --resource-group $rg --yes | Out-Null
    $poolExists = $null
    Write-Host "Deleted existing pool due to -ForceRecreateCustomPool: $CustomSessionPoolName"
}

if ([string]::IsNullOrWhiteSpace($poolExists)) {
    $acrUser = az acr credential show --name $acrName --resource-group $rg --query username -o tsv
    $acrPass = az acr credential show --name $acrName --resource-group $rg --query "passwords[0].value" -o tsv

    Invoke-TimedStep -Label "az containerapp sessionpool create" -Script {
        az containerapp sessionpool create `
            --name $CustomSessionPoolName `
            --resource-group $rg `
            --environment $CustomEnvironmentName `
            --container-type CustomContainer `
            --image "$acrServer/$ImageName`:$ImageTag" `
            --registry-server $acrServer `
            --registry-username $acrUser `
            --registry-password $acrPass `
            --target-port 8080 `
            --cpu 0.5 `
            --memory 1Gi `
            --max-sessions 20 `
            --ready-sessions 2 `
            --cooldown-period 300 `
            --network-status EgressDisabled `
            --location $Location | Out-Null
        if ($LASTEXITCODE -ne 0) {
            throw "az containerapp sessionpool create failed with exit code $LASTEXITCODE"
        }
    }

    Write-Host "Created custom session pool: $CustomSessionPoolName"
}
else {
    Write-Host "Custom session pool already exists: $CustomSessionPoolName"
}

Write-Step "Collecting endpoints"
$customPoolEndpoint = az containerapp sessionpool show --name $CustomSessionPoolName --resource-group $rg --query "properties.poolManagementEndpoint" -o tsv
$mcpApiKey = az rest --method POST `
    --uri "https://management.azure.com/subscriptions/$subscriptionId/resourceGroups/$rg/providers/Microsoft.App/sessionPools/$pythonPool/fetchMCPServerCredentials" `
    --uri-parameters api-version=2025-10-02-preview `
    --query apiKey -o tsv

Write-Step "Done"
Write-Host "Resource Group: $rg"
Write-Host "ACR Name: $acrName"
Write-Host "ACR Login Server: $acrServer"
Write-Host "Python MCP Pool: $pythonPool"
Write-Host "MCP Endpoint: $mcpEndpoint"
Write-Host "MCP API Key: $mcpApiKey"
Write-Host "Custom C# Pool: $CustomSessionPoolName"
Write-Host "Custom C# Pool Endpoint: $customPoolEndpoint"

Write-Host "`nSample custom pool execute URL:" -ForegroundColor Green
Write-Host "$customPoolEndpoint/execute?api-version=2025-10-02-preview&identifier=demo-session-001"
