# secure_code_exec Infrastructure Setup

This guide is automation-first and sets up everything needed to demo:

1. Python Dynamic Sessions with MCP enabled
1. Azure Container Registry for container images
1. Build and push the C# interpreter container image
1. Create a CustomContainer session pool pointing to that image

## What is provisioned

Terraform in `terraform/` creates:

1. Resource group
1. Azure Container Registry (ACR)
1. Python Dynamic Sessions pool with MCP enabled

Then Azure CLI commands create:

1. Container Apps environment (for custom session pools)
1. CustomContainer session pool using the C# interpreter image

## Prerequisites

1. Azure subscription with permission to create resources
1. Azure CLI
1. Terraform 1.6+
1. Docker Desktop or Docker Engine
1. PowerShell

## Before you run setup

Run these once per shell session before using either the one-command script or the manual steps:

```powershell
az login
az account set --subscription <subscription-id-or-name>
az account show
```

Notes:

1. The script runs `az login` if needed, but it uses whichever subscription is currently selected.
1. If you have multiple subscriptions, always run `az account set --subscription ...` first.

## One-command setup script

If you want the fastest setup path, run the automation script:

```powershell
.\scripts\setup-all.ps1 `
    -ResourceGroupName rg-dynsessions-demo `
    -Location eastus2 `
    -PythonSessionPoolName pymcppooldemo
```

Optional parameters:

1. `-AcrNamePrefix` to control ACR naming prefix
1. `-CustomEnvironmentName` to control the Container Apps environment name
1. `-CustomSessionPoolName` to control custom pool name
1. `-ImageName` and `-ImageTag` for image naming
1. `-SkipProviderRegistration` if Microsoft.App and containerapp extension are already configured
1. `-ForceRecreateCustomPool` to delete and recreate custom pool if it already exists

Session pool naming note:

1. Azure provider validation expects lowercase letters and numbers only for this resource name.
1. The script now auto-normalizes `-PythonSessionPoolName` to this format if needed.

The script performs all deployment/build steps and prints:

1. MCP endpoint and API key for the Python pool
1. Custom C# pool management endpoint
1. Ready-to-use execute URL for custom pool validation

Use the manual sections below only if you prefer to run each step yourself.

## One-time setup

```powershell
az login
$SUBSCRIPTION_ID = az account show --query id -o tsv
az account set --subscription $SUBSCRIPTION_ID
az provider register --namespace Microsoft.App
az extension add --name containerapp --allow-preview true --upgrade
```

## Automated deployment steps

Run these commands from the repository root.

### 1. Configure Terraform input values

```powershell
Copy-Item .\terraform\terraform.tfvars.example .\terraform\terraform.tfvars -Force
```

Edit `.\terraform\terraform.tfvars` and set at minimum:

1. `resource_group_name`
1. `location`
1. `session_pool_name`

### 2. Deploy base infrastructure with Terraform

```powershell
Set-Location .\terraform
terraform init
terraform apply -auto-approve
```

### 3. Capture Terraform outputs to variables

```powershell
$RG = terraform output -raw resource_group_name
$ACR_NAME = terraform output -raw acr_name
$ACR_SERVER = terraform output -raw acr_login_server
$PYTHON_POOL = terraform output -raw session_pool_name
$MCP_ENDPOINT = terraform output -raw mcp_server_endpoint
Set-Location ..
```

### 4. Build and push the C# interpreter image to ACR

```powershell
$IMAGE_NAME = "csharp-code-interpreter"
$IMAGE_TAG = "v1"

az acr build `
    --registry $ACR_NAME `
    --image "$IMAGE_NAME`:$IMAGE_TAG" `
    .\dotnet\CsharpCodeInterpreter
```

### 5. Create Container Apps environment for custom pools

```powershell
$LOCATION = az group show --name $RG --query location -o tsv
$CUSTOM_ENV = "acae-custom-sessions"

az containerapp env create `
    --name $CUSTOM_ENV `
    --resource-group $RG `
    --location $LOCATION
```

### 6. Create custom container session pool pointing to the pushed image

```powershell
$CUSTOM_POOL = "csharp-custom-pool"
$ACR_USER = az acr credential show --name $ACR_NAME --resource-group $RG --query username -o tsv
$ACR_PASS = az acr credential show --name $ACR_NAME --resource-group $RG --query "passwords[0].value" -o tsv

az containerapp sessionpool create `
    --name $CUSTOM_POOL `
    --resource-group $RG `
    --environment $CUSTOM_ENV `
    --container-type CustomContainer `
    --image "$ACR_SERVER/$IMAGE_NAME`:$IMAGE_TAG" `
    --registry-server $ACR_SERVER `
    --registry-username $ACR_USER `
    --registry-password $ACR_PASS `
    --target-port 8080 `
    --cpu 0.5 `
    --memory 1Gi `
    --max-sessions 20 `
    --ready-sessions 2 `
    --cooldown-period 300 `
    --network-status EgressDisabled `
    --location $LOCATION
```

### 7. Validate Python MCP endpoint

Get MCP API key:

```powershell
$SUBSCRIPTION_ID = az account show --query id -o tsv
$MCP_API_KEY = az rest --method POST `
    --uri "https://management.azure.com/subscriptions/$SUBSCRIPTION_ID/resourceGroups/$RG/providers/Microsoft.App/sessionPools/$PYTHON_POOL/fetchMCPServerCredentials" `
    --uri-parameters api-version=2025-10-02-preview `
    --query apiKey -o tsv
```

Initialize MCP server:

```powershell
curl -sS -X POST "$MCP_ENDPOINT" `
    -H "Content-Type: application/json" `
    -H "x-ms-apikey: $MCP_API_KEY" `
    -d '{ "jsonrpc": "2.0", "id": "1", "method": "initialize" }'
```

### 8. Validate custom C# session pool endpoint

```powershell
$CUSTOM_POOL_ENDPOINT = az containerapp sessionpool show `
    --name $CUSTOM_POOL `
    --resource-group $RG `
    --query "properties.poolManagementEndpoint" `
    --output tsv

$TOKEN = az account get-access-token --resource "https://dynamicsessions.io" --query accessToken -o tsv

$BODY = '{"properties":{"codeInputType":"inline","executionType":"synchronous","timeoutInSeconds":60,"language":"csharp","code":"Console.WriteLine(2+2);"}}'

curl -sS -X POST "$CUSTOM_POOL_ENDPOINT/execute?api-version=2025-10-02-preview&identifier=demo-session-001" `
    -H "Content-Type: application/json" `
    -H "Authorization: Bearer $TOKEN" `
    -d $BODY
```

## Teardown

Fastest cleanup is removing the whole resource group:

```powershell
az group delete --name $RG --yes --no-wait
```

Alternative cleanup using Terraform state:

```powershell
Set-Location .\terraform
terraform destroy -auto-approve
Set-Location ..
```

## Additional repo docs

1. `terraform/README.md` for Terraform-specific details
1. `dotnet/CsharpCodeInterpreter/README.md` for local container testing and API usage
