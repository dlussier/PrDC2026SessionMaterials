# Terraform: Python Dynamic Sessions + MCP + ACR

This folder provisions the core infrastructure for demonstrating Azure Container Apps Dynamic Sessions with MCP enabled for Python.

## Is this possible with Terraform?

Yes, currently possible via the `azapi` provider.

- `azurerm` creates common Azure resources (resource group, container registry).
- `azapi_resource` deploys `Microsoft.App/sessionPools@2025-10-02-preview` with `mcpServerSettings.isMCPServerEnabled = true`.

A first-class `azurerm_*` session pool resource is not required for this scenario.

## What gets created

- Resource group
- Azure Container Registry (Basic SKU)
- Python Dynamic Sessions pool (`containerType = PythonLTS`)
- MCP server enabled on the session pool

## Prerequisites

- Terraform 1.6+
- Azure CLI
- Access to an Azure subscription
- Microsoft.App resource provider registered

## Deploy

1. Sign in and select your subscription.

```powershell
az login
$SUBSCRIPTION_ID = az account show --query id -o tsv
az account set --subscription $SUBSCRIPTION_ID
az provider register --namespace Microsoft.App
```

1. Initialize variables.

```powershell
Set-Location .\terraform
Copy-Item .\terraform.tfvars.example .\terraform.tfvars
```

1. Review and apply.

```powershell
terraform init
terraform plan
terraform apply
```

## Get MCP endpoint and credentials

MCP endpoint is also available as Terraform output (`mcp_server_endpoint`).

```powershell
terraform output mcp_server_endpoint
```

Fetch MCP API key (required in `x-ms-apikey` header):

```powershell
$RG = terraform output -raw resource_group_name
$POOL = terraform output -raw session_pool_name
$SUBSCRIPTION_ID = az account show --query id -o tsv

$API_KEY = az rest --method POST `
  --uri "https://management.azure.com/subscriptions/$SUBSCRIPTION_ID/resourceGroups/$RG/providers/Microsoft.App/sessionPools/$POOL/fetchMCPServerCredentials" `
  --uri-parameters api-version=2025-10-02-preview `
  --query apiKey -o tsv

$API_KEY
```

## Initialize MCP server

```powershell
$MCP_ENDPOINT = terraform output -raw mcp_server_endpoint

curl -sS -X POST "$MCP_ENDPOINT" `
  -H "Content-Type: application/json" `
  -H "x-ms-apikey: $API_KEY" `
  -d '{ "jsonrpc": "2.0", "id": "1", "method": "initialize" }'
```

## Cleanup

```powershell
terraform destroy
```
