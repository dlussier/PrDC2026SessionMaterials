resource "azurerm_resource_group" "infra" {
  name     = var.resource_group_name
  location = var.location
}

resource "random_string" "acr_suffix" {
  length  = 6
  upper   = false
  special = false
  numeric = true
}

locals {
  acr_name = substr(lower(replace("${var.acr_name_prefix}${random_string.acr_suffix.result}", "-", "")), 0, 50)
}

resource "azurerm_container_registry" "acr" {
  name                = local.acr_name
  location            = azurerm_resource_group.infra.location
  resource_group_name = azurerm_resource_group.infra.name
  sku                 = "Basic"
  admin_enabled       = true
}

resource "azapi_resource" "python_session_pool" {
  type      = "Microsoft.App/sessionPools@2025-10-02-preview"
  name      = var.session_pool_name
  location  = azurerm_resource_group.infra.location
  parent_id = azurerm_resource_group.infra.id

  body = {
    properties = {
      poolManagementType = "Dynamic"
      containerType      = "PythonLTS"
      scaleConfiguration = {
        maxConcurrentSessions = var.max_concurrent_sessions
      }
      sessionNetworkConfiguration = {
        status = var.session_egress_status
      }
      dynamicPoolConfiguration = {
        lifecycleConfiguration = {
          lifecycleType            = "Timed"
          cooldownPeriodInSeconds  = var.cooldown_period_seconds
        }
      }
      mcpServerSettings = {
        isMcpServerEnabled = true
      }
    }
  }

  response_export_values = [
    "properties.poolManagementEndpoint",
    "properties.mcpServerSettings.mcpServerEndpoint"
  ]
}

locals {
  session_pool_response = can(jsondecode(azapi_resource.python_session_pool.output)) ? jsondecode(azapi_resource.python_session_pool.output) : azapi_resource.python_session_pool.output
}
