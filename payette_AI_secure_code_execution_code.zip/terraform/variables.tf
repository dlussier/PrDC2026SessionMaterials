variable "resource_group_name" {
  description = "Resource group name for the demo infrastructure."
  type        = string
}

variable "location" {
  description = "Azure region for all resources."
  type        = string
  default     = "eastus"
}

variable "session_pool_name" {
  description = "Name of the Azure Container Apps Dynamic Sessions pool."
  type        = string
}

variable "acr_name_prefix" {
  description = "Lowercase prefix used for Azure Container Registry name."
  type        = string
  default     = "acrdynsessions"
}

variable "max_concurrent_sessions" {
  description = "Maximum concurrent sessions for the Python pool."
  type        = number
  default     = 5
}

variable "cooldown_period_seconds" {
  description = "Idle cooldown in seconds for timed lifecycle."
  type        = number
  default     = 300
}

variable "session_egress_status" {
  description = "Session egress status: EgressEnabled or EgressDisabled."
  type        = string
  default     = "EgressEnabled"

  validation {
    condition     = contains(["EgressEnabled", "EgressDisabled"], var.session_egress_status)
    error_message = "session_egress_status must be either EgressEnabled or EgressDisabled."
  }
}
