output "resource_group_name" {
  description = "Resource group containing all resources."
  value       = azurerm_resource_group.infra.name
}

output "acr_name" {
  description = "Azure Container Registry name."
  value       = azurerm_container_registry.acr.name
}

output "acr_login_server" {
  description = "Azure Container Registry login server."
  value       = azurerm_container_registry.acr.login_server
}

output "session_pool_name" {
  description = "Dynamic Sessions Python pool name."
  value       = azapi_resource.python_session_pool.name
}

output "session_pool_management_endpoint" {
  description = "Dynamic Sessions management endpoint (Bearer token auth)."
  value       = try(local.session_pool_response.properties.poolManagementEndpoint, null)
}

output "mcp_server_endpoint" {
  description = "MCP server endpoint (x-ms-apikey auth)."
  value       = try(local.session_pool_response.properties.mcpServerSettings.mcpServerEndpoint, null)
}
