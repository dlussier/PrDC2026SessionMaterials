﻿using DotNetEnv;
using System.Text;
using Azure.Identity;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel.Connectors.OpenAI;
using Microsoft.SemanticKernel.Plugins.Core.CodeInterpreter;

#pragma warning disable SKEXP0050 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.

Env.Load("../../../../../.env");

var azureOpenAIEndpoint = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT");
var azureOpenAIKey = Environment.GetEnvironmentVariable("AZURE_OPENAI_API_KEY");
var azureOpenAIDeployment = "gpt-4o-mini";
var poolManagementEndpoint = Environment.GetEnvironmentVariable("POOL_MGMT_ENDPOINT");

// Session identifier for the dynamic session
var sessionId = "csharp-demo-123";

var builder = Kernel.CreateBuilder()
    .AddAzureOpenAIChatCompletion(azureOpenAIDeployment, azureOpenAIEndpoint, azureOpenAIKey);

// Cached token for the Azure Container Apps service
string? cachedToken = null;
ILogger logger = NullLogger.Instance;

/// <summary>
/// Acquire a token for the Azure Container Apps service
/// </summary>
async Task<string> TokenProvider(CancellationToken cancellationToken)
{
    if (cachedToken is null)
    {        
        string resource = "https://dynamicsessions.io/.default";
        var credential = new DefaultAzureCredential();

        // Attempt to get the token
        var accessToken = await credential.GetTokenAsync(new Azure.Core.TokenRequestContext([resource]), cancellationToken).ConfigureAwait(false);
        if (logger.IsEnabled(LogLevel.Information))
        {
            logger.LogInformation("Access token obtained successfully");
        }
        cachedToken = accessToken.Token;
    }

    return cachedToken;
}

var settings = new SessionsPythonSettings(
        sessionId: sessionId,
        endpoint: new Uri(poolManagementEndpoint));

Console.WriteLine("=== Code Interpreter With Azure Container Apps Plugin Demo ===\n");
Console.WriteLine("Start your conversation with the assistant. Type enter or an empty message to quit.");

builder.Services.AddLogging(loggingBuilder => loggingBuilder.AddConsole().SetMinimumLevel(LogLevel.Error));
builder.Services.AddHttpClient();
builder.Services.AddSingleton((sp)
    => new SessionsPythonPlugin(
        settings,
        sp.GetRequiredService<IHttpClientFactory>(),
        TokenProvider,
        sp.GetRequiredService<ILoggerFactory>()));
builder.Services.AddSingleton<IFunctionInvocationFilter, SemanticKernelCodeExec.TracingFilter>();

var kernel = builder.Build();
logger = kernel.GetRequiredService<ILoggerFactory>().CreateLogger<Program>();
kernel.Plugins.AddFromObject(kernel.GetRequiredService<SessionsPythonPlugin>());
var chatCompletion = kernel.GetRequiredService<IChatCompletionService>();

var chatHistory = new ChatHistory();

StringBuilder fullAssistantContent = new();

// Plot the graph of y=mx+b where m=4 and b=2, save the image as /mnt/data/graph.png

while (true)
{
    Console.Write("\nUser: ");
    var input = Console.ReadLine();
    if (string.IsNullOrWhiteSpace(input)) { break; }

    chatHistory.AddUserMessage(input);

    Console.WriteLine("Assistant: ");
    fullAssistantContent.Clear();
    await foreach (var content in chatCompletion.GetStreamingChatMessageContentsAsync(
        chatHistory,
        new OpenAIPromptExecutionSettings { FunctionChoiceBehavior = FunctionChoiceBehavior.Auto() },
        kernel)
        .ConfigureAwait(false))
    {
        Console.Write(content.Content);
        fullAssistantContent.Append(content.Content);
       
    }
    chatHistory.AddAssistantMessage(fullAssistantContent.ToString());
}

// After exiting the conversation, list files
var sessionsPlugin = kernel.GetRequiredService<SessionsPythonPlugin>();
var files = await sessionsPlugin.ListFilesAsync(); // Replace with actual method name
Console.WriteLine("\nFiles in the session:");
foreach (var file in files)
{
    Console.WriteLine(file.Name);
}



namespace SemanticKernelCodeExec
{
    public class TracingFilter : IFunctionInvocationFilter
    {
        public async Task OnFunctionInvocationAsync(FunctionInvocationContext context, Func<FunctionInvocationContext, Task> next)
        {
            Console.WriteLine($"Invoking function: {context.Function.Name} from plugin: {context.Function.PluginName}");
            Console.Write(context.Arguments.Values.First().ToString());

            await next(context);

            Console.WriteLine($"\nInvoked function: {context.Function.Name} from plugin: {context.Function.PluginName}\n\n");
        }
    }
}

