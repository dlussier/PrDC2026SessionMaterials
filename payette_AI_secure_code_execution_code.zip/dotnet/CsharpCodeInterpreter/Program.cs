using System.Text;
using System.Text.Json;
using CsharpCodeInterpreter.Models;
using Microsoft.CodeAnalysis.CSharp.Scripting;
using Microsoft.CodeAnalysis.Scripting;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddEndpointsApiExplorer();

var app = builder.Build();

string dataRoot = Environment.GetEnvironmentVariable("SESSION_DATA_ROOT") ?? "/mnt/data";
if (OperatingSystem.IsWindows() && dataRoot.Equals("/mnt/data", StringComparison.Ordinal))
{
	dataRoot = Path.Combine(AppContext.BaseDirectory, "session-data");
}

Directory.CreateDirectory(dataRoot);
Environment.SetEnvironmentVariable("SESSION_DATA_ROOT", dataRoot);

app.MapGet("/health", () => Results.Ok(new
{
	status = "healthy",
	message = "C# Dynamic Sessions container is ready"
}));

app.MapGet("/ready", () => Results.Ok(new
{
	status = "ready",
	dataRoot
}));

app.MapGet("/", () => Results.Ok(new
{
	message = "Azure Container Apps Dynamic Sessions C# executor",
	status = "healthy",
	endpoints = new
	{
		execute = "POST /execute",
		uploadFile = "POST /files",
		listFiles = "GET /files",
		getFileMetadata = "GET /files/{filename}",
		downloadFile = "GET /files/{filename}/content",
		health = "GET /health",
		ready = "GET /ready"
	}
}));

app.MapPost("/", ExecuteAsync);
app.MapPost("/execute", ExecuteAsync);

app.MapPost("/files", (HttpRequest request, CancellationToken cancellationToken)
	=> UploadFileAsync(request, cancellationToken, dataRoot));
app.MapGet("/files", () => ListFiles(dataRoot));
app.MapGet("/files/{filename}", (string filename) => GetFileMetadata(dataRoot, filename));
app.MapGet("/files/{filename}/content", (string filename) => DownloadFileContent(dataRoot, filename));

await app.RunAsync();

static async Task<IResult> ExecuteAsync(ExecutionRequest? request, CancellationToken cancellationToken)
{
	if (request is null)
	{
		return Results.BadRequest(new { error = "No JSON request body was provided." });
	}

	string code = request.Properties?.Code ?? request.Code ?? string.Empty;
	if (string.IsNullOrWhiteSpace(code))
	{
		return BadExecutionRequest("No code provided.", "No code provided.");
	}

	string language = request.Properties?.Language ?? request.Language ?? "csharp";
	if (!IsSupportedCSharpLanguage(language))
	{
		return BadExecutionRequest(
			$"Unsupported language '{language}'. Supported values: csharp, cs, dotnet-csharp.",
			$"Unsupported language '{language}'.");
	}

	int timeoutSeconds = Math.Clamp(request.Properties?.TimeoutInSeconds ?? request.TimeoutInSeconds ?? 60, 1, 220);
	return await ExecuteCodeCoreAsync(code, timeoutSeconds, cancellationToken);
}

static async Task<IResult> ExecuteCodeCoreAsync(string code, int timeoutSeconds, CancellationToken cancellationToken)
{
	var sw = System.Diagnostics.Stopwatch.StartNew();

	var stdOut = new StringBuilder();
	var stdErr = new StringBuilder();

	TextWriter originalOut = Console.Out;
	TextWriter originalErr = Console.Error;
	await using var outWriter = new StringWriter(stdOut);
	await using var errWriter = new StringWriter(stdErr);

	try
	{
		Console.SetOut(outWriter);
		Console.SetError(errWriter);

		using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
		timeoutCts.CancelAfter(TimeSpan.FromSeconds(timeoutSeconds));

		ScriptOptions options = ScriptOptions.Default
			.WithImports(
				"System",
				"System.IO",
				"System.Linq",
				"System.Collections.Generic",
				"System.Net.Http",
				"System.Text",
				"System.Text.Json",
				"System.Threading.Tasks")
			.WithReferences(
				typeof(object).Assembly,
				typeof(Console).Assembly,
				typeof(Enumerable).Assembly,
				typeof(HttpClient).Assembly,
				typeof(JsonSerializer).Assembly);

		ScriptState<object?> result = await CSharpScript.RunAsync(
			code,
			options,
			globals: null,
			cancellationToken: timeoutCts.Token);

		if (result.ReturnValue is not null)
		{
			stdOut.AppendLine(result.ReturnValue.ToString());
		}

		sw.Stop();
		return BuildExecutionResponse(
			ExecutionStatus.Success,
			stdOut.ToString(),
			stdErr.ToString(),
			0,
			sw.ElapsedMilliseconds);
	}
	catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
	{
		sw.Stop();
		return BuildExecutionResponse(
			ExecutionStatus.Failed,
			stdOut.ToString(),
			$"Execution timed out after {timeoutSeconds} seconds.",
			124,
			sw.ElapsedMilliseconds,
			StatusCodes.Status408RequestTimeout);
	}
	catch (CompilationErrorException ex)
	{
		sw.Stop();
		string compilationErrors = string.Join(Environment.NewLine, ex.Diagnostics.Select(d => d.ToString()));
		return BuildExecutionResponse(
			ExecutionStatus.Failed,
			stdOut.ToString(),
			compilationErrors,
			1,
			sw.ElapsedMilliseconds);
	}
	catch (Exception ex)
	{
		sw.Stop();
		return BuildExecutionResponse(
			ExecutionStatus.Failed,
			stdOut.ToString(),
			$"{ex.GetType().Name}: {ex.Message}{Environment.NewLine}{ex.StackTrace}",
			1,
			sw.ElapsedMilliseconds);
	}
	finally
	{
		Console.SetOut(originalOut);
		Console.SetError(originalErr);
	}
}

static IResult BuildExecutionResponse(
	string status,
	string stdout,
	string stderr,
	int returnCode,
	long executionTimeInMilliseconds,
	int? statusCode = null)
{
	var payload = new
	{
		properties = new
		{
			status,
			stdout,
			stderr,
			returnCode,
			executionResult = stdout,
			executionTimeInMilliseconds
		}
	};

	return statusCode.HasValue
		? Results.Json(payload, statusCode: statusCode.Value)
		: Results.Ok(payload);
}

static IResult BadExecutionRequest(string error, string stderr)
{
	return Results.BadRequest(new
	{
		error,
		properties = new
		{
			status = ExecutionStatus.Failed,
			stderr,
			returnCode = 1
		}
	});
}

static async Task<IResult> UploadFileAsync(HttpRequest request, CancellationToken cancellationToken, string dataRoot)
{
	if (!request.HasFormContentType)
	{
		return Results.BadRequest(new { error = "Content-Type must be multipart/form-data." });
	}

	IFormCollection form = await request.ReadFormAsync(cancellationToken);
	IFormFile? file = form.Files.FirstOrDefault();
	if (file is null || file.Length == 0)
	{
		return Results.BadRequest(new { error = "No file supplied." });
	}

	string safeFileName = Path.GetFileName(file.FileName);
	if (string.IsNullOrWhiteSpace(safeFileName))
	{
		return Results.BadRequest(new { error = "File name is required." });
	}

	string outputPath = ResolvePathUnderDataRoot(dataRoot, safeFileName);
	Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);

	await using (FileStream fs = File.Create(outputPath))
	{
		await file.CopyToAsync(fs, cancellationToken);
	}

	FileInfo info = new(outputPath);
	return Results.Ok(new
	{
		properties = new
		{
			filename = info.Name,
			size = info.Length,
			lastModifiedTime = info.LastWriteTimeUtc
		}
	});
}

static IResult ListFiles(string dataRoot)
{
	DirectoryInfo dir = new(dataRoot);
	var files = dir
		.EnumerateFiles("*", SearchOption.TopDirectoryOnly)
		.OrderBy(f => f.Name, StringComparer.OrdinalIgnoreCase)
		.Select(file => new
		{
			properties = new
			{
				filename = file.Name,
				size = file.Length,
				lastModifiedTime = file.LastWriteTimeUtc
			}
		});

	return Results.Ok(new { value = files });
}

static IResult GetFileMetadata(string dataRoot, string filename)
{
	try
	{
		string filePath = ResolvePathUnderDataRoot(dataRoot, filename);
		if (!File.Exists(filePath))
		{
			return Results.NotFound(new { error = $"File '{filename}' not found." });
		}

		FileInfo file = new(filePath);
		return Results.Ok(new
		{
			properties = new
			{
				filename = file.Name,
				size = file.Length,
				lastModifiedTime = file.LastWriteTimeUtc
			}
		});
	}
	catch (InvalidOperationException ex)
	{
		return Results.BadRequest(new { error = ex.Message });
	}
}

static IResult DownloadFileContent(string dataRoot, string filename)
{
	try
	{
		string filePath = ResolvePathUnderDataRoot(dataRoot, filename);
		if (!File.Exists(filePath))
		{
			return Results.NotFound(new { error = $"File '{filename}' not found." });
		}

		return Results.File(filePath, "application/octet-stream", Path.GetFileName(filePath));
	}
	catch (InvalidOperationException ex)
	{
		return Results.BadRequest(new { error = ex.Message });
	}
}

static bool IsSupportedCSharpLanguage(string language) =>
	language.Equals("csharp", StringComparison.OrdinalIgnoreCase)
	|| language.Equals("cs", StringComparison.OrdinalIgnoreCase)
	|| language.Equals("dotnet-csharp", StringComparison.OrdinalIgnoreCase)
	|| language.Equals("dotnet", StringComparison.OrdinalIgnoreCase);

static string ResolvePathUnderDataRoot(string dataRoot, string fileName)
{
	string safeName = fileName.Trim();
	if (string.IsNullOrWhiteSpace(safeName))
	{
		throw new InvalidOperationException("File name is required.");
	}

	string combined = Path.GetFullPath(Path.Combine(dataRoot, safeName));
	string normalizedRoot = Path.GetFullPath(dataRoot)
		.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)
		+ Path.DirectorySeparatorChar;

	if (!combined.StartsWith(normalizedRoot, StringComparison.OrdinalIgnoreCase))
	{
		throw new InvalidOperationException("Invalid file path.");
	}

	return combined;
}

namespace CsharpCodeInterpreter.Models
{
	internal static class ExecutionStatus
	{
		public const string Success = "Success";
		public const string Failed = "Failed";
	}

	internal sealed class ExecutionRequest
	{
		public ExecutionProperties? Properties { get; init; }
		public string? Code { get; init; }
		public string? Language { get; init; }
		public int? TimeoutInSeconds { get; init; }
	}

	internal sealed class ExecutionProperties
	{
		public string? CodeInputType { get; init; }
		public string? ExecutionType { get; init; }
		public int? TimeoutInSeconds { get; init; }
		public string? Code { get; init; }
		public string? Language { get; init; }
	}
}
