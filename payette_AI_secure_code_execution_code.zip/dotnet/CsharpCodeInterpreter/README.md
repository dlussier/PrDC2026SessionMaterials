# CsharpCodeInterpreter

Custom container for Azure Container Apps Dynamic Sessions that executes C# code and exposes session file APIs.

## What this container implements

- `POST /execute`: Executes C# code and returns Dynamic Sessions-style result payload.
- `POST /`: Alias for `/execute`.
- `POST /files`: Uploads a file (multipart form data, field name `file`) to the session data directory.
- `GET /files`: Lists files in the session data directory.
- `GET /files/{filename}`: Returns file metadata.
- `GET /files/{filename}/content`: Downloads file content.
- `GET /health`: Liveness probe endpoint.
- `GET /ready`: Startup/readiness probe endpoint.

By default files are stored in `/mnt/data` (or `SESSION_DATA_ROOT` if set).

## Local testing

### Prerequisites

- Docker
- PowerShell (examples below)

### Run locally with Docker (recommended)

1. Build the image:

```powershell
Set-Location .\dotnet\CsharpCodeInterpreter
docker build -t csharp-code-interpreter:local .
```

1. Run the container:

```powershell
docker run --rm -p 8080:8080 csharp-code-interpreter:local
```

1. Keep this terminal running while you execute Postman requests.

### Local Docker testing in Postman

These examples assume a Linux runtime/container and use `/mnt/data` as the session file path.

1. Open Postman and create a new collection named CsharpCodeInterpreter.
1. Add a collection variable named `LocalBaseUrl` with value `http://localhost:8080`.
1. Add the requests below.

#### Example 1: Execute C# code

- Method: POST
- URL: {{LocalBaseUrl}}/execute
- Headers:
  - Content-Type: application/json
- Body (raw JSON):

```json
{
  "properties": {
    "codeInputType": "inline",
    "executionType": "synchronous",
    "timeoutInSeconds": 60,
    "language": "csharp",
    "code": "var x = 21 * 2; Console.WriteLine($\"Answer: {x}\");"
  }
}
```

Expected result:

- HTTP 200
- Response body includes properties.status = Success
- Response body includes properties.stdout containing Answer: 42

#### Example 2: Create a file, list files, then download it

Step A: Create a file in the session with code execution

- Method: POST
- URL: {{LocalBaseUrl}}/execute
- Headers:
  - Content-Type: application/json
- Body (raw JSON):

```json
{
  "properties": {
    "codeInputType": "inline",
    "executionType": "synchronous",
    "timeoutInSeconds": 60,
    "language": "csharp",
    "code": "var path = \"/mnt/data/postman-demo.txt\"; Directory.CreateDirectory(\"/mnt/data\"); File.WriteAllText(path, \"hello from postman\"); Console.WriteLine($\"Created: {path}\");"
  }
}
```

Step B: Verify the file exists

- Method: GET
- URL: {{LocalBaseUrl}}/files

Expected result:

- HTTP 200
- Response value array contains postman-demo.txt

Step C: Download the file

- Method: GET
- URL: {{LocalBaseUrl}}/files/postman-demo.txt/content
- In Postman, select Send and Download to save the file locally.

Expected result:

- Downloaded file contains hello from postman

### Optional: Run without Docker

```powershell
dotnet run --project .\dotnet\CsharpCodeInterpreter\CsharpCodeInterpreter.csproj --urls http://localhost:8080
```

Use the same Postman requests above with `LocalBaseUrl=http://localhost:8080`.

## Deploy for Azure Container Apps Dynamic Sessions

### 1. Prerequisites

- Azure CLI (latest)
- Container Apps extension with preview features:

```powershell
az upgrade
az extension add --name containerapp --upgrade --allow-preview true -y
```

- An Azure subscription and permissions to create resources.
- A principal (user or managed identity) that will call the pool endpoint and has:
  - `Azure ContainerApps Session Executor`
  - `Azure ContainerApps Session Contributor`

### 2. Set deployment variables

```powershell
$Location = "eastus"
$ResourceGroup = "rg-csharp-dynsessions"
$EnvironmentName = "acae-csharp-dynsessions"
$AcrName = "acrcsharpdyn$(Get-Random -Maximum 99999)"
$ImageName = "csharp-interpreter"
$ImageTag = "v1"
$PoolName = "csharp-session-pool"
```

### 3. Create resource group, environment, and ACR

```powershell
az group create --name $ResourceGroup --location $Location

az containerapp env create `
  --name $EnvironmentName `
  --resource-group $ResourceGroup `
  --location $Location

az acr create `
  --name $AcrName `
  --resource-group $ResourceGroup `
  --location $Location `
  --sku Basic `
  --admin-enabled true
```

### 4. Build and push image to ACR

Run from `dotnet/CsharpCodeInterpreter`:

```powershell
az acr build `
  --registry $AcrName `
  --image "$ImageName`:$ImageTag" `
  .
```

### 5. Create the custom container session pool

```powershell
$AcrServer = az acr show --name $AcrName --resource-group $ResourceGroup --query loginServer -o tsv
$AcrUser = az acr credential show --name $AcrName --resource-group $ResourceGroup --query username -o tsv
$AcrPass = az acr credential show --name $AcrName --resource-group $ResourceGroup --query "passwords[0].value" -o tsv

az containerapp sessionpool create `
  --name $PoolName `
  --resource-group $ResourceGroup `
  --environment $EnvironmentName `
  --container-type CustomContainer `
  --image "$AcrServer/$ImageName`:$ImageTag" `
  --registry-server $AcrServer `
  --registry-username $AcrUser `
  --registry-password $AcrPass `
  --target-port 8080 `
  --cpu 0.5 `
  --memory 1Gi `
  --max-sessions 20 `
  --ready-sessions 2 `
  --cooldown-period 300 `
  --network-status EgressDisabled `
  --location $Location
```

### 6. Get the pool management endpoint

```powershell
$PoolEndpoint = az containerapp sessionpool show `
  --name $PoolName `
  --resource-group $ResourceGroup `
  --query "properties.poolManagementEndpoint" `
  --output tsv

$PoolEndpoint
```

### 7. Test execution against Dynamic Sessions endpoint (Postman)

Get a token in PowerShell (one-time per test session):

```powershell
$Token = az account get-access-token --resource "https://dynamicsessions.io" --query accessToken -o tsv
```

Note: this assignment command is silent in PowerShell and does not print the token.

Verify the token was captured:

```powershell
$Token.Length
```

Print the token so you can copy it for Postman:

```powershell
echo $Token
```

Optional: copy token directly to clipboard:

```powershell
$Token | Set-Clipboard
```

If needed, use this robust fallback parsing approach:

```powershell
$Token = (az account get-access-token --resource "https://dynamicsessions.io" -o json | ConvertFrom-Json).accessToken
$Token.Length
```

Set these Postman collection variables:

- `PoolEndpoint`: value from Step 6
- `ApiVersion`: `2025-10-02-preview`
- `SessionId`: `test-session-001`
- `Token`: paste the value from `$Token`

In Postman, create a request named Dynamic Session - Execute C#:

- Method: POST
- URL: {{PoolEndpoint}}/execute?api-version={{ApiVersion}}&identifier={{SessionId}}
- Authorization:
  - Type: Bearer Token
  - Token: {{Token}}
- Headers:
  - Content-Type: application/json
- Body (raw JSON):

```json
{
  "properties": {
    "codeInputType": "inline",
    "executionType": "synchronous",
    "timeoutInSeconds": 60,
    "language": "csharp",
    "code": "Console.WriteLine(DateTime.UtcNow.ToString(\"O\"));"
  }
}
```

Expected result:

- HTTP 200
- Response body includes properties.status = Success

### 8. (Optional) Validate file APIs through the session pool endpoint (Postman)

In Postman, create a request named Dynamic Session - List Files:

- Method: GET
- URL: {{PoolEndpoint}}/files?api-version={{ApiVersion}}&identifier={{SessionId}}
- Authorization:
  - Type: Bearer Token
  - Token: {{Token}}

Expected result:

- HTTP 200
- Response contains a value array with file metadata entries

### 9. (Optional) Test Python MCP endpoint authentication flow

This repo also provisions a Python Dynamic Sessions pool with MCP enabled (via root Terraform).

MCP uses API key authentication, not Bearer token authentication.

Get MCP endpoint and API key:

```powershell
$SubscriptionId = az account show --query id -o tsv
$ResourceGroup = "rg-codestock"
$PythonMcpPoolName = "pymcppooldemo"

$McpEndpoint = az containerapp sessionpool show `
  --name $PythonMcpPoolName `
  --resource-group $ResourceGroup `
  --query "properties.mcpServerSettings.mcpServerEndpoint" `
  -o tsv

$McpApiKey = az rest --method POST `
  --uri "https://management.azure.com/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup/providers/Microsoft.App/sessionPools/$PythonMcpPoolName/fetchMCPServerCredentials" `
  --uri-parameters api-version=2025-10-02-preview `
  --query apiKey -o tsv
```

In Postman, set collection variables:

- `MCPServerEndpoint` = `$McpEndpoint`
- `MCPApiKey` = `$McpApiKey`

Request: MCP - Initialize

- Method: POST
- URL: {{MCPServerEndpoint}}
- Headers:
  - Content-Type: application/json
  - x-ms-apikey: {{MCPApiKey}}
- Body:

```json
{
  "jsonrpc": "2.0",
  "id": "1",
  "method": "initialize"
}
```

Request: MCP - Tools List

- Method: POST
- URL: {{MCPServerEndpoint}}
- Headers:
  - Content-Type: application/json
  - x-ms-apikey: {{MCPApiKey}}
- Body:

```json
{
  "jsonrpc": "2.0",
  "id": "2",
  "method": "tools/list"
}
```

## Operational notes

- Use unique image tags when updating the container image, then update the session pool image.
- Keep `/health` and `/ready` endpoints fast and deterministic for session probe stability.
- Session identifiers are sensitive; your app must ensure each user can only access their own identifier.
