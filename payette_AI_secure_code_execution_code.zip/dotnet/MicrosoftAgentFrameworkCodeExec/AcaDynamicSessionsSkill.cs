using System.ComponentModel;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Azure.Core;
using Azure.Identity;

namespace MicrosoftAgentFrameworkCodeExec;

internal sealed class AcaDynamicSessionsSkill
{
	private readonly HttpClient _httpClient;
	private readonly string _poolManagementEndpoint;
	private readonly string _sessionIdentifier;
	private readonly string _apiVersion;
	private readonly int _executionTimeoutSeconds;
	private readonly string? _jwtToken;
	private readonly string _tokenAudience;
	private readonly DefaultAzureCredential _credential = new();
	private readonly SemaphoreSlim _tokenLock = new(1, 1);
	private AccessToken _cachedAccessToken;

	public AcaDynamicSessionsSkill(
		HttpClient httpClient,
		string poolManagementEndpoint,
		string sessionIdentifier,
		string apiVersion,
		int executionTimeoutSeconds,
		string? jwtToken,
		string tokenAudience)
	{
		_httpClient = httpClient;
		_poolManagementEndpoint = poolManagementEndpoint.TrimEnd('/');
		_sessionIdentifier = sessionIdentifier;
		_apiVersion = apiVersion;
		_executionTimeoutSeconds = Math.Clamp(executionTimeoutSeconds, 1, 220);
		_jwtToken = string.IsNullOrWhiteSpace(jwtToken) ? null : jwtToken;
		_tokenAudience = NormalizeTokenScope(tokenAudience);
	}

	[Description("Execute Python code in the current Azure Container Apps Dynamic Session and return output.")]
	public async Task<string> ExecutePythonAsync(
		[Description("Python code to execute.")] string code,
		CancellationToken cancellationToken = default)
	{
		if (string.IsNullOrWhiteSpace(code))
		{
			return "Code input is empty.";
		}

		string endpoint = BuildEndpoint("executions");
		// First try the documented shape. If the backend reports missing code in properties,
		// retry with a flat payload shape used by some endpoint variants.
		object[] payloads =
		[
			new
			{
				properties = new
				{
					codeInputType = "inline",
					executionType = "synchronous",
					timeoutInSeconds = _executionTimeoutSeconds,
					code
				}
			},
			new
			{
				codeInputType = "inline",
				executionType = "synchronous",
				timeoutInSeconds = _executionTimeoutSeconds,
				code
			}
		];

		for (int i = 0; i < payloads.Length; i++)
		{
			using var request = BuildJsonPostRequest(endpoint, payloads[i]);
			await ApplyAuthorizationAsync(request, cancellationToken).ConfigureAwait(false);
			using HttpResponseMessage response = await _httpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
			string body = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);

			if (response.IsSuccessStatusCode)
			{
				return FormatExecutionResponse(body);
			}

			bool hasAnotherShape = i < payloads.Length - 1;
			if (hasAnotherShape && ShouldRetryWithAlternateExecutionShape(response.StatusCode, body))
			{
				continue;
			}

			return $"Execution failed with {(int)response.StatusCode} {response.ReasonPhrase}. Body: {body}";
		}

		return "Execution failed after trying all payload shapes.";
	}

	[Description("List files available in the current Azure Container Apps Dynamic Session.")]
	public async Task<string> ListSessionFilesAsync(CancellationToken cancellationToken = default)
	{
		string endpoint = BuildEndpoint("files");
		using var request = new HttpRequestMessage(HttpMethod.Get, endpoint);
		request.Headers.Accept.ParseAdd("application/json");
		await ApplyAuthorizationAsync(request, cancellationToken).ConfigureAwait(false);

		using HttpResponseMessage response = await _httpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
		string body = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);

		if (!response.IsSuccessStatusCode)
		{
			return $"List files failed with {(int)response.StatusCode} {response.ReasonPhrase}. Body: {body}";
		}

		try
		{
			using JsonDocument doc = JsonDocument.Parse(body);
			if (!doc.RootElement.TryGetProperty("value", out JsonElement value) || value.ValueKind != JsonValueKind.Array)
			{
				return "No files found.";
			}

			List<string> filenames = [];
			foreach (JsonElement item in value.EnumerateArray())
			{
				string? filename = TryGetString(item, "properties", "name") ?? TryGetString(item, "name");
				if (!string.IsNullOrWhiteSpace(filename))
				{
					filenames.Add(filename);
				}
			}

			return filenames.Count == 0 ? "No files found." : string.Join(Environment.NewLine, filenames);
		}
		catch (JsonException)
		{
			return body;
		}
	}

	[Description("Upload a local file from this machine into the current Azure Container Apps Dynamic Session.")]
	public async Task<string> UploadLocalFileToSessionAsync(
		[Description("Path to a local file to upload.")] string localFilePath,
		[Description("Optional target filename in the session. If omitted, uses the source file name.")] string? sessionFileName = null,
		CancellationToken cancellationToken = default)
	{
		if (string.IsNullOrWhiteSpace(localFilePath))
		{
			return "localFilePath is required.";
		}

		if (!File.Exists(localFilePath))
		{
			return $"File not found: {localFilePath}";
		}

		string endpoint = BuildEndpoint("files");
		string fileName = string.IsNullOrWhiteSpace(sessionFileName)
			? Path.GetFileName(localFilePath)
			: sessionFileName.Trim();

		byte[] bytes = await File.ReadAllBytesAsync(localFilePath, cancellationToken).ConfigureAwait(false);

		using var fileContent = new ByteArrayContent(bytes);
		fileContent.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");

		using var multipart = new MultipartFormDataContent();
		multipart.Add(fileContent, "file", fileName);

		using var request = new HttpRequestMessage(HttpMethod.Post, endpoint)
		{
			Content = multipart
		};
		request.Headers.Accept.ParseAdd("application/json");

		await ApplyAuthorizationAsync(request, cancellationToken).ConfigureAwait(false);
		using HttpResponseMessage response = await _httpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
		string body = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);

		if (!response.IsSuccessStatusCode)
		{
			return $"Upload failed with {(int)response.StatusCode} {response.ReasonPhrase}. Body: {body}";
		}

		return string.IsNullOrWhiteSpace(body)
			? $"Uploaded '{fileName}' successfully."
			: $"Uploaded '{fileName}' successfully. Response: {body}";
	}

	[Description("Download a file from the current Azure Container Apps Dynamic Session to local disk.")]
	public async Task<string> DownloadSessionFileAsync(
		[Description("Filename in the session to download.")] string sessionFileName,
		[Description("Optional local output directory. Defaults to ./downloads.")] string? localOutputDirectory = null,
		CancellationToken cancellationToken = default)
	{
		if (string.IsNullOrWhiteSpace(sessionFileName))
		{
			return "sessionFileName is required.";
		}

		string safeFileName = sessionFileName.Trim();
		string encodedFileName = Uri.EscapeDataString(safeFileName);
		string endpoint = BuildEndpoint($"files/{encodedFileName}/content");

		using var request = new HttpRequestMessage(HttpMethod.Get, endpoint);
		await ApplyAuthorizationAsync(request, cancellationToken).ConfigureAwait(false);

		using HttpResponseMessage response = await _httpClient.SendAsync(request, cancellationToken).ConfigureAwait(false);
		if (!response.IsSuccessStatusCode)
		{
			string errorBody = await response.Content.ReadAsStringAsync(cancellationToken).ConfigureAwait(false);
			return $"Download failed with {(int)response.StatusCode} {response.ReasonPhrase}. Body: {errorBody}";
		}

		byte[] content = await response.Content.ReadAsByteArrayAsync(cancellationToken).ConfigureAwait(false);

		string outputDirectory = string.IsNullOrWhiteSpace(localOutputDirectory)
			? Path.Combine(Environment.CurrentDirectory, "downloads")
			: localOutputDirectory.Trim();

		Directory.CreateDirectory(outputDirectory);
		string outputPath = Path.Combine(outputDirectory, safeFileName);
		await File.WriteAllBytesAsync(outputPath, content, cancellationToken).ConfigureAwait(false);

		return $"Downloaded '{safeFileName}' to '{outputPath}'.";
	}

	private string BuildEndpoint(string relativePath)
	{
		string encodedIdentifier = Uri.EscapeDataString(_sessionIdentifier);
		return $"{_poolManagementEndpoint}/{relativePath}?api-version={_apiVersion}&identifier={encodedIdentifier}";
	}

	private static HttpRequestMessage BuildJsonPostRequest(string endpoint, object payload)
	{
		var request = new HttpRequestMessage(HttpMethod.Post, endpoint)
		{
			Content = new StringContent(
				JsonSerializer.Serialize(payload),
				Encoding.UTF8,
				"application/json")
		};

		request.Headers.Accept.ParseAdd("application/json");
		return request;
	}

	private async Task ApplyAuthorizationAsync(HttpRequestMessage request, CancellationToken cancellationToken)
	{
		if (_jwtToken is not null)
		{
			request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _jwtToken);
			return;
		}

		AccessToken accessToken = await GetAccessTokenAsync(cancellationToken).ConfigureAwait(false);
		request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken.Token);
	}

	private async Task<AccessToken> GetAccessTokenAsync(CancellationToken cancellationToken)
	{
		if (_cachedAccessToken.ExpiresOn > DateTimeOffset.UtcNow.AddMinutes(2))
		{
			return _cachedAccessToken;
		}

		await _tokenLock.WaitAsync(cancellationToken).ConfigureAwait(false);
		try
		{
			if (_cachedAccessToken.ExpiresOn > DateTimeOffset.UtcNow.AddMinutes(2))
			{
				return _cachedAccessToken;
			}

			_cachedAccessToken = await _credential
				.GetTokenAsync(new TokenRequestContext([_tokenAudience]), cancellationToken)
				.ConfigureAwait(false);

			return _cachedAccessToken;
		}
		finally
		{
			_tokenLock.Release();
		}
	}

	private static string NormalizeTokenScope(string tokenAudienceOrScope)
	{
		string value = tokenAudienceOrScope.Trim();
		if (value.EndsWith("/.default", StringComparison.OrdinalIgnoreCase))
		{
			return value;
		}

		return value.TrimEnd('/') + "/.default";
	}

	private static string FormatExecutionResponse(string json)
	{
		try
		{
			using JsonDocument doc = JsonDocument.Parse(json);
			JsonElement root = doc.RootElement;

			string? stdout = TryGetString(root, "properties", "stdout") ?? TryGetString(root, "stdout");
			string? stderr = TryGetString(root, "properties", "stderr") ?? TryGetString(root, "stderr");
			string? result = TryGetString(root, "properties", "result") ?? TryGetString(root, "result");
			string? returnCode = TryGetScalar(root, "properties", "returnCode") ?? TryGetScalar(root, "returnCode");

			List<string> lines = [];
			if (!string.IsNullOrWhiteSpace(stdout))
			{
				lines.Add($"stdout:\n{stdout}");
			}
			if (!string.IsNullOrWhiteSpace(stderr))
			{
				lines.Add($"stderr:\n{stderr}");
			}
			if (!string.IsNullOrWhiteSpace(result))
			{
				lines.Add($"result:\n{result}");
			}
			if (!string.IsNullOrWhiteSpace(returnCode))
			{
				lines.Add($"returnCode: {returnCode}");
			}

			return lines.Count == 0 ? json : string.Join("\n\n", lines);
		}
		catch (JsonException)
		{
			return json;
		}
	}

	private static bool ShouldRetryWithAlternateExecutionShape(HttpStatusCode statusCode, string body)
	{
		if (statusCode != HttpStatusCode.BadRequest)
		{
			return false;
		}

		try
		{
			using JsonDocument doc = JsonDocument.Parse(body);
			if (!doc.RootElement.TryGetProperty("error", out JsonElement error) || error.ValueKind != JsonValueKind.Object)
			{
				return false;
			}

			string? code = TryGetString(error, "code");
			string? message = TryGetString(error, "message");

			return string.Equals(code, "SessionPropertiesMissing", StringComparison.OrdinalIgnoreCase)
				&& !string.IsNullOrWhiteSpace(message)
				&& message.Contains("code", StringComparison.OrdinalIgnoreCase);
		}
		catch (JsonException)
		{
			return false;
		}
	}

	private static string? TryGetString(JsonElement element, params string[] path)
	{
		JsonElement current = element;
		foreach (string step in path)
		{
			if (current.ValueKind != JsonValueKind.Object || !current.TryGetProperty(step, out JsonElement next))
			{
				return null;
			}
			current = next;
		}

		return current.ValueKind == JsonValueKind.String ? current.GetString() : null;
	}

	private static string? TryGetScalar(JsonElement element, params string[] path)
	{
		JsonElement current = element;
		foreach (string step in path)
		{
			if (current.ValueKind != JsonValueKind.Object || !current.TryGetProperty(step, out JsonElement next))
			{
				return null;
			}
			current = next;
		}

		return current.ValueKind switch
		{
			JsonValueKind.Number => current.GetRawText(),
			JsonValueKind.String => current.GetString(),
			JsonValueKind.True => "true",
			JsonValueKind.False => "false",
			_ => null
		};
	}
}
