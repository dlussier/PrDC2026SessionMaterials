﻿using Azure;
using Azure.AI.OpenAI;
using DotNetEnv;
using MicrosoftAgentFrameworkCodeExec;
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.OpenAI;
using Microsoft.Extensions.AI;

string[] candidateEnvPaths =
[
	".env",
	Path.Combine("dotnet", "MicrosoftAgentFrameworkCodeExec", ".env"),
	Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "../../../../../.env"))
];

string? envPath = candidateEnvPaths.FirstOrDefault(File.Exists);
if (envPath is not null)
{
	Env.Load(envPath);
}

var azureOpenAIEndpoint = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")
	?? throw new InvalidOperationException("AZURE_OPENAI_ENDPOINT is not set.");
var azureOpenAIKey = Environment.GetEnvironmentVariable("AZURE_OPENAI_API_KEY")
	?? throw new InvalidOperationException("AZURE_OPENAI_API_KEY is not set.");
var azureOpenAIDeployment = Environment.GetEnvironmentVariable("AZURE_OPENAI_DEPLOYMENT_NAME") ?? "gpt-4o-mini";
var poolManagementEndpoint = Environment.GetEnvironmentVariable("POOL_MGMT_ENDPOINT")
	?? throw new InvalidOperationException("POOL_MGMT_ENDPOINT is not set.");
var sessionIdentifier = Environment.GetEnvironmentVariable("SESSION_ID") ?? "csharp-demo-123";
var sessionsApiVersion = Environment.GetEnvironmentVariable("SESSIONS_API_VERSION") ?? "2025-10-02-preview";
var executionTimeoutSeconds = int.TryParse(Environment.GetEnvironmentVariable("SESSIONS_EXECUTION_TIMEOUT_SECONDS"), out int timeout)
	? timeout
	: 220;

// Optional JWT forwarding for Dynamic Sessions management API.
var dynamicSessionsJwtToken = Environment.GetEnvironmentVariable("DYNAMIC_SESSIONS_JWT_TOKEN");
var dynamicSessionsTokenAudience = Environment.GetEnvironmentVariable("DYNAMIC_SESSIONS_TOKEN_AUDIENCE") ?? "https://dynamicsessions.io/.default";

using var httpClient = new HttpClient();
// Code execution can run up to 220 seconds; keep client timeout above that ceiling.
httpClient.Timeout = TimeSpan.FromSeconds(240);
var dynamicSessionsSkill = new AcaDynamicSessionsSkill(
	httpClient,
	poolManagementEndpoint,
	sessionIdentifier,
	sessionsApiVersion,
	executionTimeoutSeconds,
	dynamicSessionsJwtToken,
	dynamicSessionsTokenAudience);

List<AITool> tools =
[
	AIFunctionFactory.Create(dynamicSessionsSkill.ExecutePythonAsync),
	AIFunctionFactory.Create(dynamicSessionsSkill.ListSessionFilesAsync),
	AIFunctionFactory.Create(dynamicSessionsSkill.UploadLocalFileToSessionAsync),
	AIFunctionFactory.Create(dynamicSessionsSkill.DownloadSessionFileAsync)
];

var openAIClient = new AzureOpenAIClient(new Uri(azureOpenAIEndpoint), new AzureKeyCredential(azureOpenAIKey));
var chatClient = openAIClient.GetChatClient(azureOpenAIDeployment).AsIChatClient();

var instructions =
	"You are a helpful assistant with Python code execution capabilities. " +
	"Use tools to run code, inspect files, and produce grounded answers.";

AIAgent agent = chatClient.AsAIAgent(
	name: "MicrosoftAgentFrameworkCodeExec",
	instructions: instructions,
	tools: tools);

var session = await agent.CreateSessionAsync().ConfigureAwait(false);

Console.WriteLine("=== Microsoft Agent Framework Code Execution Demo ===\n");
Console.WriteLine($"Pool management endpoint: {poolManagementEndpoint}");
Console.WriteLine($"Session identifier: {sessionIdentifier}");
Console.WriteLine($"API version: {sessionsApiVersion}");
Console.WriteLine($"Execution timeout (seconds): {Math.Clamp(executionTimeoutSeconds, 1, 220)}");
Console.WriteLine("Start your conversation with the assistant. Type enter or an empty message to quit.");

while (true)
{
	Console.Write("\nUser: ");
	var input = Console.ReadLine();
	if (string.IsNullOrWhiteSpace(input))
	{
		break;
	}

	Console.WriteLine("Assistant:");

	await foreach (AgentResponseUpdate update in agent.RunStreamingAsync(input, session).ConfigureAwait(false))
	{
		var updateText = update.ToString();
		Console.Write(updateText);
	}

	Console.WriteLine();
}
