using System.Text.Json;
using System.Text.Json.Serialization;
using DiscoverAF.Demo1.ScopedContext;
using DiscoverAF.Shared;

namespace DiscoverAF.Demo3.Router;

public sealed record RouteDecision
{
    [JsonPropertyName("route")]
    public string Route { get; init; } = "";

    [JsonPropertyName("brief")]
    public string Brief { get; init; } = "";
}

public sealed class Demo3Pipeline(DemoConfig config) : IDemoPipeline
{
    public string Name => "3 — Router with Supervisor Fallback";

    public string Description => "A mini-model router selects a specialist or the supervisor for work spanning domains.";

    public async Task<string> RunAsync(string userMessage, DemoSession session, IProgress<TraceEvent> trace, CancellationToken ct)
    {
        if (!config.IsConfigured)
        {
            return DemoConfig.NotConfiguredMessage;
        }

        var router = AgentCatalog.CreateMiniAgent(
            config,
            "Router",
            "You are a router for Contoso Outfitters support. Classify the customer request into exactly one route: " +
            "'orders' (status/shipping/cancellation), 'returns' (returns/refunds/exchanges), " +
            "'product' (recommendations/sizing/stock), 'account' (address/payment/loyalty), or " +
            "'multi' when the request genuinely needs more than one of these. " +
            "Also extract the key facts (ids, budgets, sizes, new values) into a one-or-two-sentence task brief. " +
            "The customer is CUST-1001.",
            trace);

        var decision = (await router.RunAsync<RouteDecision>(userMessage, cancellationToken: ct)).Result;
        trace.Report(TraceEvent.Info("Router", $"route: {decision.Route}", JsonSerializer.Serialize(decision, new JsonSerializerOptions { WriteIndented = true })));

        var specialistName = decision.Route?.Trim().ToLowerInvariant() switch
        {
            "orders" => AgentCatalog.Orders,
            "returns" => AgentCatalog.Returns,
            "product" => AgentCatalog.Product,
            "account" => AgentCatalog.Account,
            _ => null,
        };

        if (specialistName is null)
        {
            trace.Report(TraceEvent.Info("Router", "multi-intent — falling through to the demo-1 orchestrator"));
            trace.Report(TraceEvent.Handoff("Router", "Orchestrator", userMessage));
            return await new Demo1Pipeline(config).RunAsync(userMessage, session, trace, ct);
        }

        trace.Report(TraceEvent.Handoff("Router", specialistName, decision.Brief));
        var specialist = AgentCatalog.CreateSpecialist(config, specialistName, trace);
        var response = await specialist.RunAsync(
            $"Customer request: {userMessage}\n\nRouter's task brief: {decision.Brief}",
            cancellationToken: ct);

        return response.Text;
    }
}
