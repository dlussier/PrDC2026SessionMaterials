using DiscoverAF.Host.Components;
using DiscoverAF.Shared;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;

internal static class ArchitectureRenderChecks
{
    public static async Task RunAsync(Action<bool, string> check)
    {
        await using var services = new ServiceCollection().AddLogging().AddSingleton<IJSRuntime, NoBrowserJs>().BuildServiceProvider();
        await using var renderer = new HtmlRenderer(services, services.GetRequiredService<ILoggerFactory>());
        var trace = new List<TraceEvent>
        {
            new() { Kind = TraceEventKind.RunStarted, Agent = "Customer", Title = "Customer request", Detail = "Find <script>unsafe</script> boots" },
            new() { Kind = TraceEventKind.PlanValidated, Agent = "Executor", Title = "validated", Steps = [new("a", "Product", "first", []), new("b", "Product", "second", [])] },
            new() { Kind = TraceEventKind.InvocationStarted, Agent = "Product", NodeId = "step:a", InvocationId = "a", Title = "first", Detail = "Brief A", FromNode = "Executor" },
            new() { Kind = TraceEventKind.InvocationStarted, Agent = "Product", NodeId = "step:b", InvocationId = "b", Title = "second", Detail = "Brief B", FromNode = "Executor" },
            new() { Kind = TraceEventKind.ModelCallStarted, Agent = "Product", NodeId = "step:a", InvocationId = "a", CallId = "a1", Title = "working" },
            new() { Kind = TraceEventKind.ModelCallStarted, Agent = "Product", NodeId = "step:b", InvocationId = "b", CallId = "b1", Title = "working" },
        };
        async Task<string> Render(string demo, IReadOnlyList<TraceEvent> events) => await renderer.Dispatcher.InvokeAsync(async () =>
        {
            var component = await renderer.RenderComponentAsync<ArchitectureView>(ParameterView.FromDictionary(new Dictionary<string, object?>
            { [nameof(ArchitectureView.DemoName)] = demo, [nameof(ArchitectureView.Events)] = events }));
            return component.ToHtmlString();
        });
        var html = await Render("4 — Planner", trace);
        check(html.Split("agent-node active").Length - 1 == 2 && html.Contains("step a") && html.Contains("step b"),
            "rendered graph highlights two separate same-named workers");
        check(html.Contains("Brief A") && html.Contains("Brief B") && html.IndexOf("Brief A", StringComparison.Ordinal) < html.IndexOf("Brief B", StringComparison.Ordinal),
            "rendered communication preserves chronological task briefs");
        check(!html.Contains("<script>unsafe</script>") && html.Contains("&lt;script&gt;"), "communication and customer request HTML-encode captured content");
        check(!html.Contains("Elapsed (whole run)"), "unfinished run does not display a completed duration");
        trace.Add(new() { Kind = TraceEventKind.RunCancelled, Agent = "host", Title = "cancelled", ElapsedMs = 1250 });
        html = await Render("4 — Planner", trace);
        check(!html.Contains("agent-node active") && html.Contains("Cancelled"), "rendered cancellation clears active graph styling");
        check(html.Contains("Elapsed (whole run): 1.25 s"), "cancelled run shows recorded wall-clock duration");
        trace.RemoveAt(trace.Count - 1);
        trace.Add(new() { Kind = TraceEventKind.RunCompleted, Agent = "host", Title = "done", ElapsedMs = 1600 });
        html = await Render("4 — Planner", trace);
        check(html.Contains("Elapsed (whole run): 1.60 s"), "completed run shows wall-clock duration independently of model-call totals");
        html = await Render("1 — Scoped", []);
        check(html.Contains("Orchestrator") && !html.Contains("Brief A") && !html.Contains("step a"), "new demo renders its own clean graph and communication");
        check(!html.Contains("Elapsed (whole run)"), "new demo does not inherit earlier elapsed time");
    }

    private sealed class NoBrowserJs : IJSRuntime
    {
        public ValueTask<TValue> InvokeAsync<TValue>(string identifier, object?[]? args) => throw new InvalidOperationException("No browser during server rendering");
        public ValueTask<TValue> InvokeAsync<TValue>(string identifier, CancellationToken cancellationToken, object?[]? args) => InvokeAsync<TValue>(identifier, args);
    }
}
