using DiscoverAF.Demo1.ScopedContext;
using DiscoverAF.Demo4.Planner;
using DiscoverAF.Shared;
using Microsoft.Extensions.AI;

internal static class ExperimentChecks
{
    public static async Task RunAsync(Action<bool, string> check)
    {
        var steps = new[] { new PlanStep { Id = "first" }, new PlanStep { Id = "second" } };
        var started = new List<string>();
        var releases = steps.ToDictionary(s => s.Id, _ => new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously));
        var parallel = Demo4Pipeline.ExecuteWaveAsync(steps, s => { started.Add(s.Id); return releases[s.Id].Task; }, true);
        check(started.SequenceEqual(new[] { "first", "second" }) && !parallel.IsCompleted,
            "parallel executor starts independent work before either result exists");
        releases["second"].SetResult("second result");
        releases["first"].SetResult("first result");
        check((await parallel).SequenceEqual(new[] { "first result", "second result" }),
            "parallel completion order cannot attach a result to the wrong plan step");
        started.Clear();
        var first = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
        var sequential = Demo4Pipeline.ExecuteWaveAsync(steps, s =>
        {
            started.Add(s.Id);
            return s.Id == "first" ? first.Task : Task.FromResult("second result");
        }, false);
        check(started.SequenceEqual(new[] { "first" }), "sequential comparator waits before starting the next ready step");
        first.SetResult("first result");
        check((await sequential).SequenceEqual(new[] { "first result", "second result" }), "both schedules preserve step/result mapping");
        var trace = new Sink();
        var names = GrowthPipeline.AvailableNames(6);
        var tools = names.SelectMany(n => GrowthPipeline.ToolsFor(n, trace)).OfType<AIFunction>().ToArray();
        check(tools.Length == 48 && tools.Select(t => t.Name).Distinct().Count() == 48,
            "growing registry has 48 distinct callable tools without replacing the original twelve");
        check(GrowthPipeline.ToolsFor("Account", trace).OfType<AIFunction>().Select(t => t.Name)
            .SequenceEqual(new ContosoTools(trace).AccountTools().OfType<AIFunction>().Select(t => t.Name)),
            "Account specialist retains only its original tools as business scope grows");
        var result = await tools.Single(t => t.Name == "ReadRentalAgreement").InvokeAsync(new AIFunctionArguments { ["query"] = "48213" });
        check(result?.ToString()?.Contains("No matching fixture record") == true &&
            result.ToString()!.Contains("\"ActionCompleted\":false"),
            "unrelated department lookups cannot fabricate completion of Alex's retail request");
    }
    private sealed class Sink : IProgress<TraceEvent> { public void Report(TraceEvent value) { } }
}
