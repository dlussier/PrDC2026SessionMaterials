using System.Runtime.CompilerServices;
using System.Text.Json;
using DiscoverAF.Demo2.TargetedHandoffs;
using DiscoverAF.Demo5.Memory;
using DiscoverAF.Shared;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Configuration;

internal static class EvidenceChecks
{
    public static async Task RunAsync(Action<bool, string> check)
    {
        var events = new List<TraceEvent>();
        var trace = new Capture(events.Add);
        var tools = new ContosoTools(trace);
        using var quote = JsonDocument.Parse(tools.QuoteProducts(["CO-1000", "CO-1001", "CO-1004"]));
        check(quote.RootElement.GetProperty("Total").GetDecimal() == 377.94m,
            "catalog quotes sum decimal prices from authoritative SKUs");
        using var badQuote = JsonDocument.Parse(tools.QuoteProducts(["CO-1000", "missing"]));
        check(badQuote.RootElement.TryGetProperty("Error", out _) && !badQuote.RootElement.TryGetProperty("Total", out _),
            "unknown SKU rejects the entire quote instead of returning a partial total");
        using var duplicateQuote = JsonDocument.Parse(tools.QuoteProducts(["CO-1000", "co-1000"]));
        check(duplicateQuote.RootElement.TryGetProperty("Error", out _), "duplicate SKUs cannot silently double a quote");

        foreach (var failTwice in new[] { false, true })
        {
            var composerCalls = 0;
            var specialistCalls = 0;
            var schemaRequests = 0;
            var client = new StubClient((messages, options) =>
            {
                if (options?.ResponseFormat is ChatResponseFormatJson { Schema: not null } &&
                    options.AdditionalProperties?.TryGetValue("strict", out var strict) == true && strict is true) schemaRequests++;
                if (options?.Instructions?.Contains("front-desk triage") == true)
                    return """{"target":"Returns","reason":"The customer requests a defect return."}""";
                if (options?.Instructions?.Contains("compress support conversations") == true)
                {
                    composerCalls++;
                    return composerCalls == 1 || failTwice
                        ? """{"type":"object","properties":{"intent":"return","customerId":"CUST-1001","orderId":"48213","relevantFacts":["boots are defective"],"openQuestion":"start return"}}"""
                        : """{"intent":"return","customerId":"CUST-1001","orderId":"48213","relevantFacts":["boots are defective"],"openQuestion":"start return"}""";
                }
                specialistCalls++;
                check(messages.Any(m => m.Text?.Contains("48213") == true), "repaired handoff delivers the actual order to the specialist");
                return "Specialist received the validated task.";
            });
            events.Clear();
            var threw = false;
            try { await new Demo2TargetedPipeline(Config(client)).RunAsync("Return defective boots from order #48213.", new(), trace, default); }
            catch (InvalidOperationException) { threw = true; }
            check(composerCalls == 2 && schemaRequests == 3, "triage and bounded handoff repair request actual JSON schemas");
            check(threw == failTwice && specialistCalls == (failTwice ? 0 : 1),
                failTwice ? "invalid handoff never reaches a specialist after bounded repair fails" : "schema wrapper is rejected and one valid repair can continue");
            check(events.Count(e => e.Kind == TraceEventKind.ModelCallMetered) == (failTwice ? 3 : 4),
                "validation retries remain included in model-call usage");
        }

        var selectionInputs = new List<string>();
        var memoryClient = new StubClient((messages, options) =>
        {
            if (options?.Instructions?.Contains("Decide whether this original customer message") == true)
            {
                selectionInputs.Add(string.Join("\n", messages.Select(m => m.Text)));
                return """{"remember":true}""";
            }
            if (options?.Instructions?.Contains("Compress this support-chat history") == true)
                return "Assistant suggested EU 44 and prefers cold conditions.";
            return "Assistant-only invention: customer prefers cold-at-night conditions and wears EU 44.";
        });
        var store = new MemoryStore();
        using var pipeline = new Demo5cPipeline(Config(memoryClient), store);
        var session = new DemoSession();
        const string original = "I run cold at night — is the pad warm enough?";
        await pipeline.RunAsync(original, session, trace, default);
        var saved = store.Facts.Single();
        check(saved.StartsWith("Customer said: ") && JsonSerializer.Deserialize<string>(saved[15..]) == original,
            "durable memory preserves the original customer's wording including cold sensitivity");
        check(selectionInputs.Single().Contains(original) && !selectionInputs.Single().Contains("Assistant-only invention"),
            "memory selection receives original customer input without the assistant's invented facts");

        selectionInputs.Clear();
        store.Facts.Clear();
        await pipeline.RunAsync(Scenario.AutoPlayCommand, new(), trace, default);
        var originals = store.Facts.Select(f => JsonSerializer.Deserialize<string>(f[15..])).ToArray();
        check(originals.SequenceEqual(Scenario.LongSessionScript),
            "autoplay supplies each original customer turn separately to durable memory selection");
        check(selectionInputs.Count == 20 && selectionInputs.All(i => !i.Contains("Assistant-only invention") && !i.Contains("Customer said:")),
            "neither assistant output nor recalled memory becomes new customer evidence across 20 turns");
    }

    private static DemoConfig Config(IChatClient client) => new(new ConfigurationBuilder().AddInMemoryCollection(
        new Dictionary<string, string?> { ["DiscoverAF:Endpoint"] = "https://evidence-test.invalid" }).Build(), _ => client);

    private sealed class MemoryStore : IFactStore
    {
        public List<string> Facts { get; private set; } = [];
        public string DisplayName => "isolated test memory";
        public Task<List<string>> LoadAsync(string customerId, CancellationToken ct) => Task.FromResult(Facts.ToList());
        public Task SaveAsync(string customerId, List<string> facts, CancellationToken ct) { Facts = facts.ToList(); return Task.CompletedTask; }
    }

    private sealed class StubClient(Func<List<ChatMessage>, ChatOptions?, string> respond) : IChatClient
    {
        public Task<ChatResponse> GetResponseAsync(IEnumerable<ChatMessage> messages, ChatOptions? options = null, CancellationToken cancellationToken = default) =>
            Task.FromResult(new ChatResponse(new ChatMessage(ChatRole.Assistant, respond(messages.ToList(), options)))
                { Usage = new UsageDetails { InputTokenCount = 50, OutputTokenCount = 10 } });
        public async IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(IEnumerable<ChatMessage> messages, ChatOptions? options = null,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            var response = await GetResponseAsync(messages, options, cancellationToken);
            foreach (var update in response.ToChatResponseUpdates()) yield return update;
        }
        public object? GetService(Type serviceType, object? serviceKey = null) => null;
        public void Dispose() { }
    }
}
