using System.Collections.Concurrent;
using System.Runtime.CompilerServices;
using DiscoverAF.Demo1.ScopedContext;
using DiscoverAF.Demo4.Planner;
using DiscoverAF.Shared;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Configuration;

internal static class ArchitectureChecks
{
    public static async Task RunAsync(Action<bool, string> check)
    {
        var state = new ArchitectureState("4 — Planner");
        state.Apply(new() { Kind = TraceEventKind.PlanEmitted, Agent = "Planner", Title = "unvalidated", Detail = "invalid" });
        check(!state.Nodes.Keys.Any(k => k.StartsWith("step:")), "unvalidated plans never create executable graph steps");
        state.Apply(new()
        {
            Kind = TraceEventKind.PlanValidated,
            Agent = "Executor",
            Title = "validated",
            Steps = [new("a", "Product", "A", []), new("b", "Product", "B", []), new("c", "Returns", "C", ["a"])]
        });
        check(state.Nodes["step:a"].Name == state.Nodes["step:b"].Name &&
              state.Edges.Any(e => e.From == "step:a" && e.To == "step:c") &&
              state.Nodes["step:c"].Level > state.Nodes["step:a"].Level, "same-named steps keep distinct identity and dependency levels");
        TraceEvent Event(TraceEventKind kind, string invocation, string? call = null) => new()
        {
            Kind = kind,
            Agent = "Product",
            NodeId = $"step:{invocation}",
            InvocationId = invocation,
            CallId = call,
            Title = "test",
            Detail = "actual payload",
        };
        state.Apply(Event(TraceEventKind.InvocationStarted, "a"));
        state.Apply(Event(TraceEventKind.InvocationStarted, "b"));
        state.Apply(Event(TraceEventKind.ModelCallStarted, "a", "a1"));
        state.Apply(Event(TraceEventKind.ModelCallStarted, "b", "b1"));
        check(state.Status("step:a") == "Model running" && state.Status("step:b") == "Model running", "concurrent workers highlight independently");
        state.Apply(Event(TraceEventKind.ModelCallCompleted, "a", "a1"));
        check(state.Status("step:a") == "Working" && state.Status("step:b") == "Model running", "model completion does not complete the agent invocation");
        state.Apply(Event(TraceEventKind.ToolCalled, "a") with { ToolCallId = "ta", ToolName = "SearchCatalog" });
        state.Apply(Event(TraceEventKind.ToolCalled, "b") with { ToolCallId = "tb", ToolName = "SearchCatalog" });
        state.Apply(Event(TraceEventKind.ToolResult, "b") with { ToolCallId = "tb", Detail = "result B" });
        state.Apply(Event(TraceEventKind.ToolResult, "a") with { ToolCallId = "ta", Detail = "result A" });
        check(state.Communication.First(i => i.Id == "a").Tools["ta"].Result == "result A" &&
              state.Communication.First(i => i.Id == "b").Tools["tb"].Result == "result B", "interleaved same-named tool results attach to the right worker");
        state.Apply(Event(TraceEventKind.InvocationCompleted, "a"));
        check(state.Status("step:a") == "Complete" && state.Status("step:b") == "Model running", "completed worker does not clear another worker's highlight");
        state.Apply(new() { Kind = TraceEventKind.RunCancelled, Agent = "host", Title = "cancelled" });
        check(!state.Nodes.Keys.Any(id => ArchitectureState.IsActive(state.Status(id))) && state.Status("step:b") == "Cancelled",
            "cancellation clears unfinished model and invocation activity");

        var parent = new ArchitectureState("1 — Scoped");
        parent.Apply(new() { Kind = TraceEventKind.InvocationStarted, Agent = "Orchestrator", InvocationId = "p", Title = "task" });
        parent.Apply(new() { Kind = TraceEventKind.InvocationStarted, Agent = "Returns", InvocationId = "c", ParentInvocationId = "p", Title = "task" });
        check(parent.Status("Orchestrator") == "Waiting for specialist", "supervisor waits while its child works");
        parent.Apply(new() { Kind = TraceEventKind.InvocationCompleted, Agent = "Returns", InvocationId = "c", Title = "done", FromNode = "Returns", ToNode = "Orchestrator" });
        check(parent.Edges.Any(e => e.From == "Returns" && e.To == "Orchestrator"), "completed delegation exposes the actual result-return direction");

        var history = new ArchitectureState("5b — Memory");
        history.Apply(new() { Kind = TraceEventKind.RunStarted, Agent = "Customer", Title = "run", Detail = "first request" });
        check(history.Request == "first request", "replay snapshot retains its current customer request");
        history.Apply(new() { Kind = TraceEventKind.ChatTurnStarted, Agent = "Customer", Title = "next turn", Detail = "next request" });
        check(history.Request == "next request", "autoplay request advances only when its recorded turn begins");

        var events = new ConcurrentQueue<TraceEvent>();
        var sink = new Capture(events.Enqueue);
        var config = new DemoConfig(new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string?>
        { ["DiscoverAF:Endpoint"] = "https://architecture-test.invalid" }).Build(), _ => new ArchitectureClient());
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        var reply = await new Demo4Pipeline(config).RunAsync("Compare two product tasks", new(), sink, timeout.Token);
        check(reply.Contains("finished"), "planner completes through real framework agents with deterministic model responses");
        var starts = events.Where(e => e.Kind == TraceEventKind.InvocationStarted && e.Agent == "Product").ToArray();
        check(starts.Length == 2 && starts.Select(e => e.InvocationId).Distinct().Count() == 2 &&
              starts.Select(e => e.NodeId).Distinct().Count() == 2, "planner emits unique invocation and node IDs for repeated specialists");
        var recorded = events.ToArray();
        var projected = new ArchitectureState("4 — Planner");
        var simultaneous = false;
        foreach (var evt in recorded)
        {
            projected.Apply(evt);
            simultaneous |= starts.All(s => ArchitectureState.IsActive(projected.Status(s.NodeId!)));
        }
        check(simultaneous, "real planner trace represents overlapping workers");
        check(starts.All(s => recorded.Any(e => e.Kind == TraceEventKind.PromptCaptured && e.InvocationId == s.InvocationId && e.NodeId == s.NodeId)),
            "worker prompt captures inherit exact invocation identity");
        check(projected.Communication.Where(i => i.IsInvocation).All(i => i.Status == "Complete"), "real planner lifecycle completes every scoped task");
        var replay = new ArchitectureState("4 — Planner");
        foreach (var evt in recorded) replay.Apply(evt);
        check(replay.InputTokens == projected.InputTokens && replay.Communication.Select(i => i.Output).SequenceEqual(projected.Communication.Select(i => i.Output)),
            "replay yields identical totals and communication to live event reduction");

        events.Clear();
        await new Demo1Pipeline(config).RunAsync("Find boots", new(), sink, timeout.Token);
        var child = events.Single(e => e.Kind == TraceEventKind.InvocationStarted && e.Agent == "Product");
        var supervisor = events.Single(e => e.Kind == TraceEventKind.InvocationStarted && e.Agent == "Orchestrator");
        check(child.ParentInvocationId == supervisor.InvocationId && child.FromNode == "Orchestrator", "real delegation records parent and sender without title parsing");
        check(events.Any(e => e.Kind == TraceEventKind.InvocationCompleted && e.InvocationId == child.InvocationId && e.ToNode == "Orchestrator"),
            "specialist result records its return destination");

        events.Clear();
        try
        {
            await InvocationTrace.RunAsync<string>(sink, "Product", "cancel test", _ => throw new OperationCanceledException(), s => s);
        }
        catch (OperationCanceledException) { }
        check(events.Last().Kind == TraceEventKind.InvocationFailed && events.Last().Cancelled, "scope records cancellation before propagating it");
    }

    private sealed class ArchitectureClient : IChatClient
    {
        public async Task<ChatResponse> GetResponseAsync(IEnumerable<ChatMessage> messages, ChatOptions? options = null, CancellationToken cancellationToken = default)
        {
            var instructions = options?.Instructions ?? "";
            ChatMessage result;
            if (instructions.Contains("decompose"))
                result = new(ChatRole.Assistant, """{"steps":[{"id":"a","agent":"Product","instruction":"Task A","dependsOn":[]},{"id":"b","agent":"Product","instruction":"Task B","dependsOn":[]}]}""");
            else if (instructions.Contains("support orchestrator") && !messages.Any(m => m.Contents.OfType<FunctionResultContent>().Any()))
                result = new(ChatRole.Assistant, [new FunctionCallContent("delegate", "ask_product_specialist", new Dictionary<string, object?> { ["taskBrief"] = "Find size 10 boots" })]);
            else { await Task.Delay(30, cancellationToken); result = new(ChatRole.Assistant, "Work finished"); }
            return new(result) { Usage = new() { InputTokenCount = 30, OutputTokenCount = 8 } };
        }
        public async IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(IEnumerable<ChatMessage> messages, ChatOptions? options = null,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            foreach (var update in (await GetResponseAsync(messages, options, cancellationToken)).ToChatResponseUpdates()) yield return update;
        }
        public object? GetService(Type serviceType, object? serviceKey = null) => null;
        public void Dispose() { }
    }
}
