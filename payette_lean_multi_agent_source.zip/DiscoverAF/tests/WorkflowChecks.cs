using System.Collections.Concurrent;
using System.Runtime.CompilerServices;
using DiscoverAF.Demo0.Baseline;
using DiscoverAF.Demo2.TargetedHandoffs;
using DiscoverAF.Shared;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Configuration;

internal static class WorkflowChecks
{
    public static async Task RunAsync(Action<bool, string> check)
    {
        var toolSets = new ConcurrentDictionary<string, string[]>();
        var config = new DemoConfig(new ConfigurationBuilder().AddInMemoryCollection(
            new Dictionary<string, string?> { ["DiscoverAF:Endpoint"] = "https://workflow-test.invalid" }).Build(),
            _ => new WorkflowClient(toolSets));
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        var events = new ConcurrentQueue<TraceEvent>();
        var trace = new Capture(events.Enqueue);
        var session = new DemoSession();
        var baseline = new Demo0Pipeline(config);
        var reply = await baseline.RunAsync("Find boots and update my address.", session, trace, timeout.Token);
        var calledAgents = events.Where(e => e.Kind == TraceEventKind.ModelCallMetered).Select(e => e.Agent).Distinct().ToArray();
        check(calledAgents.SequenceEqual(AgentCatalog.SpecialistNames), "baseline invokes all four specialists in order");
        var expectedTools = new Dictionary<string, string[]>
        {
            ["Orders"] = ["LookupOrder", "GetShipmentStatus", "CancelOrder"],
            ["Returns"] = ["StartReturn", "CheckReturnEligibility", "IssueRefund"],
            ["Product"] = ["SearchCatalog", "CheckInventory", "GetSizingChart"],
            ["Account"] = ["GetProfile", "UpdateAddress", "GetLoyaltyBalance"],
        };
        check(expectedTools.All(pair => toolSets.TryGetValue(pair.Key, out var actual) &&
            actual.Order().SequenceEqual(pair.Value.Order())), "baseline gives each specialist only its three domain tools");
        check(reply.Contains("Account completed") && session.Transcript.Any(m => m.Role == ChatRole.Assistant),
            "baseline returns and saves workflow output");
        check(events.Any(e => e.Agent == "Account" && e.Kind == TraceEventKind.PromptCaptured && e.Detail.Contains("EverTrail")),
            "baseline shares Product tool output with Account");
        events.Clear();
        await baseline.RunAsync("What is my address now?", session, trace, timeout.Token);
        check(events.Any(e => e.Agent == "Orders" && e.Kind == TraceEventKind.PromptCaptured && e.Detail.Contains("Account completed")),
            "baseline follow-up replays previous conversation");

        events.Clear();
        var monolithReply = await new MonolithPipeline(config).RunAsync("Find boots", new DemoSession(), trace, timeout.Token);
        check(events.Where(e => e.Kind == TraceEventKind.ModelCallMetered).All(e => e.Agent == "Monolith") &&
            monolithReply.Contains("Monolith completed"), "monolith executes one agent without specialist delegation");
        check(toolSets["Monolith"].Order().SequenceEqual(expectedTools.Values.SelectMany(v => v).Order()),
            "monolith receives exactly the union of the same 12 domain tools");
        check(AgentCatalog.SpecialistNames.All(name => MonolithPipeline.Instructions.Contains(AgentCatalog.InstructionsFor(name))),
            "monolith preserves every specialist domain instruction verbatim");
        check(events.Any(e => e.Agent == "Monolith" && e.Kind == TraceEventKind.ToolResult && e.Detail.Contains("EverTrail")),
            "monolith executes the same verbose catalog tool and captures its result");

        events.Clear();
        var handoffSession = new DemoSession();
        var handoffReply = await new Demo2NaivePipeline(config).RunAsync("Hello", handoffSession, trace, timeout.Token);
        check(events.Any(e => e.Kind == TraceEventKind.ModelCallMetered && e.Agent == "Triage"),
            "handoff workflow starts the triage agent");
        check(handoffReply.Contains("Triage completed") && handoffSession.Transcript.Count > 1,
            "handoff workflow returns and saves its reply");

        var failingConfig = new DemoConfig(new ConfigurationBuilder().AddInMemoryCollection(
            new Dictionary<string, string?> { ["DiscoverAF:Endpoint"] = "https://workflow-test.invalid" }).Build(),
            _ => new WorkflowClient(toolSets, fail: true));
        foreach (var pipeline in new IDemoPipeline[] { new Demo0Pipeline(failingConfig), new Demo2NaivePipeline(failingConfig) })
        {
            events.Clear();
            var failedSession = new DemoSession();
            var threw = false;
            try { await pipeline.RunAsync("Hello", failedSession, trace, timeout.Token); }
            catch (InvalidOperationException) { threw = true; }
            check(threw && events.Any(e => e.Kind == TraceEventKind.Error),
                $"{pipeline.Name} propagates executor failure instead of returning a completed reply");
            check(!failedSession.Transcript.Any(m => m.Role == ChatRole.Assistant),
                $"{pipeline.Name} does not save a fabricated assistant answer after failure");
        }
    }

    private sealed class WorkflowClient(ConcurrentDictionary<string, string[]> toolSets, bool fail = false) : IChatClient
    {
        public Task<ChatResponse> GetResponseAsync(IEnumerable<ChatMessage> messages, ChatOptions? options = null, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (fail) throw new InvalidOperationException("Simulated provider failure");
            var name = options?.Instructions?.StartsWith("You are the single Contoso") == true ? "Monolith" :
                AgentCatalog.SpecialistNames.FirstOrDefault(n => options?.Instructions?.Contains($"{n} specialist") == true) ?? "Triage";
            toolSets[name] = options?.Tools?.OfType<AIFunction>().Select(tool => tool.Name).ToArray() ?? [];
            var hasCatalog = messages.SelectMany(m => m.Contents).OfType<FunctionResultContent>().Any();
            var message = (name is "Product" or "Monolith") && !hasCatalog
                ? new ChatMessage(ChatRole.Assistant, [new FunctionCallContent("catalog-call", "SearchCatalog", new Dictionary<string, object?> { ["query"] = "boots" })])
                : new ChatMessage(ChatRole.Assistant, $"{name} completed");
            return Task.FromResult(new ChatResponse(message) { Usage = new UsageDetails { InputTokenCount = 50, OutputTokenCount = 5 } });
        }

        public async IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(IEnumerable<ChatMessage> messages, ChatOptions? options = null,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            var response = await GetResponseAsync(messages, options, cancellationToken);
            foreach (var update in response.ToChatResponseUpdates()) yield return update;
        }

        public object? GetService(Type serviceType, object? serviceKey = null) => null;
        public void Dispose() { }
    }
}
