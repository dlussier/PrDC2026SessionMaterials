using System.Globalization;
using DiscoverAF.Demo4.Planner;
using DiscoverAF.Demo5.Memory;
using DiscoverAF.Shared;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Configuration;
using SummarizingChatReducer = DiscoverAF.Demo5.Memory.SummarizingChatReducer;

var passed = 0;
void Check(bool condition, string name)
{
    if (!condition) throw new Exception($"FAIL: {name}");
    Console.WriteLine($"PASS: {name}");
    passed++;
}
void Reject(Plan plan, string name)
{
    try { PlanValidator.Validate(plan); }
    catch (InvalidOperationException) { Check(true, name); return; }
    throw new Exception($"FAIL: {name}");
}
PlanStep Step(string id, params string[] dependencies) => new()
    { Id = id, Agent = "Product", Instruction = "Check boot stock", DependsOn = dependencies };

PlanValidator.Validate(new Plan { Steps = [Step("a"), Step("b", "a"), Step("c")] });
Check(true, "valid parallel plan with dependency");
Reject(new Plan(), "empty plan rejected");
Reject(new Plan { Steps = [Step("a"), Step("a")] }, "duplicate ids rejected");
Reject(new Plan { Steps = [Step("a", "missing")] }, "missing dependency rejected");
Reject(new Plan { Steps = [Step("a", "b"), Step("b", "a")] }, "cycle rejected before execution");
Reject(new Plan { Steps = [Step("a") with { Agent = "Unknown" }] }, "unknown specialist rejected");
Reject(new Plan { Steps = [Step("a") with { DependsOn = null! }] }, "null dependencies rejected");

List<ChatMessage> history =
[
    new(ChatRole.System, "Keep this instruction"),
    new(ChatRole.User, "Find boots"),
    new(ChatRole.Assistant, [new FunctionCallContent("one", "Search", new Dictionary<string, object?>()),
        new FunctionCallContent("two", "Stock", new Dictionary<string, object?>())]),
    new(ChatRole.Tool, [new FunctionResultContent("one", "boots cost 149 USD")]),
    new(ChatRole.Tool, [new FunctionResultContent("two", "size 10 in stock")]),
    new(ChatRole.Assistant, "I found boots"),
    new(ChatRole.User, "Thank you"),
    new(ChatRole.Assistant, "You're welcome"),
];
var retained = (await new TruncatingChatReducer(6).ReduceAsync(history, default)).ToList();
Check(retained.Contains(history[2]) && retained.Contains(history[3]) && retained.Contains(history[4]),
    "truncation preserves parallel tool calls and results");
retained = (await new TruncatingChatReducer(2).ReduceAsync(history, default)).ToList();
Check(retained.Count == 3 && retained[0].Role == ChatRole.System && retained[1] == history[6],
    "truncation keeps system instructions and recent whole turn");
var fake = new FakeClient();
var reduced = (await new SummarizingChatReducer(fake, 2).ReduceAsync(history, default)).ToList();
Check(fake.LastInput.Contains("149 USD") && fake.LastInput.Contains("size 10 in stock"),
    "summary includes function results, not just message text");
Check(reduced.Count == 4 && reduced[0].Role == ChatRole.System && reduced[2] == history[6],
    "summary preserves instructions and recent turn");

var events = new List<TraceEvent>();
var trace = new Capture(events.Add);
var tools = new ContosoTools(trace);
using (var meter = new MeteredChatClient(fake, "Test", "fake", new ModelPricing(1, 2), trace))
{
    await meter.GetResponseAsync(history, new ChatOptions { Instructions = "Follow the policy", Tools = tools.ProductTools() });
    var prompt = events.Last(e => e.Kind == TraceEventKind.PromptCaptured).Detail;
    var measured = events.Last(e => e.Kind == TraceEventKind.ModelCallMetered);
    Check(prompt.Contains("properties") && prompt.Contains("query") && prompt.Contains("149 USD"),
        "inspector includes tool schemas and results");
    Check(measured.UsageEstimated && measured.InputTokens >= prompt.Length / 4,
        "fallback usage counts full rendered context and labels estimates");
    fake.Usage = new UsageDetails { InputTokenCount = 123, OutputTokenCount = 7 };
    await meter.GetResponseAsync(history);
    measured = events.Last(e => e.Kind == TraceEventKind.ModelCallMetered);
    Check(!measured.UsageEstimated && measured.InputTokens == 123 && measured.OutputTokens == 7,
        "provider usage takes precedence over estimates");
}

var directory = Path.Combine(Path.GetTempPath(), "DiscoverAF-tests-" + Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(directory);
try
{
    var path = Path.Combine(directory, "scoreboard.json");
    var board = new Scoreboard(path);
    Parallel.For(0, 40, _ => board.Record("demo", TraceEvent.Metered("a", "m", 10, 2, .01m, 1)));
    Check(new Scoreboard(path).Totals["demo"].InputTokens == 400, "parallel metering persists consistent totals");
    var snapshot = board.Totals;
    board.ResetAll();
    Check(snapshot["demo"].ModelCalls == 40 && board.Totals.Count == 0, "scoreboard snapshots survive reset");
    var blockedBoard = new Scoreboard(Path.Combine(directory, "missing", "scoreboard.json"));
    blockedBoard.Record("demo", TraceEvent.Metered("a", "m", 1, 1, 0, 1));
    Check(blockedBoard.Totals.Count == 1 && blockedBoard.PersistenceError is not null,
        "persistence failure preserves live totals with a visible error");
    var store = new JsonFileFactStore(Path.Combine(directory, "memory.json"));
    await store.SaveAsync(ContosoData.Profile.CustomerId, ["Size 10; waterproof boots"], default);
    await store.SaveAsync("another-customer", ["Keep this preference"], default);
    using (var memoryDemo = new Demo5cPipeline(new DemoConfig(new ConfigurationBuilder().Build()), store))
    {
        await memoryDemo.ResetMemoryAsync();
        await memoryDemo.ResetMemoryAsync();
    }
    var reopenedStore = new JsonFileFactStore(Path.Combine(directory, "memory.json"));
    Check((await reopenedStore.LoadAsync(ContosoData.Profile.CustomerId, default)).Count == 0,
        "5c rehearsal reset persists empty facts and can be repeated");
    Check((await reopenedStore.LoadAsync("another-customer", default)).Single() == "Keep this preference",
        "5c rehearsal reset preserves other customers");
    var backupStore = new JsonFileFactStore(Path.Combine(directory, "backup-source.json"));
    await backupStore.SaveAsync(ContosoData.Profile.CustomerId, ["Size 10", "Prefers waterproof"], default);
    try
    {
        using var backupDemo = new Demo5cPipeline(new DemoConfig(new ConfigurationBuilder().Build()), backupStore);
        Check(await backupDemo.BackUpMemoryAsync() == 2, "backup reports the fact count it snapshotted");
        await backupDemo.ResetMemoryAsync();
        Check((await backupStore.LoadAsync(ContosoData.Profile.CustomerId, default)).Count == 0,
            "reset empties the live store after a backup");
        Check(await backupDemo.RestoreMemoryAsync() == 2, "restore reports the fact count it put back");
        Check((await backupStore.LoadAsync(ContosoData.Profile.CustomerId, default))
            .SequenceEqual(new[] { "Size 10", "Prefers waterproof" }),
            "restore returns the exact stored statements in order");
    }
    finally
    {
        if (File.Exists(Demo5cPipeline.BackupPath)) File.Delete(Demo5cPipeline.BackupPath);
    }
    await Task.WhenAll(Enumerable.Range(0, 10).Select(i => Task.Run(() => store.SaveAsync($"customer-{i}", [$"fact {i}"], default))));
    Check((await store.LoadAsync("customer-0", default)).Single() == "fact 0" &&
          (await store.LoadAsync("customer-9", default)).Single() == "fact 9", "concurrent file saves preserve other customers");
}
finally
{
    foreach (var file in Directory.GetFiles(directory)) File.Delete(file);
    Directory.Delete(directory);
}

var originalCulture = CultureInfo.CurrentCulture;
try
{
    CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("fr-FR");
    var config = new DemoConfig(new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string?>
    {
        ["DiscoverAF:Pricing:test:InputPerMillion"] = "1.25",
        ["DiscoverAF:Pricing:test:OutputPerMillion"] = "10.00",
    }).Build());
    Check(config.PricingFor("test").InputPerMillion == 1.25m, "pricing parses consistently across locales");
}
finally { CultureInfo.CurrentCulture = originalCulture; }

Check(tools.CancelOrder("48610").Contains("can no longer") && ContosoData.FindOrder("48610")!.Status == "In transit",
    "shipped order cannot be cancelled");
Check(tools.CheckReturnEligibility("48213").Contains("outside"), "old order does not falsely claim standard eligibility");
Check(tools.StartReturn("48213", "changed my mind").Contains("Outside"), "expired non-defect return rejected");
tools.StartReturn("48213", "falling apart", true);
tools.StartReturn("#48213", "falling apart", true);
Check(ContosoData.Returns.Count == 1, "defect return is eligible and retry is idempotent");
var returnId = ContosoData.Returns.Single().ReturnId;
tools.IssueRefund(returnId);
Check(tools.IssueRefund(returnId).Contains("already"), "refund retry does not issue a second refund");

ContosoData.UpdateAddress("999 Elsewhere Ave, Denver, CO 80202");
ContosoData.Orders[0].Status = "Cancelled";
ContosoData.ResetFixtures();
Check(ContosoData.Returns.Count == 0, "reset clears started returns");
Check(ContosoData.Profile.ShippingAddress == "17 Juniper Lane, Boulder, CO 80301",
    "reset restores the seed shipping address");
Check(ContosoData.Orders[0].Status == "Delivered", "reset restores the original order status");
tools.StartReturn("48213", "falling apart", true);
Check(ContosoData.Returns.Single().ReturnId == "RET-9000",
    "reset restores RET-9000 numbering for the next demo");
ContosoData.ResetFixtures();
Check(ContosoData.Returns.Count == 0, "reset is repeatable across a rehearsal");

await WorkflowChecks.RunAsync(Check);
await ExperimentChecks.RunAsync(Check);
await ArchitectureChecks.RunAsync(Check);
await ArchitectureRenderChecks.RunAsync(Check);
await EvidenceChecks.RunAsync(Check);
Console.WriteLine($"All {passed} regression checks passed.");

sealed class Capture(Action<TraceEvent> capture) : IProgress<TraceEvent>
{
    public void Report(TraceEvent value) => capture(value);
}

sealed class FakeClient : IChatClient
{
    public string LastInput { get; private set; } = "";
    public UsageDetails? Usage { get; set; }
    public Task<ChatResponse> GetResponseAsync(IEnumerable<ChatMessage> messages, ChatOptions? options = null, CancellationToken cancellationToken = default)
    {
        LastInput = string.Join("\n", messages.Select(m => m.Text));
        return Task.FromResult(new ChatResponse(new ChatMessage(ChatRole.Assistant, "Customer wants boots, size 10, 149 USD.")) { Usage = Usage });
    }
    public IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(IEnumerable<ChatMessage> messages, ChatOptions? options = null, CancellationToken cancellationToken = default) =>
        throw new NotSupportedException();
    public object? GetService(Type serviceType, object? serviceKey = null) => null;
    public void Dispose() { }
}
