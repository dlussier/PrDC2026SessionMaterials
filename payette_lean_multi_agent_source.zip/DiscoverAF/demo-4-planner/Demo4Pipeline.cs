using System.Text.Json;
using System.Text.Json.Serialization;
using DiscoverAF.Shared;

namespace DiscoverAF.Demo4.Planner;

public sealed record PlanStep
{
    [JsonPropertyName("id")]
    public string Id { get; init; } = "";

    [JsonPropertyName("agent")]
    public string Agent { get; init; } = "";

    [JsonPropertyName("instruction")]
    public string Instruction { get; init; } = "";

    [JsonPropertyName("dependsOn")]
    public string[] DependsOn { get; init; } = [];
}

public sealed record Plan
{
    [JsonPropertyName("steps")]
    public PlanStep[] Steps { get; init; } = [];
}

public sealed class Demo4Pipeline(DemoConfig config) : IDemoPipeline
{
    private static readonly JsonSerializerOptions PrettyJson = new() { WriteIndented = true };

    public string Name => "4 — Plan-and-Execute";

    public string Description => "A planner proposes tasks; code validates dependencies and runs ready steps together.";

    public async Task<string> RunAsync(string userMessage, DemoSession session, IProgress<TraceEvent> trace, CancellationToken ct)
    {
        if (!config.IsConfigured)
        {
            return DemoConfig.NotConfiguredMessage;
        }

        var plan = await CreatePlanAsync(userMessage, trace, ct);
        return await ExecutePlanAsync(plan, userMessage, trace, ct);
    }

    public async Task<Plan> CreatePlanAsync(string userMessage, IProgress<TraceEvent> trace, CancellationToken ct)
    {
        return await InvocationTrace.RunAsync(trace, "Planner", userMessage, async scope =>
        {
            var planner = AgentCatalog.CreateFrontierAgent(
                config,
                "Planner",
                "You decompose Contoso Outfitters support requests into an execution plan for specialist agents " +
                $"({string.Join(", ", AgentCatalog.SpecialistNames)}). Each step gets a short self-contained instruction " +
                "with every id/constraint it needs. Preserve customer-reported reasons and requested actions, not only task topics. " +
                "For a return, carry the customer's defect description verbatim into the Returns instruction, together with the order id. " +
                "When the customer asks to return an item, instruct Returns to check eligibility and START the eligible return, " +
                "then report the actual return id. Do not turn an action request into eligibility advice, options, or a request " +
                "for facts already supplied. Preserve the replacement budget, size and stock requirement, and the exact new address. " +
                "Before emitting the plan, check every step against the original request for missing facts or unfinished actions. " +
                "Steps only depend on another step when they truly need its output — " +
                "independent steps run in parallel. The customer is CUST-1001 (Alex Rivera).",
                scope);

            return (await planner.RunAsync<Plan>($"Customer request: {userMessage}", cancellationToken: ct)).Result;
        }, value => JsonSerializer.Serialize(value, PrettyJson), from: "Customer", to: "Executor");
    }

    public async Task<string> ExecutePlanAsync(Plan plan, string userMessage, IProgress<TraceEvent> trace,
        CancellationToken ct, bool parallel = true)
    {
        trace.Report(TraceEvent.Plan("Planner", JsonSerializer.Serialize(plan, PrettyJson)));
        PlanValidator.Validate(plan);
        trace.Report(new TraceEvent
        {
            Kind = TraceEventKind.PlanValidated,
            Agent = "Executor",
            Title = "plan validated",
            Detail = JsonSerializer.Serialize(plan, PrettyJson),
            Steps = plan.Steps.Select(s => new ArchitectureStep(s.Id, s.Agent, s.Instruction, s.DependsOn)).ToArray()
        });

        var results = new Dictionary<string, string>();
        var remaining = plan.Steps.ToList();

        while (remaining.Count > 0)
        {
            var wave = remaining.Where(s => s.DependsOn.All(results.ContainsKey)).ToList();
            if (wave.Count == 0)
            {
                trace.Report(TraceEvent.Error("Planner", "plan has unsatisfiable dependencies", string.Join(", ", remaining.Select(s => s.Id))));
                throw new InvalidOperationException("The plan has unsatisfiable dependencies.");
            }

            trace.Report(TraceEvent.Info("Executor", $"running {wave.Count} ready step(s) {(parallel ? "in parallel" : "sequentially")}: {string.Join(", ", wave.Select(s => s.Id))}"));
            var waveResults = await ExecuteWaveAsync(wave,
                step => RunStepAsync(step, results, trace, ct), parallel);

            foreach (var (step, output) in wave.Zip(waveResults))
            {
                results[step.Id] = output;
                remaining.Remove(step);
            }
        }

        var summaryInput =
            $"Customer request: {userMessage}\n\nCompleted work:\n" +
            string.Join("\n\n", results.Select(kv => $"[{kv.Key}]\n{kv.Value}"));
        return await InvocationTrace.RunAsync(trace, "Aggregator", summaryInput, async scope =>
        {
            var aggregator = AgentCatalog.CreateMiniAgent(
                config,
                "Aggregator",
                "You write the final customer-facing reply for Contoso Outfitters support from completed work items. " +
                "Be warm, concise, and cover every item.",
                scope);

            var reply = await aggregator.RunAsync(summaryInput, cancellationToken: ct);
            return reply.Text;
        }, value => value, from: "Executor", to: "Customer");
    }

    public static async Task<string[]> ExecuteWaveAsync(IReadOnlyList<PlanStep> wave,
        Func<PlanStep, Task<string>> run, bool parallel)
    {
        if (parallel) return await Task.WhenAll(wave.Select(run));
        var outputs = new List<string>();
        foreach (var step in wave) outputs.Add(await run(step));
        return outputs.ToArray();
    }

    private async Task<string> RunStepAsync(
        PlanStep step, Dictionary<string, string> results, IProgress<TraceEvent> trace, CancellationToken ct)
    {
        var specialistName = AgentCatalog.SpecialistNames.FirstOrDefault(
            name => name.Equals(step.Agent, StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException($"Unknown specialist '{step.Agent}'.");

        var input = step.Instruction;
        if (step.DependsOn.Length > 0)
        {
            input += "\n\nOutputs from prerequisite steps:\n" +
                     string.Join("\n\n", step.DependsOn.Select(id => $"[{id}]\n{results[id]}"));
        }

        return await InvocationTrace.RunAsync(trace, specialistName, input, async scope =>
        {
            var specialist = AgentCatalog.CreateSpecialist(config, specialistName, scope);
            return (await specialist.RunAsync(input, cancellationToken: ct)).Text;
        }, value => value, nodeId: $"step:{step.Id}", from: "Executor", to: "Executor");
    }
}
