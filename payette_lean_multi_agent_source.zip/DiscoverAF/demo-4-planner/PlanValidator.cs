using DiscoverAF.Shared;

namespace DiscoverAF.Demo4.Planner;

public static class PlanValidator
{
    public static void Validate(Plan plan)
    {
        if (plan.Steps is not { Length: > 0 and <= 12 })
            throw new InvalidOperationException("The planner must return between 1 and 12 steps.");

        var steps = new Dictionary<string, PlanStep>(StringComparer.Ordinal);
        foreach (var step in plan.Steps)
        {
            if (step is null || string.IsNullOrWhiteSpace(step.Id) ||
                string.IsNullOrWhiteSpace(step.Instruction) || step.DependsOn is null)
                throw new InvalidOperationException("Every plan step needs an id, instruction, and dependency list.");
            if (!steps.TryAdd(step.Id, step))
                throw new InvalidOperationException($"Duplicate plan step id '{step.Id}'.");
            if (!AgentCatalog.SpecialistNames.Contains(step.Agent, StringComparer.OrdinalIgnoreCase))
                throw new InvalidOperationException($"Unknown specialist '{step.Agent}' in step '{step.Id}'.");
        }

        foreach (var step in steps.Values)
            if (step.DependsOn.Any(id => id is null || !steps.ContainsKey(id)))
                throw new InvalidOperationException($"Step '{step.Id}' references an unknown dependency.");

        var completed = new HashSet<string>(StringComparer.Ordinal);
        while (completed.Count < steps.Count)
        {
            var ready = steps.Values.Where(s => !completed.Contains(s.Id) && s.DependsOn.All(completed.Contains)).ToArray();
            if (ready.Length == 0)
                throw new InvalidOperationException("The plan contains a dependency cycle.");
            foreach (var step in ready) completed.Add(step.Id);
        }
    }
}
