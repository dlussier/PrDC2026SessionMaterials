using DiscoverAF.Demo0.Baseline;
using DiscoverAF.Demo1.ScopedContext;
using DiscoverAF.Demo2.TargetedHandoffs;
using DiscoverAF.Demo3.Router;
using DiscoverAF.Demo4.Planner;
using DiscoverAF.Demo5.Memory;
using DiscoverAF.Demo6.ContextHygiene;
using DiscoverAF.Host.Components;
using DiscoverAF.Shared;

var resetDemo5Memory = args.Contains("--reset-demo5-memory", StringComparer.Ordinal);
var builder = WebApplication.CreateBuilder(args.Where(arg => arg != "--reset-demo5-memory").ToArray());

if (resetDemo5Memory)
{
    try
    {
        using var memoryDemo = new Demo5cPipeline(new DemoConfig(builder.Configuration));
        await memoryDemo.ResetMemoryAsync();
        Console.WriteLine($"Cleared demo 5c saved facts for {ContosoData.Profile.CustomerId}. Other customers and scoreboard totals are unchanged.");
        Console.WriteLine("Start the host normally for rehearsal. Do not reset memory between learning preferences and demonstrating recall after restart.");
    }
    catch (Exception ex)
    {
        Console.Error.WriteLine($"Demo 5c memory reset failed: {ex.Message}");
        Environment.ExitCode = 1;
    }
    return;
}

builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

builder.Services.AddSingleton<DemoConfig>();
builder.Services.AddSingleton<Scoreboard>();

builder.Services.AddSingleton<IDemoPipeline, Demo0Pipeline>();
builder.Services.AddSingleton<IDemoPipeline, Demo1Pipeline>();
builder.Services.AddSingleton<IDemoPipeline, Demo2NaivePipeline>();
builder.Services.AddSingleton<IDemoPipeline, Demo2TargetedPipeline>();
builder.Services.AddSingleton<IDemoPipeline, Demo3Pipeline>();
builder.Services.AddSingleton<IDemoPipeline, Demo4Pipeline>();
builder.Services.AddSingleton<IDemoPipeline, Demo5aPipeline>();
builder.Services.AddSingleton<IDemoPipeline, Demo5bPipeline>();
builder.Services.AddSingleton<IDemoPipeline, Demo5cPipeline>();
builder.Services.AddSingleton<IDemoPipeline, Demo6RawPipeline>();
builder.Services.AddSingleton<IDemoPipeline, Demo6SummarizePipeline>();
builder.Services.AddSingleton<IDemoPipeline, Demo6PrunePipeline>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseAntiforgery();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
