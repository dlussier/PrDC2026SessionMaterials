# host — Blazor chat host for all demos

The single app on screen for the entire session. Blazor Server (real-time UI updates with no extra SignalR plumbing; C# end to end).

## Layout

The primary workspace now places an architecture graph beside a chronological communication feed. The customer request stays above it, and the customer chat/composer stays below. Detailed scoreboard, memory chart, cross-demo totals, and raw trace are available under **Detailed scoreboard and raw trace**. The diagram below describes the original diagnostic layout.

```
+--------------------------------------------------------------+
| DiscoverAF          [ Demo: 1 — Scoped Context   v ]  [Reset] |
+---------------------------------------+----------------------+
|                                       |  SCOREBOARD          |
|  Chat pane                            |  agent   in    out  $ |
|  (user <-> active pipeline)           |  Router   212   18  ~0|
|                                       |  Returns  801  144  … |
|                                       |  ------- total ------ |
|                                       |  [cross-demo bars]    |
|                                       +----------------------+
|                                       |  TRACE               |
|                                       |  > Orchestrator → …   |
|  [ type a message…            Send ]  |  > tool LookupOrder…  |
+---------------------------------------+----------------------+
```

## Pieces

- **Architecture graph** — stable topology per demo, active model/tool/invocation labels, and directed task/result edges. Planner graphs use validated step IDs and dependencies, so two steps using the same specialist stay distinct. Deterministic executors and durable storage have explicit labels.
- **Communication** — chronological tasks and captured replies, with tools grouped under their owning invocation. Select an exchange to highlight its graph boundary. Expand its inspector for the full payload, tool arguments/results, and model input buttons. No extra summarization model calls power this view.
- **Pause and replay** — Pause view or selecting an exchange freezes only the display. Execution and event collection continue. Follow live catches up, and Previous/Next replay exchange boundaries from the latest request for that demo. Starting another request replaces its graph replay. Raw trace and conversation totals keep accumulating.
- **Instrumentation scope** — Demos 1 and 4 carry whole-task and parent/child identities. All demos emit model-call lifecycle and correlated business-tool events. A model reply in a framework-managed workflow means that call finished, not necessarily that the whole agent turn finished.
- **Demo picker** — dropdown bound to registered `IDemoPipeline` implementations, including variants within a library. Switching preserves each demo's conversation; **Reset conversation** clears the active conversation, and **Reset business state** additionally clears returns and restores Alex's seed address and order statuses.
- **Chat pane** — displays the final reply when a request completes, while trace and usage updates appear live. **Stop** cancels the active run; component disposal also cancels pending work.
- **Scoreboard widget** — subscribes to usage events from `shared/`; rows update per model call. Cumulative totals are session evidence. Use separately recorded, matched fresh-state runs for the closing comparison.
- **Trace panel** — shows agent turns, tool calls/results, handoffs, plans, and memory retrievals. Click a row to inspect its detail in a modal.
- **Prompt inspector** — click a **prompt captured** row to see instructions, function schemas, and messages at the chat-client boundary.
- **Per-turn chart** — shows input tokens summed across all model calls in each completed turn, including each `/autoplay` turn. Hover for counts. Average model-call latency is shown per agent in the scoreboard.

## The contract each demo implements

```csharp
public interface IDemoPipeline
{
    string Name { get; }          // "0 — Shared-History Group Chat"
    string Description { get; }   // one-liner shown under the picker
    Task<string> RunAsync(string userMessage, DemoSession session,
                  IProgress<TraceEvent> trace, CancellationToken ct);
}
```

`DemoSession` carries per-conversation state (the session/thread objects a pipeline needs between turns) so multi-turn demos (especially demo 5) work naturally in the chat.

## Stage tips

- **Reset conversation** clears the active conversation, not the shared business fixtures or durable facts.
- **Reset business state** clears returns, restores the seed address and order statuses, and resets the conversation — the host-restart equivalent for matched runs. Durable facts survive it.
- **Back up saved memory** / **Restore backup** (demo 5c) snapshot and restore Alex's durable facts. Restore stays disabled until a snapshot exists on this machine.
- **Elapsed (whole run)** appears in the graph after completion, failure, or cancellation. It includes tools and supporting calls, excludes browser delivery, and measures the entire script for /autoplay.
- Use the canonical quick-fill button for the boots prompt.
- Dark theme + big fonts; the trace panel font size matters more than you think on a projector.
- Keep the cumulative chart data in a JSON file so a crash/restart mid-talk doesn't lose your earlier demo runs.
