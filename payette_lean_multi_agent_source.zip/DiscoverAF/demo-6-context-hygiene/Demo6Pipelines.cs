using DiscoverAF.Shared;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

namespace DiscoverAF.Demo6.ContextHygiene;

public abstract class Demo6PipelineBase(DemoConfig config) : IDemoPipeline
{
    public abstract string Name { get; }

    public abstract string Description { get; }

    protected DemoConfig Config => config;

    protected abstract AIAgent CreateAgent(IProgress<TraceEvent> trace);

    public async Task<string> RunAsync(string userMessage, DemoSession session, IProgress<TraceEvent> trace, CancellationToken ct)
    {
        if (!config.IsConfigured)
        {
            return DemoConfig.NotConfiguredMessage;
        }

        var agent = CreateAgent(trace);
        var agentSession = await session.GetOrCreateAgentSessionAsync($"{GetType().Name}-agent", agent, ct);
        var response = await agent.RunAsync(userMessage, agentSession, cancellationToken: ct);
        return response.Text;
    }

    protected ChatClientAgent CreateProductAgent(IProgress<TraceEvent> trace, ChatHistoryProvider? historyProvider = null) =>
        AgentCatalog.CreateSpecialist(config, AgentCatalog.Product, trace, historyProvider: historyProvider);
}

public sealed class Demo6RawPipeline(DemoConfig config) : Demo6PipelineBase(config)
{
    public override string Name => "6a — Hygiene: Raw Tool Output";

    public override string Description => "Verbose tool results land in context untouched.";

    protected override AIAgent CreateAgent(IProgress<TraceEvent> trace) => CreateProductAgent(trace);
}

public sealed class Demo6SummarizePipeline(DemoConfig config) : Demo6PipelineBase(config)
{
    private const int ThresholdChars = 2_000;

    public override string Name => "6b — Hygiene: Summarize on Threshold";

    public override string Description => "Function middleware compresses oversized tool results with the mini model.";

    protected override AIAgent CreateAgent(IProgress<TraceEvent> trace) =>
        CreateProductAgent(trace)
            .AsBuilder()
            .Use(async (agent, context, next, ct) =>
            {
                var result = await next(context, ct);
                if (result is not string text || text.Length <= ThresholdChars)
                {
                    return result;
                }

                var summarizer = Config.CreateMeteredChatClient("ToolSummarizer", Config.MiniDeployment, trace);
                var summary = await summarizer.GetResponseAsync(
                    [
                        new ChatMessage(ChatRole.System,
                            "Compress this tool result to only what a shopping assistant needs to reason with: " +
                            "names, prices, stock, sizes, key attributes. Drop marketing prose. Be dense."),
                        new ChatMessage(ChatRole.User, $"Tool: {context.Function.Name}\n\n{text}"),
                    ],
                    cancellationToken: ct);

                trace.Report(TraceEvent.Info(
                    "ToolSummarizer",
                    $"{context.Function.Name} result compressed {text.Length:N0} → {summary.Text.Length:N0} chars",
                    summary.Text));
                return summary.Text;
            })
            .Build();
}

public sealed class Demo6PrunePipeline(DemoConfig config) : Demo6PipelineBase(config)
{
    private const int DigestChars = 120;

    public override string Name => "6c — Hygiene: Prune Spent Tool Calls";

    public override string Description => "After each response, shortens large retained tool results to a prefix for later turns.";

    protected override AIAgent CreateAgent(IProgress<TraceEvent> trace)
    {
        var historyProvider = new InMemoryChatHistoryProvider(new InMemoryChatHistoryProviderOptions
        {
            StorageInputResponseMessageFilter = messages => messages.Select(DigestToolResults),
        });

        return CreateProductAgent(trace, historyProvider);
    }

    private static ChatMessage DigestToolResults(ChatMessage message)
    {
        if (!message.Contents.OfType<FunctionResultContent>().Any())
        {
            return message;
        }

        var digested = message.Contents
            .Select(content => content is FunctionResultContent result
                ? new FunctionResultContent(result.CallId, Digest(result.Result?.ToString() ?? ""))
                : content)
            .ToList();

        return new ChatMessage(message.Role, digested) { AuthorName = message.AuthorName };
    }

    private static string Digest(string raw) =>
        raw.Length <= DigestChars
            ? raw
            : $"[digest — full payload pruned after use] {raw[..DigestChars].ReplaceLineEndings(" ")}…";
}
