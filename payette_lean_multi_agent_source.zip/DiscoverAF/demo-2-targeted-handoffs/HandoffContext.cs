using System.Text.Json.Serialization;

namespace DiscoverAF.Demo2.TargetedHandoffs;

public sealed record HandoffContext
{
    public static void Validate(HandoffContext value)
    {
        if (string.IsNullOrWhiteSpace(value.Intent) || string.IsNullOrWhiteSpace(value.OpenQuestion))
            throw new InvalidDataException("intent and openQuestion must describe the customer's task.");
        if (value.CustomerId != "CUST-1001")
            throw new InvalidDataException("customerId must match the authenticated customer CUST-1001.");
        if (value.RelevantFacts is null || value.RelevantFacts.Any(string.IsNullOrWhiteSpace))
            throw new InvalidDataException("relevantFacts must be an array of nonempty facts.");
        if (value.OrderId is not null && string.IsNullOrWhiteSpace(value.OrderId))
            throw new InvalidDataException("orderId must be an order identifier or null.");
    }

    [JsonPropertyName("intent")]
    public string Intent { get; init; } = "";

    [JsonPropertyName("customerId")]
    public string CustomerId { get; init; } = "";

    [JsonPropertyName("orderId")]
    public string? OrderId { get; init; }

    [JsonPropertyName("relevantFacts")]
    public string[] RelevantFacts { get; init; } = [];

    [JsonPropertyName("openQuestion")]
    public string OpenQuestion { get; init; } = "";
}

public sealed record TriageDecision
{
    [JsonPropertyName("target")]
    public string Target { get; init; } = "";

    [JsonPropertyName("reason")]
    public string Reason { get; init; } = "";
}
