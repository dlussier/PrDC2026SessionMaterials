using System.Text;
using System.Text.Json;
using DiscoverAF.Shared;
using Microsoft.Extensions.AI;

namespace DiscoverAF.Demo2.TargetedHandoffs;

public sealed class Demo2TargetedPipeline(DemoConfig config) : IDemoPipeline
{
    private static readonly JsonSerializerOptions PrettyJson = new() { WriteIndented = true };

    public string Name => "2b — Handoff with Structured Context";

    public string Description => "Triage selects one specialist and a composer prepares its handoff context.";

    public async Task<string> RunAsync(string userMessage, DemoSession session, IProgress<TraceEvent> trace, CancellationToken ct)
    {
        if (!config.IsConfigured)
        {
            return DemoConfig.NotConfiguredMessage;
        }

        session.Transcript.Add(new ChatMessage(ChatRole.User, userMessage));
        var conversationText = RenderConversation(session.Transcript);

        var triage = Demo2NaivePipeline.CreateTriageAgent(config, trace);
        var decision = await StructuredResponses.RunAsync<TriageDecision>(triage,
            $"Conversation so far:\n{conversationText}\n\n" +
            $"Which specialist should take over: {string.Join(", ", AgentCatalog.SpecialistNames)}?",
            value => { if (!AgentCatalog.SpecialistNames.Contains(value.Target, StringComparer.OrdinalIgnoreCase))
                throw new InvalidDataException("Choose a known specialist target."); }, trace, ct);

        var target = AgentCatalog.SpecialistNames.FirstOrDefault(
            name => name.Equals(decision.Target, StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException($"Triage returned an unknown specialist '{decision.Target}'.");
        trace.Report(TraceEvent.Info("Triage", $"target: {target}", decision.Reason));

        var composer = AgentCatalog.CreateMiniAgent(
            config,
            "HandoffComposer",
            "You compress support conversations into handoff records. Extract only facts relevant to the " +
            "receiving specialist. relevantFacts holds short bullet facts (ids, items, constraints, stated " +
            "preferences). openQuestion is the one thing the specialist must resolve. The customer is CUST-1001.",
            trace);

        var baton = await StructuredResponses.RunAsync<HandoffContext>(composer,
            $"The {target} specialist is taking over. Compose the handoff record.\n\nConversation:\n{conversationText}",
            HandoffContext.Validate, trace, ct);

        var batonJson = JsonSerializer.Serialize(baton, PrettyJson);

        trace.Report(TraceEvent.Handoff("Triage", target, batonJson));

        var specialist = AgentCatalog.CreateSpecialist(config, target, trace);
        var response = await specialist.RunAsync(
            $"You are receiving a handoff. Handle it for the customer.\n\nHandoff context:\n{batonJson}",
            cancellationToken: ct);

        session.Transcript.Add(new ChatMessage(ChatRole.Assistant, response.Text) { AuthorName = target });
        return response.Text;
    }

    private static string RenderConversation(IEnumerable<ChatMessage> transcript)
    {
        var sb = new StringBuilder();
        foreach (var message in transcript)
        {
            sb.Append(message.AuthorName ?? message.Role.Value).Append(": ").AppendLine(message.Text);
        }

        return sb.ToString();
    }
}
