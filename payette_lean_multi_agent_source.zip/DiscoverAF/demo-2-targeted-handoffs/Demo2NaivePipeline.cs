using DiscoverAF.Shared;
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Extensions.AI;

namespace DiscoverAF.Demo2.TargetedHandoffs;

public sealed class Demo2NaivePipeline(DemoConfig config) : IDemoPipeline
{
    public string Name => "2a — Handoff with Shared History";

    public string Description => "The handoff workflow passes its accumulated conversation to the receiving agent.";

    public async Task<string> RunAsync(string userMessage, DemoSession session, IProgress<TraceEvent> trace, CancellationToken ct)
    {
        if (!config.IsConfigured)
        {
            return DemoConfig.NotConfiguredMessage;
        }

        var triage = CreateTriageAgent(config, trace);
        var specialists = AgentCatalog.CreateAllSpecialists(config, trace);

        var workflow = AgentWorkflowBuilder.CreateHandoffBuilderWith(triage)
            .WithHandoffs(triage, specialists)
            .WithHandoffs(specialists, triage)
            .EmitAgentResponseEvents()
            .Build();

        session.Transcript.Add(new ChatMessage(ChatRole.User, userMessage));
        var input = new List<ChatMessage>(session.Transcript);

        await using var run = await InProcessExecution.RunStreamingAsync(workflow, input, cancellationToken: ct);

        await run.TrySendMessageAsync(new TurnToken(emitEvents: true));

        List<ChatMessage>? finalConversation = null;
        string? workflowFailure = null;
        await foreach (var evt in run.WatchStreamAsync(ct))
        {
            switch (evt)
            {
                case AgentResponseEvent response:
                    trace.Report(TraceEvent.AgentDone(response.ExecutorId, "responded (with full history in context)", response.Response.Text));
                    break;
                case ExecutorFailedEvent failed:
                    workflowFailure = failed.Data?.ToString() ?? "The handoff executor failed.";
                    trace.Report(TraceEvent.Error(failed.ExecutorId, "executor failed", failed.Data?.ToString() ?? ""));
                    break;
                case WorkflowOutputEvent output when output.Is<List<ChatMessage>>():
                    finalConversation = output.As<List<ChatMessage>>();
                    break;
            }
        }

        if (workflowFailure is not null)
        {
            throw new InvalidOperationException("The handoff workflow failed. Check the trace for the underlying error. " + workflowFailure);
        }
        if (finalConversation is null)
            throw new InvalidOperationException("The handoff workflow produced no output. Check the trace panel for errors.");

        session.Transcript.AddRange(finalConversation.Skip(input.Count));

        var lastReply = finalConversation.LastOrDefault(m => m.Role == ChatRole.Assistant && !string.IsNullOrWhiteSpace(m.Text));
        return lastReply?.Text ?? "The handoff finished without a spoken reply — check the trace panel.";
    }

    internal static ChatClientAgent CreateTriageAgent(DemoConfig config, IProgress<TraceEvent> trace) =>
        AgentCatalog.CreateFrontierAgent(
            config,
            "Triage",
            "You are the Contoso Outfitters front-desk triage agent for customer CUST-1001 (Alex Rivera). " +
            "You have no tools of your own: decide which specialist should take over and hand the conversation " +
            "off to them. If the request has several parts, hand off for the most urgent part first. " +
            "Only answer directly when no specialist is relevant.",
            trace);
}
