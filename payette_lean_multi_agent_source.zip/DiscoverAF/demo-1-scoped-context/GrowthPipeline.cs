using System.ComponentModel;
using System.Text.Json;
using DiscoverAF.Shared;
using Microsoft.Extensions.AI;

namespace DiscoverAF.Demo1.ScopedContext;

public sealed class GrowthPipeline(DemoConfig config, string design, int extraDomains) : IDemoPipeline
{
    public string Name => $"Growth: {design}, {extraDomains} extra departments";
    public string Description => "Fixed customer request with a growing fictional department registry.";
    public static readonly string[] Designs = ["all", "selected", "shared", "scoped"];
    public sealed record Selection { public string[] Domains { get; init; } = []; }
    public sealed record Department(string Name, string Description, string Policy, string[] Services);
    public static readonly Department[] ExtraDepartments =
    [
        new("Rentals", "Equipment rental reservations and deposits, not purchased merchandise.",
            "Rentals covers temporary equipment hire. A rental agreement identifies the asset, collection location, start date and due date. " +
            "Inventory must be checked for the entire requested date range. A listed daily rate excludes the refundable security deposit. " +
            "A customer may collect only after the reservation is confirmed and identification matches the agreement. Extensions require a new availability check. " +
            "Late fees depend on the original due time. Weather closures permit a reschedule only when the collection store confirms closure. " +
            "Cleaning charges require an inspection record. Missing components are recorded separately from ordinary wear. A rented tent cannot be returned through a retail purchase return. " +
            "Explain a quote as an estimate until a reservation exists. Never describe a requested extension as approved without the reservation result. " +
            "For cancellation, report the policy associated with the actual agreement. Do not infer rental dates or deposits from a customer's retail order.",
            ["FindRentalEquipment", "ReadRentalAgreement", "QuoteRentalDates", "CheckRentalDeposit", "FindRentalCollectionStore", "ReadRentalCancellationPolicy"]),
        new("Rewards", "Promotional vouchers and rewards campaigns; profile points remain with Account.",
            "Rewards administers promotional voucher campaigns. Voucher eligibility depends on campaign dates, membership tier and product exclusions. " +
            "A campaign code is not a payment method. Percentage discounts apply only to eligible items before tax. Fixed vouchers cannot create a negative subtotal. " +
            "Two campaigns may be combined only when both campaign records permit stacking. Expired codes require a documented extension, not an invented replacement. " +
            "Rental deposits and paid lessons are excluded unless a campaign names them. Read the customer voucher ledger before promising an unused benefit. " +
            "A displayed promotion does not prove that a customer redeemed it. Report a quote separately from a completed redemption. " +
            "Do not change an account's loyalty points or shipping details. Account owns those fields. " +
            "A customer asking for a budget recommendation has not requested voucher redemption. List applicable exclusions when answering a campaign question.",
            ["ListRewardCampaigns", "ReadVoucherLedger", "CheckVoucherEligibility", "QuoteVoucherDiscount", "ReadCampaignExclusions", "CheckVoucherStacking"]),
        new("Protection", "Separately purchased extended protection contracts; ordinary defective-item returns remain with Returns.",
            "Protection handles separately purchased extended service contracts. Obtain the contract identifier before deciding coverage. " +
            "Coverage dates start at the date recorded in the contract and may differ from purchase dates. Accidental damage coverage is an optional rider. " +
            "An estimate is not a claim approval. Claim eligibility depends on the covered serial number, incident description, coverage dates and deductible. " +
            "Ordinary retail returns, including defective merchandise, belong to Returns and do not require an extended protection contract. " +
            "Do not substitute a protection claim for a return the customer requested. Contract transfers require proof of ownership under the transfer policy. " +
            "Replacement limits are per contract period and include previously approved claims. A contract may require inspection before repair authorization. " +
            "Explain exclusions from the actual contract wording and identify any missing evidence. Never promise reimbursement from a deductible quote or an unapproved claim.",
            ["ReadProtectionContract", "CheckProtectionCoverage", "QuoteProtectionDeductible", "ReadProtectionClaim", "FindProtectionProvider", "ReadProtectionExclusions"]),
        new("Pickup", "Store pickup lockers and collection appointments; shipped-order addresses remain with Account.",
            "Pickup supports orders explicitly assigned to store collection. A pickup-ready notification is required before promising collection. " +
            "Locker availability is location-specific and does not establish that an order is packed. Collection hours follow the store's local time zone. " +
            "An alternate collector needs authorization recorded against the pickup order. A pickup code is sensitive and must not be inferred from a retail order number. " +
            "Expired locker holds revert to the store team for review. Accessibility requests require a confirmed service option at that store. " +
            "Store collection and shipment delivery are different fulfillment methods. Do not convert a shipped order merely because a customer changes their profile address. " +
            "Account manages saved shipping addresses. Orders manages shipping status. Report collection readiness separately from shelf inventory. " +
            "Weather disruptions can change collection hours; use the store status result. A lookup does not reserve a locker or extend a hold.",
            ["ReadPickupStatus", "FindPickupLockers", "ReadCollectionHours", "CheckAlternateCollector", "ReadPickupHoldPolicy", "FindAccessibleCollection"]),
        new("Workshop", "Paid equipment servicing and workshop appointments, not merchandise refunds.",
            "Workshop manages paid servicing for customer-owned outdoor equipment. A service estimate requires the equipment type, symptoms and preferred location. " +
            "An inspection may identify additional work, which needs customer authorization before proceeding. Parts availability does not guarantee a technician appointment. " +
            "Labor rates are estimates until the work order is accepted. Separate diagnostic fees from repair charges. " +
            "Safety-critical damage may make equipment unsuitable for servicing. In that case report the workshop's finding without promising a repair. " +
            "A workshop appointment is not a merchandise return. Route a requested retail refund or defective-item return to Returns. " +
            "Completed service carries only the warranty shown on the work order. Storage fees depend on the notification and collection dates. " +
            "Do not book work or authorize extra charges from a customer's general product question. Read the work-order status before claiming that servicing is complete.",
            ["FindWorkshopServices", "QuoteWorkshopInspection", "ReadWorkshopOrder", "CheckWorkshopParts", "FindTechnicianSlots", "ReadWorkshopGuarantee"]),
        new("Lessons", "Outdoor skills classes, instructors and course bookings.",
            "Lessons manages outdoor skills courses. Eligibility depends on minimum age, stated prerequisites and the course's fitness requirements. " +
            "A course listing is not a confirmed seat. Availability must match the date, location and group size. " +
            "Equipment included in the course differs from rental equipment and retail purchases. Tell the customer which items they must bring. " +
            "Weather cancellation decisions come from the course operator. Do not promise a refund or an alternative date until the booking policy and current status support it. " +
            "Private instruction requires an instructor with the relevant qualification. Accessibility accommodations require operator confirmation. " +
            "A hiking trip mentioned during a boot recommendation is not a request to book a lesson. " +
            "Separate prerequisite advice from enrollment approval. A quote does not collect payment. Cancellation deadlines use the course location's time zone and the actual booking terms.",
            ["FindOutdoorCourses", "CheckCourseSeats", "ReadCoursePrerequisites", "FindQualifiedInstructors", "QuotePrivateLesson", "ReadCourseCancellationPolicy"])
    ];

    public static string CompletionRules => "Preserve every requested action and constraint. Before replying, check that each requested action has a completion result or a concrete blocker. " +
        "Execute requested actions rather than only describing options. Do not ask for confirmation already supplied. Compose one friendly final answer.";
    public static string[] AvailableNames(int count)
    {
        if (count < 0 || count > ExtraDepartments.Length) throw new ArgumentOutOfRangeException(nameof(count));
        return [.. AgentCatalog.SpecialistNames, .. ExtraDepartments.Take(count).Select(d => d.Name)];
    }
    public static string PolicyFor(string name) => AgentCatalog.SpecialistNames.Contains(name)
        ? AgentCatalog.InstructionsFor(name) : ExtraDepartments.Single(d => d.Name == name).Policy;
    public static IList<AITool> ToolsFor(string name, IProgress<TraceEvent> trace)
    {
        if (AgentCatalog.SpecialistNames.Contains(name)) return AgentCatalog.ScopedToolsFor(name, new ContosoTools(trace, name));
        var department = ExtraDepartments.Single(d => d.Name == name);
        return department.Services.Select(service => (AITool)AIFunctionFactory.Create(
            ([Description("The customer question, item or reference to look up.")] string query) =>
            {
                trace.Report(TraceEvent.ToolCalled(name, service, JsonSerializer.Serialize(new { query })));
                var result = JsonSerializer.Serialize(new { Department = name, Service = service, Query = query,
                    Status = "No matching fixture record", Guidance = department.Policy, ActionCompleted = false });
                trace.Report(TraceEvent.ToolResult(name, service, result));
                return result;
            }, name: service, description: $"{service} in {name}. {department.Description}" )).ToList();
    }

    public async Task<string> RunAsync(string userMessage, DemoSession session, IProgress<TraceEvent> trace, CancellationToken ct)
    {
        if (!Designs.Contains(design)) throw new ArgumentException("Unknown growth design.");
        var names = AvailableNames(extraDomains);
        var registry = string.Join("\n", names.Select(n => $"{n}: " + (AgentCatalog.SpecialistNames.Contains(n)
            ? AgentCatalog.DescriptionFor(n) : ExtraDepartments.Single(d => d.Name == n).Description)));
        trace.Report(TraceEvent.Info("Experiment", "Available business scope", registry));
        if (design is "all" or "selected")
        {
            var selected = names;
            if (design == "selected")
            {
                selected = await InvocationTrace.RunAsync(trace, "ToolSelector", userMessage, async scope =>
                {
                    var selector = AgentCatalog.CreateFrontierAgent(config, "ToolSelector",
                        "Select every department needed for the customer's full request. Return exact names from this registry:\n" + registry, scope);
                    return (await selector.RunAsync<Selection>(userMessage, cancellationToken: ct)).Result.Domains;
                }, value => JsonSerializer.Serialize(value), from: "Customer", to: "SingleAgent");
                if (selected is null || selected.Length == 0 || selected.Any(n => !names.Contains(n)))
                    throw new InvalidOperationException("Tool selector returned an invalid department set.");
                selected = selected.Distinct().ToArray();
            }
            return await InvocationTrace.RunAsync(trace, "SingleAgent", userMessage, async scope =>
            {
                var agent = AgentCatalog.CreateFrontierAgent(config, "SingleAgent",
                    "You are the single Contoso Outfitters support agent for CUST-1001 (Alex Rivera). These department rules are your own responsibilities.\n" +
                    string.Join("\n\n", selected.Select(PolicyFor)) + "\n" + CompletionRules, scope,
                    selected.SelectMany(n => ToolsFor(n, scope)).ToList());
                return (await agent.RunAsync(userMessage, cancellationToken: ct)).Text;
            }, value => value, from: "Customer", to: "Customer");
        }
        var journal = new List<string>();
        using var gate = new SemaphoreSlim(1);
        return await InvocationTrace.RunAsync(trace, "GrowthSupervisor", userMessage, async parent =>
        {
            var delegates = names.Select(n => (AITool)AIFunctionFactory.Create(async (string taskBrief) =>
            {
                await gate.WaitAsync(ct);
                try
                {
                    var input = design == "shared" ? $"Customer request: {userMessage}\nPrevious specialist work:\n{string.Join("\n", journal)}\nYour task: {taskBrief}" : taskBrief;
                    var evidence = new List<string>();
                    var recorder = new ToolRecorder(parent, evidence);
                    var reply = await InvocationTrace.RunAsync(recorder, n, input, async scope =>
                    {
                        var worker = AgentCatalog.CreateFrontierAgent(config, n, PolicyFor(n), scope, ToolsFor(n, scope));
                        return (await worker.RunAsync(input, cancellationToken: ct)).Text;
                    }, value => value, from: "GrowthSupervisor", to: "GrowthSupervisor");
                    journal.Add($"{n} brief: {taskBrief}\nTool evidence: {string.Join("\n", evidence)}\nResult: {reply}");
                    return reply;
                }
                finally { gate.Release(); }
            }, name: $"ask_{n.ToLowerInvariant()}", description: registry.Split('\n').Single(line => line.StartsWith(n + ":")))).ToList();
            var supervisor = AgentCatalog.CreateFrontierAgent(config, "GrowthSupervisor",
                "You coordinate Contoso Outfitters support for CUST-1001 (Alex Rivera). Delegate each requested task to the relevant specialist. " +
                "Give a brief of at most two sentences preserving its required facts, constraints and requested action. " + CompletionRules, parent, delegates);
            return (await supervisor.RunAsync(userMessage, cancellationToken: ct)).Text;
        }, value => value, from: "Customer", to: "Customer");
    }
    private sealed class ToolRecorder(IProgress<TraceEvent> parent, List<string> evidence) : IProgress<TraceEvent>
    {
        public void Report(TraceEvent value)
        {
            if (value.Kind == TraceEventKind.ToolResult) lock (evidence) evidence.Add(value.Detail);
            parent.Report(value);
        }
    }
}
