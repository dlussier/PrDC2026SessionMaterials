using System.ComponentModel;
using DiscoverAF.Shared;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

namespace DiscoverAF.Demo1.ScopedContext;

public sealed class Demo1Pipeline(DemoConfig config) : IDemoPipeline
{
    public string Name => "1 — Supervisor with Scoped Delegation";

    public string Description => "A supervisor sends task briefs to fresh specialist sessions and combines their results.";

    public async Task<string> RunAsync(string userMessage, DemoSession session, IProgress<TraceEvent> trace, CancellationToken ct)
    {
        if (!config.IsConfigured)
        {
            return DemoConfig.NotConfiguredMessage;
        }

        return await InvocationTrace.RunAsync(trace, "Orchestrator", userMessage, async scope =>
        {
            var orchestrator = CreateOrchestrator(config, scope, ct);
            var orchestratorSession = await session.GetOrCreateAgentSessionAsync("demo1-orchestrator", orchestrator, ct);
            return (await orchestrator.RunAsync(userMessage, orchestratorSession, cancellationToken: ct)).Text;
        }, result => result, from: "Customer", to: "Customer");
    }

    public static ChatClientAgent CreateOrchestrator(DemoConfig config, IProgress<TraceEvent> trace, CancellationToken ct)
    {
        IList<AITool> specialistTools =
        [
            .. AgentCatalog.SpecialistNames.Select(name => CreateSpecialistTool(config, name, trace, ct)),
        ];

        return AgentCatalog.CreateFrontierAgent(
            config,
            "Orchestrator",
            "You are the Contoso Outfitters support orchestrator. You own the conversation with the customer " +
            "(CUST-1001, Alex Rivera). You cannot access data yourself — delegate every task to the specialist " +
            "tools. For each delegation, write a brief of at most two sentences containing ONLY the facts that " +
            "specialist needs (ids, items, constraints, the new value). Never paste the conversation into a brief. " +
            "A multi-part request means multiple briefs to multiple specialists. Preserve the requested ACTION, " +
            "not only its topic: a request to return an item means check eligibility and START the eligible return; " +
            "do not rewrite it as a request for options or next steps. Distinguish requests to act from questions " +
            "about policy. Before your final answer, check that every requested action has a completion result " +
            "or a concrete blocker. If a specialist only described an action that was requested, delegate again " +
            "to complete it. Do not ask for confirmation the customer already supplied. Compose one friendly final answer.",
            trace,
            specialistTools);
    }

    private static AITool CreateSpecialistTool(DemoConfig config, string specialistName, IProgress<TraceEvent> trace, CancellationToken ct)
    {
        return AIFunctionFactory.Create(
            async ([Description("A task brief of at most two sentences containing only the facts this specialist needs.")] string taskBrief) =>
            {
                return await InvocationTrace.RunAsync(trace, specialistName, taskBrief, async scope =>
                {
                    var specialist = AgentCatalog.CreateSpecialist(config, specialistName, scope);
                    return (await specialist.RunAsync(taskBrief, cancellationToken: ct)).Text;
                }, result => result, from: "Orchestrator", to: "Orchestrator");
            },
            name: $"ask_{specialistName.ToLowerInvariant()}_specialist",
            description: $"{AgentCatalog.DescriptionFor(specialistName)} Give it a short task brief preserving the requested action and all required facts. Request execution when the customer asked for an action.");
    }
}
