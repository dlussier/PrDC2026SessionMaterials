using DiscoverAF.Shared;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Extensions.AI;

namespace DiscoverAF.Demo0.Baseline;

public sealed class Demo0Pipeline(DemoConfig config) : IDemoPipeline
{
    public string Name => "0 — Shared-History Group Chat";

    public string Description => "All four specialists take a turn with shared history and their own domain tools.";

    public async Task<string> RunAsync(string userMessage, DemoSession session, IProgress<TraceEvent> trace, CancellationToken ct)
    {
        if (!config.IsConfigured)
        {
            return DemoConfig.NotConfiguredMessage;
        }

        var agents = AgentCatalog.CreateAllSpecialists(config, trace);

        var workflow = AgentWorkflowBuilder
            .CreateGroupChatBuilderWith(participants =>
                new RoundRobinGroupChatManager(participants) { MaximumIterationCount = agents.Length })
            .AddParticipants(agents)
            .Build();

        session.Transcript.Add(new ChatMessage(ChatRole.User, userMessage));
        var input = new List<ChatMessage>(session.Transcript);

        await using var run = await InProcessExecution.RunStreamingAsync(workflow, input, cancellationToken: ct);

        await run.TrySendMessageAsync(new TurnToken(emitEvents: true));

        List<ChatMessage>? finalConversation = null;
        string? workflowFailure = null;
        await foreach (var evt in run.WatchStreamAsync(ct))
        {
            switch (evt)
            {
                case AgentResponseEvent response:
                    trace.Report(TraceEvent.AgentDone(response.ExecutorId, "spoke in group chat", response.Response.Text));
                    break;
                case ExecutorInvokedEvent invoked:
                    trace.Report(TraceEvent.AgentTurn(invoked.ExecutorId, "takes the floor"));
                    break;
                case ExecutorFailedEvent failed:
                    workflowFailure = failed.Data?.ToString() ?? "The group-chat executor failed.";
                    trace.Report(TraceEvent.Error(failed.ExecutorId, "executor failed", failed.Data?.ToString() ?? ""));
                    break;
                case WorkflowOutputEvent output when output.Is<List<ChatMessage>>():
                    finalConversation = output.As<List<ChatMessage>>();
                    break;
            }
        }

        if (workflowFailure is not null)
        {
            throw new InvalidOperationException("The group chat failed. Check the trace for the underlying error. " + workflowFailure);
        }
        if (finalConversation is null)
            throw new InvalidOperationException("The group chat produced no output. Check the trace panel for errors.");

        var newMessages = finalConversation.Skip(input.Count).ToList();
        session.Transcript.AddRange(newMessages);

        var spokenTurns = newMessages
            .Where(m => m.Role == ChatRole.Assistant && !string.IsNullOrWhiteSpace(m.Text))
            .Select(m => string.IsNullOrEmpty(m.AuthorName) ? m.Text : $"**{m.AuthorName}:** {m.Text}")
            .ToList();

        return spokenTurns.Count > 0
            ? string.Join("\n\n", spokenTurns)
            : "The group chat finished without a spoken reply — check the trace panel.";
    }
}
