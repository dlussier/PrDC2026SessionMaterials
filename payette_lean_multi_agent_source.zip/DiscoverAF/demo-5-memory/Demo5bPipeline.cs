using DiscoverAF.Shared;
using Microsoft.Agents.AI;

namespace DiscoverAF.Demo5.Memory;

public sealed class Demo5bPipeline(DemoConfig config) : IDemoPipeline
{
    public string Name => "5b — Memory: Summarized";

    public string Description => "Keeps recent exchanges and a rolling summary of older discussion. Try /autoplay.";

    public async Task<string> RunAsync(string userMessage, DemoSession session, IProgress<TraceEvent> trace, CancellationToken ct)
    {
        if (!config.IsConfigured)
        {
            return DemoConfig.NotConfiguredMessage;
        }

        var reducer = new SummarizingChatReducer(
            config.CreateMeteredChatClient("Summarizer", config.MiniDeployment, trace), keepRecentMessages: 6);

        var historyProvider = new InMemoryChatHistoryProvider(new InMemoryChatHistoryProviderOptions
        {
            ChatReducer = reducer,
            ReducerTriggerEvent = InMemoryChatHistoryProviderOptions.ChatReducerTriggerEvent.BeforeMessagesRetrieval,
        });

        var concierge = AgentCatalog.CreateFrontierAgent(
            config, "Concierge", Demo5Common.ConciergeInstructions, trace, Demo5Common.ConciergeTools(trace),
            historyProvider: historyProvider);

        var agentSession = await session.GetOrCreateAgentSessionAsync("demo5b-concierge", concierge, ct);
        return await Demo5Common.RunTurnsAsync(concierge, agentSession, userMessage, trace, ct);
    }
}
