using System.Text.Json;
using Azure.Identity;
using Microsoft.Azure.Cosmos;

namespace DiscoverAF.Demo5.Memory;

public interface IFactStore
{
    string DisplayName { get; }

    Task<List<string>> LoadAsync(string customerId, CancellationToken ct);

    Task SaveAsync(string customerId, List<string> facts, CancellationToken ct);
}

public sealed class JsonFileFactStore : IFactStore
{
    private static readonly object Gate = new();
    private readonly string _path;

    public JsonFileFactStore(string? path = null) =>
        _path = path ?? Path.Combine(AppContext.BaseDirectory, "contoso-memory.json");

    public string DisplayName => $"JSON file ({_path})";

    public Task<List<string>> LoadAsync(string customerId, CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();
        lock (Gate)
        {
            if (!File.Exists(_path))
            {
                return Task.FromResult(new List<string>());
            }

            var all = JsonSerializer.Deserialize<Dictionary<string, List<string>>>(File.ReadAllText(_path)) ?? [];
            return Task.FromResult(all.TryGetValue(customerId, out var facts) ? facts : []);
        }
    }

    public Task SaveAsync(string customerId, List<string> facts, CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();
        lock (Gate)
        {
            var all = File.Exists(_path)
                ? JsonSerializer.Deserialize<Dictionary<string, List<string>>>(File.ReadAllText(_path)) ?? []
                : [];
            all[customerId] = facts;
            File.WriteAllText(_path + ".tmp", JsonSerializer.Serialize(all, new JsonSerializerOptions { WriteIndented = true }));
            File.Move(_path + ".tmp", _path, overwrite: true);
            return Task.CompletedTask;
        }
    }
}

public sealed class CosmosFactStore(string endpoint, string databaseName) : IFactStore, IDisposable
{
    private readonly Lazy<CosmosClient> _client = new(() => new CosmosClient(endpoint, new DefaultAzureCredential()));

    public string DisplayName => $"Cosmos DB ({endpoint})";

    public async Task<List<string>> LoadAsync(string customerId, CancellationToken ct)
    {
        var container = GetContainer();
        try
        {
            var response = await container.ReadItemAsync<FactDocument>(customerId, new PartitionKey(customerId), cancellationToken: ct);
            return response.Resource.facts;
        }
        catch (CosmosException ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            return [];
        }
    }

    public async Task SaveAsync(string customerId, List<string> facts, CancellationToken ct)
    {
        var container = GetContainer();
        await container.UpsertItemAsync(new FactDocument { id = customerId, facts = facts }, new PartitionKey(customerId), cancellationToken: ct);
    }

    private Container GetContainer() => _client.Value.GetContainer(databaseName, "customer-facts");

    public void Dispose()
    {
        if (_client.IsValueCreated) _client.Value.Dispose();
    }

    private sealed class FactDocument
    {
        public string id { get; set; } = "";

        public List<string> facts { get; set; } = [];
    }
}
