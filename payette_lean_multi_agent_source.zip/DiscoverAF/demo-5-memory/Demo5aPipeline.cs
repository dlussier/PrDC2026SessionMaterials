using DiscoverAF.Shared;

namespace DiscoverAF.Demo5.Memory;

public sealed class Demo5aPipeline(DemoConfig config) : IDemoPipeline
{
    public string Name => "5a — Memory: Unmanaged";

    public string Description => "Retains conversation history and tool results across turns. Try /autoplay.";

    public async Task<string> RunAsync(string userMessage, DemoSession session, IProgress<TraceEvent> trace, CancellationToken ct)
    {
        if (!config.IsConfigured)
        {
            return DemoConfig.NotConfiguredMessage;
        }

        var concierge = AgentCatalog.CreateFrontierAgent(
            config, "Concierge", Demo5Common.ConciergeInstructions, trace, Demo5Common.ConciergeTools(trace));

        var agentSession = await session.GetOrCreateAgentSessionAsync("demo5a-concierge", concierge, ct);
        return await Demo5Common.RunTurnsAsync(concierge, agentSession, userMessage, trace, ct);
    }
}
