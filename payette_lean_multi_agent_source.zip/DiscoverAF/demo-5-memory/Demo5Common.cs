using System.Text;
using DiscoverAF.Shared;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

namespace DiscoverAF.Demo5.Memory;

public static class Demo5Common
{
    public const string ConciergeInstructions =
        "You are the Contoso Outfitters gear concierge for customer CUST-1001 (Alex Rivera). You help plan trips " +
        "and recommend gear using your product tools. Remember what the customer tells you about their needs and " +
        "preferences, and keep answers short and specific. Keep customer statements distinct from your suggestions; " +
        "do not turn conditional sizing advice into a confirmed preference. For every total or subtotal, call " +
        "QuoteProducts with exactly the included SKUs and use its returned total verbatim. Quote alternatives " +
        "and optional additions as separate complete sets. Never calculate a price total yourself. " +
        "If no quote is available, list verified item prices and omit the total.";

    public static IList<AITool> ConciergeTools(IProgress<TraceEvent> trace)
    {
        var tools = new ContosoTools(trace, "Concierge");
        return [.. tools.ProductTools(), AIFunctionFactory.Create(tools.QuoteProducts)];
    }

    public static async Task<string> RunTurnsAsync(
        AIAgent agent, AgentSession agentSession, string userMessage, IProgress<TraceEvent> trace, CancellationToken ct,
        Action<string>? beforeTurn = null)
    {
        if (!userMessage.Trim().Equals(Scenario.AutoPlayCommand, StringComparison.OrdinalIgnoreCase))
        {
            beforeTurn?.Invoke(userMessage);
            var response = await agent.RunAsync(userMessage, agentSession, cancellationToken: ct);
            return response.Text;
        }

        var log = new StringBuilder("Auto-played the scripted 20-turn session. Watch the per-turn input tokens in the scoreboard.\n");
        var turnNumber = 0;
        foreach (var scriptedMessage in Scenario.LongSessionScript)
        {
            ct.ThrowIfCancellationRequested();
            turnNumber++;
            trace.Report(new TraceEvent { Kind = TraceEventKind.ChatTurnStarted, Agent = "Customer",
                Title = $"turn {turnNumber}/{Scenario.LongSessionScript.Length}", Detail = scriptedMessage });
            beforeTurn?.Invoke(scriptedMessage);
            var response = await agent.RunAsync(scriptedMessage, agentSession, cancellationToken: ct);
            trace.Report(new TraceEvent { Kind = TraceEventKind.ChatTurnCompleted, Agent = "Concierge", Title = $"Turn {turnNumber} complete", Detail = response.Text });
            log.AppendLine($"\n**Turn {turnNumber} — you:** {scriptedMessage}\n\n**Concierge:** {response.Text}");
        }

        return log.ToString();
    }
}
