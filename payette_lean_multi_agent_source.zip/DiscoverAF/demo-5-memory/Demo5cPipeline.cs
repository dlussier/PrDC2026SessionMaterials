using System.Text.Json;
using DiscoverAF.Shared;

namespace DiscoverAF.Demo5.Memory;

public sealed class Demo5cPipeline(DemoConfig config, IFactStore? factStore = null) : IDemoPipeline, IDisposable
{
    private readonly IFactStore _store = factStore ?? (string.IsNullOrWhiteSpace(config.CosmosEndpoint)
        ? new JsonFileFactStore()
        : new CosmosFactStore(config.CosmosEndpoint, config.CosmosDatabase));

    public void Dispose() => (_store as IDisposable)?.Dispose();
    public string Name => "5c — Memory: Long-Term";

    public string Description => "Facts stored outside the context, recalled selectively. Survives restarts.";

    public Task ResetMemoryAsync(CancellationToken ct = default) =>
        _store.SaveAsync(ContosoData.Profile.CustomerId, [], ct);

    public static string BackupPath { get; } =
        Path.Combine(AppContext.BaseDirectory, "contoso-memory.backup.json");

    public static bool BackupExists => File.Exists(BackupPath);

    public async Task<int> BackUpMemoryAsync(CancellationToken ct = default)
    {
        var facts = await _store.LoadAsync(ContosoData.Profile.CustomerId, ct);
        var payload = new Dictionary<string, List<string>> { [ContosoData.Profile.CustomerId] = facts };
        var json = JsonSerializer.Serialize(payload, new JsonSerializerOptions { WriteIndented = true });
        await File.WriteAllTextAsync(BackupPath + ".tmp", json, ct);
        File.Move(BackupPath + ".tmp", BackupPath, overwrite: true);
        return facts.Count;
    }

    public async Task<int> RestoreMemoryAsync(CancellationToken ct = default)
    {
        if (!BackupExists)
        {
            throw new InvalidOperationException("No backup on this machine yet. Back up saved memory first.");
        }

        var all = JsonSerializer.Deserialize<Dictionary<string, List<string>>>(
            await File.ReadAllTextAsync(BackupPath, ct)) ?? [];
        var facts = all.TryGetValue(ContosoData.Profile.CustomerId, out var stored) ? stored : [];
        await _store.SaveAsync(ContosoData.Profile.CustomerId, facts, ct);
        return facts.Count;
    }

    public async Task<string> RunAsync(string userMessage, DemoSession session, IProgress<TraceEvent> trace, CancellationToken ct)
    {
        if (!config.IsConfigured)
        {
            return DemoConfig.NotConfiguredMessage;
        }

        var currentCustomerMessage = userMessage;
        var memoryProvider = new FactMemoryProvider(config, _store, ContosoData.Profile.CustomerId, trace,
            () => currentCustomerMessage);

        var historyProvider = new Microsoft.Agents.AI.InMemoryChatHistoryProvider(
            new Microsoft.Agents.AI.InMemoryChatHistoryProviderOptions
            {
                ChatReducer = new SummarizingChatReducer(
                    config.CreateMeteredChatClient("Summarizer", config.MiniDeployment, trace), keepRecentMessages: 6),
                ReducerTriggerEvent = Microsoft.Agents.AI.InMemoryChatHistoryProviderOptions.ChatReducerTriggerEvent.BeforeMessagesRetrieval,
            });

        var concierge = AgentCatalog.CreateFrontierAgent(
            config, "Concierge", Demo5Common.ConciergeInstructions, trace, Demo5Common.ConciergeTools(trace),
            historyProvider: historyProvider,
            contextProviders: [memoryProvider]);

        var agentSession = await session.GetOrCreateAgentSessionAsync("demo5c-concierge", concierge, ct);
        return await Demo5Common.RunTurnsAsync(concierge, agentSession, userMessage, trace, ct,
            beforeTurn: message => currentCustomerMessage = message);
    }
}
