using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

namespace DiscoverAF.Shared;

public static class StructuredResponses
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web)
    {
        UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow,
    };

    public static async Task<T> RunAsync<T>(ChatClientAgent agent, string prompt, Action<T> validate,
        IProgress<TraceEvent> trace, CancellationToken ct)
    {
        var request = prompt;
        for (var attempt = 0; attempt < 2; attempt++)
        {
            var response = await agent.RunAsync(request, options: new ChatClientAgentRunOptions
            {
                ChatOptions = new ChatOptions
                {
                    ResponseFormat = ChatResponseFormat.ForJsonSchema<T>(Json),

                    AdditionalProperties = new() { ["strict"] = true },
                },
            }, cancellationToken: ct);
            try
            {
                var value = JsonSerializer.Deserialize<T>(response.Text, Json)
                    ?? throw new JsonException("The response was null.");
                validate(value);
                return value;
            }
            catch (Exception ex) when (ex is JsonException or InvalidDataException)
            {
                trace.Report(TraceEvent.Info(agent.Name ?? "Structured response", "contract rejected", ex.Message));
                if (attempt == 1) throw new InvalidOperationException("Structured response failed validation after one repair attempt.", ex);
                request = prompt + "\n\nThe previous response was rejected: " + ex.Message +
                    "\nReturn an instance of the required object, not a schema or a properties wrapper. Preserve the customer's requested action and facts.";
            }
        }
        throw new InvalidOperationException("Unreachable structured response state.");
    }
}
