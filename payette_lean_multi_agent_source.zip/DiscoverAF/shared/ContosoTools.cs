using System.ComponentModel;
using System.Text.Json;
using Microsoft.Extensions.AI;

namespace DiscoverAF.Shared;

public sealed class ContosoTools(IProgress<TraceEvent> trace, string agentName = "tools")
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };

    [Description("Looks up an order by its order number and returns its full details.")]
    public string LookupOrder([Description("The order number, e.g. 48213")] string orderId) =>
        Run(nameof(LookupOrder), orderId, () =>
            ContosoData.FindOrder(orderId) is { } order
                ? ToJson(order)
                : $"No order found with id {orderId}.");

    [Description("Gets the current shipment status and tracking details for an order.")]
    public string GetShipmentStatus([Description("The order number")] string orderId) =>
        Run(nameof(GetShipmentStatus), orderId, () =>
            ContosoData.FindOrder(orderId) is { } order
                ? $"Order {order.Id} ({order.Item}): {order.Status}. Carrier {order.Carrier}, tracking {order.TrackingNumber}." +
                  (string.IsNullOrEmpty(order.DeliveredOn) ? "" : $" Delivered on {order.DeliveredOn}.")
                : $"No order found with id {orderId}.");

    [Description("Cancels an order that has not shipped yet.")]
    public string CancelOrder([Description("The order number")] string orderId) =>
        Run(nameof(CancelOrder), orderId, () =>
        {
            var order = ContosoData.FindOrder(orderId);
            if (order is null)
            {
                return $"No order found with id {orderId}.";
            }

            if (order.Status is "Cancelled") return $"Order {order.Id} is already cancelled.";
            if (order.Status is not ("Pending" or "Processing"))
            {
                return $"Order {order.Id} is {order.Status} and can no longer be cancelled. Only unshipped orders can be cancelled.";
            }

            order.Status = "Cancelled";
            return $"Order {order.Id} ({order.Item}) has been cancelled and {order.Price:C} will be refunded to {ContosoData.Profile.PaymentMethod}.";
        });

    [Description("Checks whether an order is eligible for return or exchange.")]
    public string CheckReturnEligibility([Description("The order number")] string orderId) =>
        Run(nameof(CheckReturnEligibility), orderId, () =>
        {
            var order = ContosoData.FindOrder(orderId);
            if (order is null) return $"No order found with id {orderId}.";
            if (order.Status != "Delivered") return $"Order {order.Id} has not been delivered and is not eligible for return.";
            return $"As of the fixed scenario date {ContosoData.ScenarioDate:yyyy-MM-dd}, order {order.Id} " +
                   $"is {(ContosoData.IsWithinReturnWindow(order) ? "within" : "outside")} the standard 60-day return window. " +
                   "Quality-defect returns are covered by the Contoso lifetime guarantee regardless of purchase date; " +
                   "set isQualityDefect when the customer reports a defect to qualify for a full refund and prepaid shipping.";
        });

    [Description("Starts a return for an order and emails the customer a prepaid shipping label.")]
    public string StartReturn(
        [Description("The order number")] string orderId,
        [Description("Why the customer is returning the item")] string reason,
        [Description("True only when the customer reports a product quality defect, such as falling apart.")] bool isQualityDefect = false) =>
        Run(nameof(StartReturn), $"{orderId}, {reason}, isQualityDefect={isQualityDefect}", () =>
        {
            var order = ContosoData.FindOrder(orderId);
            if (order is null) return $"No order found with id {orderId}.";
            if (order.Status != "Delivered") return $"Order {order.Id} has not been delivered and is not eligible for return.";
            if (!ContosoData.IsWithinReturnWindow(order) && !isQualityDefect)
                return "Outside the 60-day return window. Only a customer-reported quality defect qualifies under the lifetime guarantee.";
            return ToJson(ContosoData.StartReturn(orderId, reason));
        });

    [Description("Issues a refund for an approved return.")]
    public string IssueRefund([Description("The return id, e.g. RET-9000")] string returnId) =>
        Run(nameof(IssueRefund), returnId, () =>
        {
            var record = ContosoData.Returns.FirstOrDefault(r => r.ReturnId == returnId);
            if (record is null)
            {
                return $"No return found with id {returnId}.";
            }

            var order = ContosoData.FindOrder(record.OrderId);
            if (order is null) return $"No order found for return {returnId}.";
            if (record.Status == "Refunded") return $"Return {returnId} has already been refunded.";
            record.Status = "Refunded";
            return $"Refund of {order?.Price ?? 0m:C} for return {returnId} (order {record.OrderId}) issued to {ContosoData.Profile.PaymentMethod}.";
        });

    [Description("Searches the Contoso Outfitters catalog and returns matching products with full details.")]
    public string SearchCatalog([Description("Free-text search query, e.g. 'waterproof hiking boots'")] string query) =>
        Run(nameof(SearchCatalog), query, () =>

            ToJson(ContosoData.Catalog));

    [Description("Checks stock levels and available sizes for a product by name or SKU.")]
    public string CheckInventory([Description("Product name or SKU")] string product) =>
        Run(nameof(CheckInventory), product, () =>
        {
            var match = ContosoData.Catalog.FirstOrDefault(p =>
                p.Sku.Equals(product, StringComparison.OrdinalIgnoreCase) ||
                p.Name.Contains(product, StringComparison.OrdinalIgnoreCase));
            return match is null
                ? $"No product matching '{product}'."
                : $"{match.Name} ({match.Sku}): {match.UnitsInStock} units in stock." +
                  (match.SizesInStock.Length > 0 ? $" Sizes in stock: {string.Join(", ", match.SizesInStock)}." : "");
        });

    [Description("Returns the sizing chart and fit guidance for a product category.")]
    public string GetSizingChart([Description("Product category, e.g. Footwear")] string category) =>
        Run(nameof(GetSizingChart), category, () =>
            category.Contains("foot", StringComparison.OrdinalIgnoreCase) || category.Contains("boot", StringComparison.OrdinalIgnoreCase)
                ? "Footwear sizing: Contoso boots run true to size. For thick hiking socks order a half size up. " +
                  "US 10 = EU 44 = UK 9.5 = 28cm. Wide-foot hikers report the Summit Ridge and Ridgeline lasts are the roomiest."
                : $"Sizing for {category}: S (36-38), M (39-41), L (42-44), XL (45-48). All apparel is athletic fit; size up for layering.");

    [Description("Calculates an exact USD catalog quote for one of each supplied SKU. Use this for every total or subtotal; quote alternatives and optional-item sets separately.")]
    public string QuoteProducts([Description("Distinct catalog SKUs, one unit of each, in the exact set to total.")] string[] skus) =>
        Run(nameof(QuoteProducts), JsonSerializer.Serialize(skus), () =>
        {
            if (skus is null || skus.Length == 0 || skus.Any(string.IsNullOrWhiteSpace))
                return ToJson(new { Error = "Supply at least one nonempty SKU. No total calculated." });
            if (skus.Distinct(StringComparer.OrdinalIgnoreCase).Count() != skus.Length)
                return ToJson(new { Error = "Supply each SKU once. No total calculated." });
            var items = skus.Select(sku => ContosoData.Catalog.FirstOrDefault(p => p.Sku.Equals(sku, StringComparison.OrdinalIgnoreCase))).ToArray();
            if (items.Any(p => p is null))
                return ToJson(new { Error = "Unknown catalog SKU. No partial total calculated." });
            return ToJson(new { Currency = "USD", Items = items.Select(p => new { p!.Sku, p.Name, UnitPrice = p.Price, Quantity = 1 }),
                Total = items.Sum(p => p!.Price), Excludes = "Tax, shipping, and items not in this quote" });
        });

    [Description("Gets the customer's profile: name, shipping address, payment method, and membership.")]
    public string GetProfile() =>
        Run(nameof(GetProfile), "", () => ToJson(ContosoData.Profile));

    [Description("Updates the customer's shipping address.")]
    public string UpdateAddress([Description("The complete new shipping address")] string newAddress) =>
        Run(nameof(UpdateAddress), newAddress, () =>
        {
            ContosoData.UpdateAddress(newAddress);
            return $"Shipping address updated to: {newAddress}";
        });

    [Description("Gets the customer's loyalty point balance and membership tier benefits.")]
    public string GetLoyaltyBalance() =>
        Run(nameof(GetLoyaltyBalance), "", () =>
            $"{ContosoData.Profile.Name} has {ContosoData.Profile.LoyaltyPoints} points on the {ContosoData.Profile.MembershipTier} tier " +
            "(free shipping over $49, early access to seasonal drops, double points on footwear).");

    public IList<AITool> OrdersTools() =>
        [AIFunctionFactory.Create(LookupOrder), AIFunctionFactory.Create(GetShipmentStatus), AIFunctionFactory.Create(CancelOrder)];

    public IList<AITool> ReturnsTools() =>
        [AIFunctionFactory.Create(StartReturn), AIFunctionFactory.Create(CheckReturnEligibility), AIFunctionFactory.Create(IssueRefund)];

    public IList<AITool> ProductTools() =>
        [AIFunctionFactory.Create(SearchCatalog), AIFunctionFactory.Create(CheckInventory), AIFunctionFactory.Create(GetSizingChart)];

    public IList<AITool> AccountTools() =>
        [AIFunctionFactory.Create(GetProfile), AIFunctionFactory.Create(UpdateAddress), AIFunctionFactory.Create(GetLoyaltyBalance)];

    public IList<AITool> AllTools() =>
        [.. OrdersTools(), .. ReturnsTools(), .. ProductTools(), .. AccountTools()];

    private string Run(string tool, string args, Func<string> body)
    {
        var callId = Guid.NewGuid().ToString("N");
        trace.Report(TraceEvent.ToolCalled(agentName, tool, args) with { ToolCallId = callId, ToolName = tool });
        try
        {
            string result;
            lock (ContosoData.SyncRoot) result = body();
            trace.Report(TraceEvent.ToolResult(agentName, tool, result) with { ToolCallId = callId, ToolName = tool });
            return result;
        }
        catch (Exception ex)
        {
            trace.Report(TraceEvent.Error(agentName, $"tool {tool} failed", ex.Message) with { ToolCallId = callId, ToolName = tool });
            throw;
        }
    }

    private static string ToJson(object value) => JsonSerializer.Serialize(value, JsonOptions);
}
