namespace DiscoverAF.Shared;

public sealed record ArchitectureStep(string Id, string Agent, string Instruction, string[] DependsOn);
public sealed record ArchitectureEdge(string From, string To, string Label = "flow");
public sealed record ArchitectureNode(string Id, string Name, string Role, int Level);

public sealed class CommunicationItem
{
    public required string Id { get; init; }
    public required string NodeId { get; init; }
    public required string Title { get; init; }
    public string? ParentId { get; init; }
    public string? From { get; init; }
    public string? To { get; init; }
    public string Input { get; set; } = "";
    public string Output { get; set; } = "";
    public string Status { get; set; } = "Working";
    public bool IsInvocation { get; init; }
    public long InputTokens { get; set; }
    public long OutputTokens { get; set; }
    public List<TraceEvent> Prompts { get; } = [];
    public Dictionary<string, ToolActivity> Tools { get; } = [];
    public HashSet<string> ActiveCalls { get; } = [];
    public TraceEvent? Event { get; set; }
}

public sealed class ToolActivity
{
    public required string Name { get; init; }
    public string Arguments { get; init; } = "";
    public string Result { get; set; } = "";
    public string Status { get; set; } = "Running";
}

public sealed class ArchitectureState
{
    public Dictionary<string, ArchitectureNode> Nodes { get; } = [];
    public List<ArchitectureEdge> Edges { get; } = [];
    public List<CommunicationItem> Communication { get; } = [];
    private readonly Dictionary<string, CommunicationItem> _items = [];
    private readonly Dictionary<string, CommunicationItem> _calls = [];
    private readonly Dictionary<string, CommunicationItem> _tools = [];
    public string Pattern { get; }
    public string RunStatus { get; private set; } = "Ready";
    public string Request { get; private set; } = "";
    public long InputTokens { get; private set; }
    public long OutputTokens { get; private set; }
    public int Calls { get; private set; }
    public double? ElapsedMs { get; private set; }
    private int _sequence;

    public ArchitectureState(string demo)
    {
        AddNode("Customer", "Customer", "request / response", 0);
        Pattern = demo switch
        {
            var d when d.StartsWith("0 ") => "Shared group chat · shared history · 3 domain tools per specialist",
            var d when d.StartsWith("1 ") => "Supervisor / agent-as-tool · fresh specialist sessions",
            var d when d.StartsWith("2a") => "Handoff workflow · full conversation",
            var d when d.StartsWith("2b") => "Targeted handoff · typed context contract",
            var d when d.StartsWith("3 ") => "Router · conditional dispatch to specialists or supervisor",
            var d when d.StartsWith("4 ") => "Plan-and-execute · validated dependencies · concurrent workers",
            var d when d.StartsWith("5a") => "Concierge · retained conversation history",
            var d when d.StartsWith("5b") => "Concierge · rolling summary and recent turns",
            var d when d.StartsWith("5c") => "Concierge · managed history and durable fact retrieval",
            _ => "Product specialist · tool-output hygiene",
        };
        if (demo.StartsWith("4 "))
        {
            AddNode("Planner", "Planner", "model", 1); AddNode("Executor", "Executor", "C# scheduling", 2);
            AddNode("Aggregator", "Aggregator", "model", 4);
            Edge("Customer", "Planner"); Edge("Planner", "Executor");
        }
        else if (demo.StartsWith("5"))
        {
            AddNode("Concierge", "Concierge", "model", 1); Edge("Customer", "Concierge");
            if (!demo.StartsWith("5a")) { AddNode("Summarizer", "Summarizer", "model", 2); Edge("Summarizer", "Concierge", "summary"); }
            if (demo.StartsWith("5c"))
            {
                AddNode("FactExtractor", "FactExtractor", "model", 2); AddNode("Fact store", "Fact store", "durable storage", 3);
                Edge("Concierge", "FactExtractor", "turn"); Edge("FactExtractor", "Fact store", "save"); Edge("Fact store", "Concierge", "recall");
            }
        }
        else if (demo.StartsWith("6"))
        {
            AddNode("Product", "Product", "model · domain tools", 1); Edge("Customer", "Product");
            if (demo.StartsWith("6b")) { AddNode("ToolSummarizer", "ToolSummarizer", "model", 2); Edge("Product", "ToolSummarizer", "large result"); }
        }
        else
        {
            var coordinator = demo.StartsWith("0 ") ? "Shared chat" : demo.StartsWith("2") ? "Triage" : demo.StartsWith("3 ") ? "Router" : "Orchestrator";
            AddNode(coordinator, coordinator, coordinator == "Shared chat" ? "shared context" : "model", 1);
            Edge("Customer", coordinator);
            foreach (var specialist in AgentCatalog.SpecialistNames)
            {
                AddNode(specialist, specialist, "model · domain tools", 3);
                Edge(coordinator, specialist, demo.StartsWith("0 ") ? "shared history" : "task");
            }
            if (demo.StartsWith("2b")) { AddNode("HandoffComposer", "HandoffComposer", "model", 2); Edge("Triage", "HandoffComposer", "selected domain"); }
            if (demo.StartsWith("3 "))
            {
                AddNode("Orchestrator", "Orchestrator", "multi-domain fallback", 2); Edge("Router", "Orchestrator");
                foreach (var specialist in AgentCatalog.SpecialistNames) Edge("Orchestrator", specialist);
            }
        }
    }

    private void AddNode(string id, string name, string role = "model", int level = 3) => Nodes.TryAdd(id, new(id, name, role, level));
    private void Edge(string from, string to, string label = "flow")
    {
        if (from != to && !Edges.Any(e => e.From == from && e.To == to)) Edges.Add(new(from, to, label));
    }

    public string Status(string nodeId)
    {
        var items = Communication.Where(i => i.NodeId == nodeId).ToArray();
        if (items.Any(i => i.ActiveCalls.Count > 0)) return "Model running";
        if (items.Any(i => i.Tools.Values.Any(t => t.Status == "Running"))) return "Using tool";
        var open = items.Where(i => i.IsInvocation && i.Status == "Working").ToArray();
        if (open.Length > 0)
            return open.Any(i => Communication.Any(c => c.ParentId == i.Id && c.Status == "Working")) ? "Waiting for specialist" : "Working";
        var last = items.LastOrDefault();
        return last?.Status ?? (RunStatus == "Complete" ? "Not used" : "Ready");
    }

    public static bool IsActive(string status) => status is "Model running" or "Using tool" or "Working";

    public void Apply(TraceEvent evt)
    {
        _sequence++;
        var node = evt.NodeId ?? evt.Agent;
        if (evt.Kind == TraceEventKind.RunStarted) { RunStatus = "Running"; Request = evt.Detail; ElapsedMs = null; AddMessage(evt, "Customer", evt.Title); return; }
        if (evt.Kind == TraceEventKind.ChatTurnStarted) Request = evt.Detail;
        if (evt.Kind is TraceEventKind.RunCompleted or TraceEventKind.RunFailed or TraceEventKind.RunCancelled)
        {
            RunStatus = evt.Kind == TraceEventKind.RunCompleted ? "Complete" : evt.Kind == TraceEventKind.RunCancelled ? "Cancelled" : "Failed";
            ElapsedMs = evt.ElapsedMs;
            foreach (var item in Communication)
            {
                item.ActiveCalls.Clear();
                if (item.Status == "Working") item.Status = RunStatus == "Complete" ? "Finished" : RunStatus;
                foreach (var tool in item.Tools.Values.Where(t => t.Status == "Running")) tool.Status = RunStatus == "Complete" ? "Finished" : RunStatus;
            }
            AddMessage(evt, "Customer", evt.Title);
            return;
        }
        if (evt.Kind == TraceEventKind.PlanValidated && evt.Steps is { } steps)
        {
            var levels = new Dictionary<string, int>();

            for (var pass = 0; pass < steps.Count; pass++)
                foreach (var step in steps.Where(s => !levels.ContainsKey(s.Id) && s.DependsOn.All(levels.ContainsKey)))
                    levels[step.Id] = step.DependsOn.Length == 0 ? 3 : step.DependsOn.Max(id => levels[id]) + 1;
            foreach (var step in steps)
            {
                var id = $"step:{step.Id}";
                AddNode(id, step.Agent, $"step {step.Id}", levels.GetValueOrDefault(step.Id, 3));
                if (step.DependsOn.Length == 0) Edge("Executor", id, "dispatch");
                foreach (var dependency in step.DependsOn) Edge($"step:{dependency}", id, "dependency");
                Edge(id, "Aggregator", "result");
            }
            Nodes["Aggregator"] = new("Aggregator", "Aggregator", "model", levels.Values.DefaultIfEmpty(3).Max() + 1);
            AddMessage(evt, "Executor", "Validated plan");
            return;
        }
        if (evt.Kind == TraceEventKind.InvocationStarted)
        {
            AddNode(node, evt.Agent);
            var item = new CommunicationItem
            {
                Id = evt.InvocationId!,
                NodeId = node,
                ParentId = evt.ParentInvocationId,
                Title = evt.FromNode is null ? evt.Agent : $"{Name(evt.FromNode)} → {Name(node)}",
                From = evt.FromNode,
                To = node,
                Input = evt.Detail,
                IsInvocation = true,
                Event = evt
            };
            Add(item);
            if (evt.FromNode is { } from) { AddNode(from, from); Edge(from, node, "task"); }
            return;
        }
        if (evt.Kind == TraceEventKind.ModelCallStarted)
        {
            AddNode(node, evt.Agent);
            var item = FindInvocation(evt) ?? Add(new CommunicationItem
            {
                Id = evt.CallId!,
                NodeId = node,
                Title = $"{evt.Agent} · model call",
                Event = evt
            });
            item.ActiveCalls.Add(evt.CallId!); _calls[evt.CallId!] = item;
            return;
        }
        var owner = FindInvocation(evt) ?? (evt.CallId is { } call ? _calls.GetValueOrDefault(call) : null);
        if (evt.Kind == TraceEventKind.ModelCallMetered)
        {
            InputTokens += evt.InputTokens; OutputTokens += evt.OutputTokens; Calls++;
            if (owner is not null) { owner.InputTokens += evt.InputTokens; owner.OutputTokens += evt.OutputTokens; }
        }
        else if (evt.Kind == TraceEventKind.PromptCaptured && owner is not null) owner.Prompts.Add(evt);
        else if (evt.Kind is TraceEventKind.ModelCallCompleted or TraceEventKind.ModelCallFailed && owner is not null)
        {
            if (evt.CallId is not null) owner.ActiveCalls.Remove(evt.CallId);
            if (!owner.IsInvocation)
            {
                owner.Status = evt.Kind == TraceEventKind.ModelCallCompleted ? "Replied" : evt.Cancelled ? "Cancelled" : "Failed";
                owner.Output = evt.Detail; owner.Event = evt;
            }
        }
        else if (evt.Kind is TraceEventKind.InvocationCompleted or TraceEventKind.InvocationFailed && owner is not null)
        {
            owner.Status = evt.Kind == TraceEventKind.InvocationCompleted ? "Complete" : evt.Cancelled ? "Cancelled" : "Failed";
            owner.Output = evt.Detail; owner.Event = evt; owner.ActiveCalls.Clear();
            if (evt.FromNode is { } from && evt.ToNode is { } to) Edge(from, to, "result");
        }
        else if (evt.Kind == TraceEventKind.ToolCalled && evt.ToolCallId is { } toolId)
        {
            owner ??= Communication.LastOrDefault(i => i.NodeId == node && i.Event?.Kind != TraceEventKind.Handoff);
            owner ??= Add(new CommunicationItem { Id = $"tool:{toolId}", NodeId = node, Title = evt.Agent, Event = evt });
            AddNode(node, evt.Agent);
            owner.Tools[toolId] = new() { Name = evt.ToolName ?? evt.Title, Arguments = evt.Detail };
            _tools[toolId] = owner;
        }
        else if (evt.ToolCallId is { } resultId && _tools.TryGetValue(resultId, out var toolOwner))
        {
            toolOwner.Tools[resultId].Result = evt.Detail;
            toolOwner.Tools[resultId].Status = evt.Kind == TraceEventKind.Error ? "Failed" : "Complete";
        }
        else if (evt.Kind is TraceEventKind.Handoff or TraceEventKind.MemoryRecalled or TraceEventKind.MemoryStored)
        {
            if (evt.FromNode is { } from && evt.ToNode is { } to)
            {
                AddNode(from, from); AddNode(to, to); Edge(from, to, evt.Kind == TraceEventKind.Handoff ? "handoff" : "memory");
            }
            AddMessage(evt, evt.FromNode ?? node, evt.FromNode is null ? evt.Title : $"{Name(evt.FromNode)} → {Name(evt.ToNode!)}");
        }
        else if (evt.Kind is TraceEventKind.ChatTurnStarted or TraceEventKind.ChatTurnCompleted or TraceEventKind.Error)
            AddMessage(evt, evt.Kind == TraceEventKind.ChatTurnStarted ? "Customer" : node, evt.Title);
        else if (evt.Kind == TraceEventKind.AgentTurnCompleted && !string.IsNullOrWhiteSpace(evt.Detail) &&
                 !Communication.Any(i => i.NodeId == node && i.Output == evt.Detail))
            AddMessage(evt, node, $"{evt.Agent} replied");
    }

    public string Name(string id) => Nodes.TryGetValue(id, out var node) ? node.Name : id;
    private CommunicationItem? FindInvocation(TraceEvent evt) => evt.InvocationId is { } id ? _items.GetValueOrDefault(id) : null;
    private CommunicationItem Add(CommunicationItem item) { Communication.Add(item); _items[item.Id] = item; return item; }
    private void AddMessage(TraceEvent evt, string node, string title) => Add(new CommunicationItem
    {
        Id = $"event:{_sequence}",
        NodeId = node,
        Title = title,
        Input = evt.Detail,
        From = evt.FromNode,
        To = evt.ToNode,
        Status = evt.Kind is TraceEventKind.Error or TraceEventKind.RunFailed ? "Failed" : evt.Kind == TraceEventKind.RunCancelled ? "Cancelled" : "Recorded",
        Event = evt,
    });
}
