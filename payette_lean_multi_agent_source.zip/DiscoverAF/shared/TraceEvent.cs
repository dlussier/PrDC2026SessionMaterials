namespace DiscoverAF.Shared;

public enum TraceEventKind
{
    AgentTurnStarted,
    AgentTurnCompleted,
    ToolCalled,
    ToolResult,
    ModelCallMetered,
    ChatTurnCompleted,
    Handoff,
    PlanEmitted,
    MemoryRecalled,
    PromptCaptured,
    Info,
    Error,
    ModelCallStarted,
    ModelCallCompleted,
    ModelCallFailed,
    InvocationStarted,
    InvocationCompleted,
    InvocationFailed,
    PlanValidated,
    RunStarted,
    RunCompleted,
    RunFailed,
    RunCancelled,
    MemoryStored,
    ChatTurnStarted,
}

public sealed record TraceEvent
{
    public required TraceEventKind Kind { get; init; }
    public required string Agent { get; init; }
    public required string Title { get; init; }
    public string Detail { get; init; } = "";
    public long InputTokens { get; init; }
    public long OutputTokens { get; init; }
    public decimal Cost { get; init; }
    public double LatencyMs { get; init; }

    public double? ElapsedMs { get; init; }
    public bool UsageEstimated { get; init; }
    public DateTimeOffset Timestamp { get; init; } = DateTimeOffset.Now;
    public string? RunId { get; init; }
    public string? NodeId { get; init; }
    public string? InvocationId { get; init; }
    public string? ParentInvocationId { get; init; }
    public string? CallId { get; init; }
    public string? ToolCallId { get; init; }
    public string? ToolName { get; init; }
    public string? FromNode { get; init; }
    public string? ToNode { get; init; }
    public bool Cancelled { get; init; }
    public IReadOnlyList<ArchitectureStep>? Steps { get; init; }

    public static TraceEvent AgentTurn(string agent, string title, string detail = "") =>
        new() { Kind = TraceEventKind.AgentTurnStarted, Agent = agent, Title = title, Detail = detail };

    public static TraceEvent AgentDone(string agent, string title, string detail = "") =>
        new() { Kind = TraceEventKind.AgentTurnCompleted, Agent = agent, Title = title, Detail = detail };

    public static TraceEvent ToolCalled(string agent, string tool, string args) =>
        new() { Kind = TraceEventKind.ToolCalled, Agent = agent, Title = $"tool {tool}", Detail = args };

    public static TraceEvent ToolResult(string agent, string tool, string result) =>
        new() { Kind = TraceEventKind.ToolResult, Agent = agent, Title = $"tool {tool} → {result.Length:N0} chars", Detail = result };

    public static TraceEvent Metered(string agent, string model, long inputTokens, long outputTokens, decimal cost, double latencyMs, bool estimated = false) =>
        new()
        {
            Kind = TraceEventKind.ModelCallMetered,
            Agent = agent,
            Title = $"{model}: {inputTokens:N0} in / {outputTokens:N0} out{(estimated ? " (estimated)" : "")}",
            Detail = $"model={model} input={inputTokens} output={outputTokens} costUSD={cost:F6} latency={latencyMs:N0}ms usage={(estimated ? "estimated (chars/4)" : "provider")}",
            InputTokens = inputTokens,
            OutputTokens = outputTokens,
            Cost = cost,
            LatencyMs = latencyMs,
            UsageEstimated = estimated,
        };

    public static TraceEvent Handoff(string fromAgent, string toAgent, string payload) =>
        new() { Kind = TraceEventKind.Handoff, Agent = fromAgent, FromNode = fromAgent, ToNode = toAgent, Title = $"handoff → {toAgent}", Detail = payload };

    public static TraceEvent Plan(string agent, string planJson) =>
        new() { Kind = TraceEventKind.PlanEmitted, Agent = agent, Title = "plan emitted", Detail = planJson };

    public static TraceEvent Memory(string agent, string title, string detail) =>
        new() { Kind = TraceEventKind.MemoryRecalled, Agent = agent, Title = title, Detail = detail };

    public static TraceEvent Prompt(string agent, string renderedPrompt) =>
        new() { Kind = TraceEventKind.PromptCaptured, Agent = agent, Title = "prompt captured (click to inspect)", Detail = renderedPrompt };

    public static TraceEvent Info(string agent, string title, string detail = "") =>
        new() { Kind = TraceEventKind.Info, Agent = agent, Title = title, Detail = detail };

    public static TraceEvent Error(string agent, string title, string detail = "") =>
        new() { Kind = TraceEventKind.Error, Agent = agent, Title = title, Detail = detail };
}
