using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

namespace DiscoverAF.Shared;

public interface IDemoPipeline
{
    string Name { get; }

    string Description { get; }

    Task<string> RunAsync(string userMessage, DemoSession session, IProgress<TraceEvent> trace, CancellationToken ct);
}

public sealed class DemoSession
{
    private readonly Dictionary<string, object> _items = [];

    public List<ChatMessage> Transcript { get; } = [];

    public T? Get<T>(string key) where T : class =>
        _items.TryGetValue(key, out var value) ? (T)value : null;

    public void Set(string key, object value) => _items[key] = value;

    public async ValueTask<AgentSession> GetOrCreateAgentSessionAsync(string key, AIAgent agent, CancellationToken ct)
    {
        if (Get<AgentSession>(key) is { } existing)
        {
            return existing;
        }

        var session = await agent.CreateSessionAsync(ct);
        Set(key, session);
        return session;
    }
}
