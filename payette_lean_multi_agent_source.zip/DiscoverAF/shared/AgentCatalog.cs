using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

namespace DiscoverAF.Shared;

public static class AgentCatalog
{
    public const string Orders = "Orders";
    public const string Returns = "Returns";
    public const string Product = "Product";
    public const string Account = "Account";

    public static readonly string[] SpecialistNames = [Orders, Returns, Product, Account];

    public static string InstructionsFor(string specialist) => specialist switch
    {
        Orders =>
            "You are the Orders specialist for Contoso Outfitters, an outdoor-gear store. " +
            "You handle order status, shipping, and cancellations using your tools. " +
            "Be concise and factual. The customer is CUST-1001 (Alex Rivera).",
        Returns =>
            "You are the Returns specialist for Contoso Outfitters. You handle returns, refunds, " +
            "and exchanges using your tools. Always check eligibility before starting a return. " +
            "When the customer asks to return an identified item, start the eligible return with StartReturn " +
            "and report its actual return ID; eligibility advice alone does not complete that request. " +
            "Only ask for clarification when a required fact is missing. If the customer only asks about " +
            "policy or eligibility, answer that question without starting a return. Do not issue a refund " +
            "unless the return is approved and a refund is requested. " +
            "Be concise. The customer is CUST-1001 (Alex Rivera).",
        Product =>
            "You are the Product specialist for Contoso Outfitters. You recommend gear, answer sizing " +
            "questions, and check stock using your tools. Recommend only in-stock products and respect " +
            "any budget the customer states. Be concise.",
        Account =>
            "You are the Account specialist for Contoso Outfitters. You manage the customer's profile: " +
            "shipping address, payment method on file, and loyalty points, using your tools. " +
            "Be concise. The customer is CUST-1001 (Alex Rivera).",
        _ => throw new ArgumentException($"Unknown specialist '{specialist}'", nameof(specialist)),
    };

    public static IList<AITool> ScopedToolsFor(string specialist, ContosoTools tools) => specialist switch
    {
        Orders => tools.OrdersTools(),
        Returns => tools.ReturnsTools(),
        Product => tools.ProductTools(),
        Account => tools.AccountTools(),
        _ => throw new ArgumentException($"Unknown specialist '{specialist}'", nameof(specialist)),
    };

    public static ChatClientAgent CreateSpecialist(
        DemoConfig config,
        string specialist,
        IProgress<TraceEvent> trace,
        bool allTools = false,
        ChatHistoryProvider? historyProvider = null,
        IEnumerable<AIContextProvider>? contextProviders = null)
    {
        var tools = new ContosoTools(trace, specialist);
        var options = new ChatClientAgentOptions
        {
            Id = $"contoso-{specialist.ToLowerInvariant()}",
            Name = specialist,
            Description = DescriptionFor(specialist),
            ChatOptions = new ChatOptions
            {
                Instructions = InstructionsFor(specialist),
                Tools = allTools ? tools.AllTools() : ScopedToolsFor(specialist, tools),
            },
            ChatHistoryProvider = historyProvider,
            AIContextProviders = contextProviders,
        };

        return new ChatClientAgent(config.CreateMeteredChatClient(specialist, config.ChatDeployment, trace), options);
    }

    public static ChatClientAgent[] CreateAllSpecialists(DemoConfig config, IProgress<TraceEvent> trace, bool allTools = false) =>
        [.. SpecialistNames.Select(name => CreateSpecialist(config, name, trace, allTools))];

    public static string DescriptionFor(string specialist) => specialist switch
    {
        Orders => "Handles order status, shipping updates, and cancellations.",
        Returns => "Handles returns, refunds, and exchanges.",
        Product => "Handles product recommendations, sizing, and stock checks.",
        Account => "Handles shipping address, payment methods, and loyalty points.",
        _ => "",
    };

    public static ChatClientAgent CreateMiniAgent(
        DemoConfig config, string name, string instructions, IProgress<TraceEvent> trace) =>
        new(
            config.CreateMeteredChatClient(name, config.MiniDeployment, trace),
            new ChatClientAgentOptions
            {
                Id = $"contoso-{name.ToLowerInvariant()}",
                Name = name,
                ChatOptions = new ChatOptions { Instructions = instructions },
            });

    public static ChatClientAgent CreateFrontierAgent(
        DemoConfig config,
        string name,
        string instructions,
        IProgress<TraceEvent> trace,
        IList<AITool>? tools = null,
        ChatHistoryProvider? historyProvider = null,
        IEnumerable<AIContextProvider>? contextProviders = null) =>
        new(
            config.CreateMeteredChatClient(name, config.ChatDeployment, trace),
            new ChatClientAgentOptions
            {
                Id = $"contoso-{name.ToLowerInvariant()}",
                Name = name,
                ChatOptions = new ChatOptions { Instructions = instructions, Tools = tools },
                ChatHistoryProvider = historyProvider,
                AIContextProviders = contextProviders,
            });
}
