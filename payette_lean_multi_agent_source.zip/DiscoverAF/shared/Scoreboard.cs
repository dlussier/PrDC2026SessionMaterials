using System.Collections.Concurrent;
using System.Text.Json;

namespace DiscoverAF.Shared;

public sealed class DemoRunTotals
{
    public long InputTokens { get; set; }
    public long OutputTokens { get; set; }
    public decimal Cost { get; set; }
    public int ModelCalls { get; set; }
}

public sealed class Scoreboard
{
    private readonly string _path;
    private readonly object _gate = new();
    private readonly ConcurrentDictionary<string, DemoRunTotals> _totals;

    public Scoreboard() : this(Path.Combine(AppContext.BaseDirectory, "scoreboard.json")) { }

    public Scoreboard(string path)
    {
        _path = path;
        _totals = Load(_path);
    }

    public event Action? Changed;

    public string? PersistenceError { get; private set; }

    public IReadOnlyDictionary<string, DemoRunTotals> Totals
    {
        get
        {
            lock (_gate)
                return _totals.ToDictionary(kv => kv.Key, kv => new DemoRunTotals
                {
                    InputTokens = kv.Value.InputTokens, OutputTokens = kv.Value.OutputTokens,
                    Cost = kv.Value.Cost, ModelCalls = kv.Value.ModelCalls,
                });
        }
    }

    public void Record(string demoName, TraceEvent metered)
    {
        if (metered.Kind != TraceEventKind.ModelCallMetered) return;
        lock (_gate)
        {
            var totals = _totals.GetOrAdd(demoName, _ => new DemoRunTotals());
            totals.InputTokens += metered.InputTokens;
            totals.OutputTokens += metered.OutputTokens;
            totals.Cost += metered.Cost;
            totals.ModelCalls++;
            Save();
        }
        Changed?.Invoke();
    }

    public void ResetDemo(string demoName)
    {
        lock (_gate)
        {
            _totals.TryRemove(demoName, out _);
            Save();
        }
        Changed?.Invoke();
    }

    public void ResetAll()
    {
        lock (_gate)
        {
            _totals.Clear();
            Save();
        }
        Changed?.Invoke();
    }

    private void Save()
    {
        try
        {
            File.WriteAllText(_path + ".tmp", JsonSerializer.Serialize(_totals, new JsonSerializerOptions { WriteIndented = true }));
            File.Move(_path + ".tmp", _path, overwrite: true);
            PersistenceError = null;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            PersistenceError = $"Totals are available in memory but could not be saved: {ex.Message}";
        }
    }

    private static ConcurrentDictionary<string, DemoRunTotals> Load(string path)
    {
        try
        {
            if (File.Exists(path))
            {
                var loaded = JsonSerializer.Deserialize<Dictionary<string, DemoRunTotals>>(File.ReadAllText(path));
                if (loaded is not null)
                {
                    return new ConcurrentDictionary<string, DemoRunTotals>(loaded);
                }
            }
        }
        catch (Exception ex) when (ex is JsonException or IOException or UnauthorizedAccessException)
        {
        }

        return new ConcurrentDictionary<string, DemoRunTotals>();
    }
}
