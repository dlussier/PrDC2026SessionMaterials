using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.AI;

namespace DiscoverAF.Shared;

public sealed class MeteredChatClient(
    IChatClient innerClient,
    string agentName,
    string model,
    ModelPricing pricing,
    IProgress<TraceEvent> trace) : DelegatingChatClient(innerClient)
{
    public override async Task<ChatResponse> GetResponseAsync(
        IEnumerable<ChatMessage> messages, ChatOptions? options = null, CancellationToken cancellationToken = default)
    {
        var messageList = messages.ToList();
        var callId = Guid.NewGuid().ToString("N");
        trace.Report(new TraceEvent { Kind = TraceEventKind.ModelCallStarted, Agent = agentName, Title = "model running", CallId = callId });
        trace.Report(TraceEvent.Prompt(agentName, RenderPrompt(messageList, options)) with { CallId = callId });

        var stopwatch = Stopwatch.StartNew();
        try
        {
            var response = await base.GetResponseAsync(messageList, options, cancellationToken);
            stopwatch.Stop();
            Meter(response.Usage, RenderPrompt(messageList, options), RenderPrompt(response.Messages.ToList(), null), stopwatch.Elapsed.TotalMilliseconds, callId);
            trace.Report(new TraceEvent
            {
                Kind = TraceEventKind.ModelCallCompleted,
                Agent = agentName,
                Title = "model replied",
                Detail = response.Text,
                CallId = callId
            });
            return response;
        }
        catch (Exception ex)
        {
            trace.Report(new TraceEvent
            {
                Kind = TraceEventKind.ModelCallFailed,
                Agent = agentName,
                Title = "model call failed",
                Detail = ex.Message,
                CallId = callId,
                Cancelled = ex is OperationCanceledException
            });
            throw;
        }
    }

    public override async IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(
        IEnumerable<ChatMessage> messages, ChatOptions? options = null, [EnumeratorCancellation] CancellationToken cancellationToken = default)
    {
        var messageList = messages.ToList();
        var callId = Guid.NewGuid().ToString("N");
        trace.Report(new TraceEvent { Kind = TraceEventKind.ModelCallStarted, Agent = agentName, Title = "model running", CallId = callId });
        trace.Report(TraceEvent.Prompt(agentName, RenderPrompt(messageList, options)) with { CallId = callId });

        var stopwatch = Stopwatch.StartNew();
        UsageDetails? usage = null;
        var outputText = new StringBuilder();

        var completed = false;
        try
        {
            await foreach (var update in base.GetStreamingResponseAsync(messageList, options, cancellationToken))
            {
                foreach (var content in update.Contents)
                {
                    if (content is UsageContent usageContent)
                    {
                        usage = usageContent.Details;
                    }
                }

                outputText.Append(update.Text);
                foreach (var call in update.Contents.OfType<FunctionCallContent>())
                {
                    outputText.Append(call.Name).Append(JsonSerializer.Serialize(call.Arguments));
                }
                yield return update;
            }

            stopwatch.Stop();
            Meter(usage, RenderPrompt(messageList, options), outputText.ToString(), stopwatch.Elapsed.TotalMilliseconds, callId);
            completed = true;
            trace.Report(new TraceEvent
            {
                Kind = TraceEventKind.ModelCallCompleted,
                Agent = agentName,
                Title = "model replied",
                Detail = outputText.ToString(),
                CallId = callId
            });
        }
        finally
        {
            if (!completed) trace.Report(new TraceEvent
            {
                Kind = TraceEventKind.ModelCallFailed,
                Agent = agentName,
                Title = "stream ended before completion",
                CallId = callId,
                Cancelled = cancellationToken.IsCancellationRequested
            });
        }
    }

    private void Meter(UsageDetails? usage, string prompt, string outputText, double latencyMs, string callId)
    {
        var inputTokens = usage?.InputTokenCount ?? EstimateTokens(prompt.Length);
        var outputTokens = usage?.OutputTokenCount ?? EstimateTokens(outputText.Length);
        trace.Report(TraceEvent.Metered(agentName, model, inputTokens, outputTokens, pricing.CostFor(inputTokens, outputTokens), latencyMs,
            estimated: usage?.InputTokenCount is null || usage?.OutputTokenCount is null) with
        { CallId = callId });
    }

    private static long EstimateTokens(int charCount) => (charCount + 3L) / 4;

    public static string RenderPrompt(List<ChatMessage> messages, ChatOptions? options)
    {
        var sb = new StringBuilder();

        if (!string.IsNullOrEmpty(options?.Instructions))
        {
            sb.AppendLine("── instructions ──");
            sb.AppendLine(options.Instructions);
        }

        if (options?.ResponseFormat is ChatResponseFormatJson jsonFormat)
        {
            sb.AppendLine("── response format: JSON ──");
            sb.AppendLine(jsonFormat.Schema?.ToString() ?? "JSON object");
            if (options.AdditionalProperties?.TryGetValue("strict", out var strict) == true)
                sb.AppendLine($"Provider strict schema: {strict}");
        }

        if (options?.Tools is { Count: > 0 } tools)
        {
            sb.AppendLine($"── tools registered: {tools.Count} ──");
            sb.AppendLine(string.Join(", ", tools.Select(t => t.Name)));
            foreach (var function in tools.OfType<AIFunction>())
            {
                sb.AppendLine($"{function.Name}: {function.Description}");
                sb.AppendLine(function.JsonSchema.ToString());
            }
        }

        sb.AppendLine($"── messages: {messages.Count} ──");
        foreach (var message in messages)
        {
            sb.Append('[').Append(message.Role.Value).Append("] ");
            foreach (var content in message.Contents)
            {
                switch (content)
                {
                    case TextContent text:
                        sb.AppendLine(text.Text);
                        break;
                    case FunctionCallContent call:
                        sb.AppendLine($"→ call {call.Name}({JsonSerializer.Serialize(call.Arguments)})");
                        break;
                    case FunctionResultContent result:
                        sb.AppendLine($"← result {result.CallId}: {result.Result}");
                        break;
                    default:
                        sb.AppendLine(content.GetType().Name);
                        break;
                }
            }
        }

        return sb.ToString();
    }
}
