namespace DiscoverAF.Shared;

public static class Scenario
{
    public const string CanonicalPrompt =
        "My hiking boots from order #48213 are falling apart — I want to return them, get a replacement " +
        "recommendation under $150 that's in stock in size 10, and while you're at it, update my shipping " +
        "address to 42 Summit Trail.";

    public static readonly string[] QuickPrompts =
    [
        "Where's my order #48610?",
        "Are the Torrent boots waterproof?",
        "How many loyalty points do I have?",
        "Can I still return my insulated bottles from order 47775?",
        "What size should I get in the Summit Ridge boots if I wear thick socks?",
    ];

    public const string AutoPlayCommand = "/autoplay";

    public static readonly string[] LongSessionScript =
    [
        "Hi! I'm planning a week-long backpacking trip in the Rockies this fall.",
        "It'll be 6 nights, mostly on-trail, some rain likely.",
        "I wear size 10 boots by the way, and I strongly prefer waterproof gear.",
        "What tent would you recommend for two people?",
        "How heavy is the Alpine Meadow 2P tent?",
        "Is it freestanding? I camp on rocky ground a lot.",
        "What sleeping pad pairs well with it for shoulder-season temps?",
        "I run cold at night — is the Stargazer warm enough for October?",
        "Add a quilt recommendation to go with that pad.",
        "What stove should I bring if I mostly boil water for dehydrated meals?",
        "How long does a fuel canister last with that stove?",
        "Now boots — my old pair is falling apart. What do you recommend?",
        "Which of those are in stock right now?",
        "Do they run true to size?",
        "What's the price on the Torrent Waterproof Boots?",
        "Are they covered by the lifetime guarantee?",
        "What rain shell goes well for fall in the Rockies?",
        "Does the Stormfront have pit zips?",
        "What was the shoe size I told you earlier?",
        "Great — summarize a complete packing list for the trip with prices.",
    ];
}
