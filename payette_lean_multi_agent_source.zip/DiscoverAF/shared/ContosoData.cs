namespace DiscoverAF.Shared;

public sealed class Order
{
    public required string Id { get; init; }
    public required string CustomerId { get; init; }
    public required string Item { get; init; }
    public required decimal Price { get; init; }
    public required string Status { get; set; }
    public required string OrderedOn { get; init; }
    public required string DeliveredOn { get; init; }
    public required string Carrier { get; init; }
    public required string TrackingNumber { get; init; }
}

public sealed class Product
{
    public required string Sku { get; init; }
    public required string Name { get; init; }
    public required string Category { get; init; }
    public required decimal Price { get; init; }
    public required bool Waterproof { get; init; }
    public required int[] SizesInStock { get; init; }
    public required int UnitsInStock { get; init; }
    public required string Description { get; init; }
}

public sealed class CustomerProfile
{
    public required string CustomerId { get; init; }
    public required string Name { get; init; }
    public required string ShippingAddress { get; set; }
    public required string PaymentMethod { get; init; }
    public required int LoyaltyPoints { get; set; }
    public required string MembershipTier { get; init; }
}

public sealed class ReturnRecord
{
    public required string ReturnId { get; init; }
    public required string OrderId { get; init; }
    public required string Reason { get; init; }
    public required string Status { get; set; }
}

public static class ContosoData
{
    private static readonly object Lock = new();
    internal static object SyncRoot => Lock;

    public static DateOnly ScenarioDate { get; } = new(2026, 8, 21);

    public static bool IsWithinReturnWindow(Order order) =>
        DateOnly.TryParseExact(order.DeliveredOn, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture,
            System.Globalization.DateTimeStyles.None, out var delivered) &&
        ScenarioDate.DayNumber - delivered.DayNumber is >= 0 and <= 60;

    private const string SeedShippingAddress = "17 Juniper Lane, Boulder, CO 80301";

    public static CustomerProfile Profile { get; } = new()
    {
        CustomerId = "CUST-1001",
        Name = "Alex Rivera",
        ShippingAddress = SeedShippingAddress,
        PaymentMethod = "Visa ending 4242",
        LoyaltyPoints = 1840,
        MembershipTier = "TrailBlazer",
    };

    public static List<Order> Orders { get; } =
    [
        new()
        {
            Id = "48213", CustomerId = "CUST-1001", Item = "Summit Ridge Hiking Boots (size 10)",
            Price = 129.95m, Status = "Delivered", OrderedOn = "2026-05-28", DeliveredOn = "2026-06-03",
            Carrier = "FedEx", TrackingNumber = "FX-4821-3391-07",
        },
        new()
        {
            Id = "48610", CustomerId = "CUST-1001", Item = "Alpine Meadow 2P Tent",
            Price = 289.00m, Status = "In transit", OrderedOn = "2026-08-18", DeliveredOn = "",
            Carrier = "UPS", TrackingNumber = "1Z-8846-2210-44",
        },
        new()
        {
            Id = "47775", CustomerId = "CUST-1001", Item = "Cascade 32oz Insulated Bottle (2-pack)",
            Price = 54.50m, Status = "Delivered", OrderedOn = "2026-04-02", DeliveredOn = "2026-04-06",
            Carrier = "USPS", TrackingNumber = "94-0551-7788-21",
        },
    ];

    private static readonly Dictionary<string, string> SeedOrderStatuses =
        Orders.ToDictionary(order => order.Id, order => order.Status);

    public static List<ReturnRecord> Returns { get; } = [];

    public static List<Product> Catalog { get; } = BuildCatalog();

    public static Order? FindOrder(string orderId) =>
        Orders.FirstOrDefault(o => o.Id == orderId.Trim().TrimStart('#'));

    public static ReturnRecord StartReturn(string orderId, string reason)
    {
        lock (Lock)
        {
            var existing = Returns.FirstOrDefault(r => r.OrderId == orderId.Trim().TrimStart('#'));
            if (existing is not null) return existing;
            var record = new ReturnRecord
            {
                ReturnId = $"RET-{9000 + Returns.Count}",
                OrderId = orderId.Trim().TrimStart('#'),
                Reason = reason,
                Status = "Label emailed — drop off within 30 days",
            };
            Returns.Add(record);
            return record;
        }
    }

    public static void UpdateAddress(string newAddress)
    {
        lock (Lock)
        {
            Profile.ShippingAddress = newAddress;
        }
    }

    public static void ResetFixtures()
    {
        lock (Lock)
        {
            Returns.Clear();
            Profile.ShippingAddress = SeedShippingAddress;
            foreach (var order in Orders)
            {
                if (SeedOrderStatuses.TryGetValue(order.Id, out var status)) order.Status = status;
            }
        }
    }

    private static List<Product> BuildCatalog()
    {
        (string Name, string Category, decimal Price, bool Waterproof, int[] Sizes, int Units, string Hook)[] seed =
        [
            ("Summit Ridge Hiking Boots", "Footwear", 129.95m, true, [8, 9, 10, 11], 42, "aggressive lugs and a roomy toe box for long ridge days"),
            ("Torrent Waterproof Boots", "Footwear", 148.00m, true, [7, 8, 9, 10, 12], 31, "a seam-sealed bootie that laughs at creek crossings"),
            ("Granite Peak Trail Runners", "Footwear", 119.00m, false, [8, 9, 10, 11, 12], 57, "rock-plate protection at trail-runner weight"),
            ("Cloudline Approach Shoes", "Footwear", 139.50m, false, [9, 10, 11], 12, "sticky rubber for scrambles and via ferrata"),
            ("Mudguard Gaiter Boots", "Footwear", 99.99m, true, [8, 10, 11], 8, "integrated gaiters for shoulder-season slop"),
            ("Ridgeline Mid Hikers", "Footwear", 112.00m, true, [7, 8, 9, 10, 11, 13], 64, "mid-cut ankle support without the tank-like weight"),
            ("Alpine Meadow 2P Tent", "Camping", 289.00m, true, [], 19, "a 3-season freestanding pitch in under four minutes"),
            ("Basecamp 4P Tent", "Camping", 419.00m, true, [], 7, "standing headroom and two vestibules for family basecamps"),
            ("Firefly Ultralight Quilt", "Camping", 249.00m, false, [], 23, "850-fill down at a pack weight you will forget"),
            ("Stargazer Sleeping Pad", "Camping", 129.00m, false, [], 40, "4.5 R-value insulation with a whisper-quiet face fabric"),
            ("Ember Titanium Stove", "Camping", 64.95m, false, [], 88, "a 48-gram burner that simmers as well as it boils"),
            ("Cascade 32oz Insulated Bottle", "Accessories", 29.75m, false, [], 210, "24-hour ice retention in a bottle that fits every cage"),
            ("Switchback 45L Pack", "Packs", 189.00m, false, [], 26, "a ventilated backpanel and hipbelt pockets sized for real snacks"),
            ("Daybreak 22L Daypack", "Packs", 89.00m, false, [], 73, "a clamshell opening that makes day-hike packing painless"),
            ("Monsoon Pack Rain Cover", "Packs", 24.50m, true, [], 120, "high-visibility waterproof armor for 35-55L packs"),
            ("Stormfront Hardshell Jacket", "Apparel", 229.00m, true, [], 34, "3-layer weatherproofing with pit zips for climbing hard"),
            ("Foehn Windbreaker", "Apparel", 99.00m, false, [], 51, "a 90-gram wind layer that packs into its own chest pocket"),
            ("Timberline Fleece Pullover", "Apparel", 79.00m, false, [], 66, "grid fleece warmth that breathes on the uphill"),
            ("Confluence Rain Pants", "Apparel", 119.00m, true, [], 29, "full-length side zips over boots, no hopping required"),
            ("Sunbreak Trekking Shirt", "Apparel", 54.00m, false, [], 95, "UPF 50 fabric that dries before the next switchback"),
            ("Ridgepole Carbon Trekking Poles", "Accessories", 149.00m, false, [], 44, "carbon shafts with foam grips that extend for steep traverses"),
            ("Glowworm 400 Headlamp", "Accessories", 49.95m, true, [], 132, "400 lumens, a red mode, and a battery that outlasts the trip"),
            ("Blue Hour Water Filter", "Accessories", 42.00m, false, [], 77, "a hollow-fiber filter pushing 1.5 liters per minute"),
            ("Trailside First Aid Kit", "Accessories", 34.95m, true, [], 150, "trail-tuned supplies in a waterproof roll-top pouch"),
            ("Peak Seeker GPS Watch", "Electronics", 349.00m, true, [], 15, "multi-band GPS, offline topo maps, and a 30-day battery"),
        ];

        return
        [
            .. seed.Select((p, index) => new Product
            {
                Sku = $"CO-{1000 + index}",
                Name = p.Name,
                Category = p.Category,
                Price = p.Price,
                Waterproof = p.Waterproof,
                SizesInStock = p.Sizes,
                UnitsInStock = p.Units,
                Description =
                    $"The {p.Name} is Contoso Outfitters' {p.Category.ToLowerInvariant()} standout, featuring {p.Hook}. " +
                    "Built with our EverTrail fabric technology and backed by the Contoso lifetime guarantee, it has been " +
                    "field-tested across the Rockies, the Cascades, and the Appalachian Trail by our ambassador team. " +
                    "Customers consistently praise its durability, thoughtful detailing, and the way it balances weight " +
                    "against ruggedness. Available exclusively through Contoso Outfitters retail and online stores, with " +
                    "free returns within 60 days and free TrailBlazer-member shipping on orders over $49.",
            }),
        ];
    }
}
