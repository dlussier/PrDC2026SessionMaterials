using Azure.AI.OpenAI;
using System.Globalization;
using Azure.Identity;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Configuration;

namespace DiscoverAF.Shared;

public sealed record ModelPricing(decimal InputPerMillion, decimal OutputPerMillion)
{
    public decimal CostFor(long inputTokens, long outputTokens) =>
        (inputTokens * InputPerMillion + outputTokens * OutputPerMillion) / 1_000_000m;
}

public sealed class DemoConfig
{
    private readonly Dictionary<string, ModelPricing> _pricing;
    private readonly Lazy<AzureOpenAIClient> _client;
    private readonly Func<string, IChatClient>? _chatClientFactory;

    public DemoConfig(IConfiguration configuration, Func<string, IChatClient>? chatClientFactory = null)
    {
        _chatClientFactory = chatClientFactory;
        var section = configuration.GetSection("DiscoverAF");

        Endpoint = FirstNonEmpty(Environment.GetEnvironmentVariable("AZURE_AI_ENDPOINT"), section["Endpoint"]);
        _client = new(() => new AzureOpenAIClient(new Uri(Endpoint!), new DefaultAzureCredential()));
        ChatDeployment = FirstNonEmpty(Environment.GetEnvironmentVariable("AZURE_AI_CHAT_DEPLOYMENT"), section["ChatDeployment"]) ?? "gpt-5.4";
        MiniDeployment = FirstNonEmpty(Environment.GetEnvironmentVariable("AZURE_AI_MINI_DEPLOYMENT"), section["MiniDeployment"]) ?? "gpt-5.4-mini";
        CosmosEndpoint = FirstNonEmpty(Environment.GetEnvironmentVariable("COSMOS_ENDPOINT"), section["CosmosEndpoint"]);
        CosmosDatabase = FirstNonEmpty(Environment.GetEnvironmentVariable("COSMOS_DATABASE"), section["CosmosDatabase"]) ?? "agent-memory";

        _pricing = [];
        foreach (var child in section.GetSection("Pricing").GetChildren())
        {
            _pricing[child.Key] = new ModelPricing(
                decimal.TryParse(child["InputPerMillion"], NumberStyles.Number, CultureInfo.InvariantCulture, out var input) ? input : 0m,
                decimal.TryParse(child["OutputPerMillion"], NumberStyles.Number, CultureInfo.InvariantCulture, out var output) ? output : 0m);
        }
    }

    public string? Endpoint { get; }

    public string ChatDeployment { get; }

    public string MiniDeployment { get; }

    public string? CosmosEndpoint { get; }

    public string CosmosDatabase { get; }

    public bool IsConfigured => !string.IsNullOrWhiteSpace(Endpoint);

    public const string NotConfiguredMessage =
        "Azure AI isn't configured yet. Run `terraform apply` under terraform/, then set the environment " +
        "variables from `terraform output env_block` (or fill in the DiscoverAF section of host/appsettings.json) " +
        "and restart the host. You'll also need `az login` — the demos use keyless (Entra ID) auth.";

    public ModelPricing PricingFor(string deployment) =>
        _pricing.TryGetValue(deployment, out var pricing) ? pricing : new ModelPricing(0m, 0m);

    public IChatClient CreateRawChatClient(string deployment)
    {
        if (_chatClientFactory is not null) return _chatClientFactory(deployment);
        if (!IsConfigured)
        {
            throw new InvalidOperationException(
                "Azure AI is not configured. Set AZURE_AI_ENDPOINT (see `terraform output env_block`) " +
                "or the DiscoverAF:Endpoint appsettings value, then restart the host.");
        }

        return _client.Value.GetChatClient(deployment).AsIChatClient();
    }

    public IChatClient CreateMeteredChatClient(string agentName, string deployment, IProgress<TraceEvent> trace)
    {
        if (!_pricing.ContainsKey(deployment))
            trace.Report(TraceEvent.Info(agentName, $"No pricing configured for '{deployment}'; reported cost will be zero."));
        return new MeteredChatClient(CreateRawChatClient(deployment), agentName, deployment, PricingFor(deployment), trace);
    }

    private static string? FirstNonEmpty(params string?[] values) =>
        values.FirstOrDefault(v => !string.IsNullOrWhiteSpace(v));
}
