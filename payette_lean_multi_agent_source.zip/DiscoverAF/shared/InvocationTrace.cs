namespace DiscoverAF.Shared;

public sealed class InvocationTrace : IProgress<TraceEvent>
{
    private readonly IProgress<TraceEvent> _parent;
    public string Agent { get; }
    public string NodeId { get; }
    public string Id { get; } = Guid.NewGuid().ToString("N");
    public string? ParentId { get; }

    private InvocationTrace(IProgress<TraceEvent> parent, string agent, string nodeId)
    {
        _parent = parent;
        Agent = agent;
        NodeId = nodeId;
        ParentId = (parent as InvocationTrace)?.Id;
    }

    public void Report(TraceEvent value) => _parent.Report(value with
    {
        NodeId = value.NodeId ?? (value.Agent == Agent ? NodeId : value.Agent),
        InvocationId = value.InvocationId ?? (value.Agent == Agent ? Id : null),
        ParentInvocationId = value.ParentInvocationId ?? (value.Agent == Agent ? ParentId : null),
    });

    public static async Task<T> RunAsync<T>(IProgress<TraceEvent> parent, string agent, string input,
        Func<InvocationTrace, Task<T>> run, Func<T, string> output, string? nodeId = null,
        string? from = null, string? to = null)
    {
        var scope = new InvocationTrace(parent, agent, nodeId ?? agent);
        scope.Report(new TraceEvent
        {
            Kind = TraceEventKind.InvocationStarted,
            Agent = agent,
            Title = "received task",
            Detail = input,
            FromNode = from,
            ToNode = scope.NodeId
        });
        try
        {
            var result = await run(scope);
            scope.Report(new TraceEvent
            {
                Kind = TraceEventKind.InvocationCompleted,
                Agent = agent,
                Title = "returned result",
                Detail = output(result),
                FromNode = scope.NodeId,
                ToNode = to
            });
            return result;
        }
        catch (Exception ex)
        {
            scope.Report(new TraceEvent
            {
                Kind = TraceEventKind.InvocationFailed,
                Agent = agent,
                Title = ex is OperationCanceledException ? "cancelled" : "failed",
                Detail = ex.Message,
                Cancelled = ex is OperationCanceledException
            });
            throw;
        }
    }
}
